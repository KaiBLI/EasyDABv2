
var default_config = [
0x80, //reset eth
192, 168, 1, 1, //gw IP
255, 255, 255, 0, //mask
0x00, 0x08, 0xDC, 0x01, 0x02, 0x03, // MAC-addr MAC[0] == 0x00!
192, 168, 1, 2, //device IP
0x01, //Sn_MR => MR_TCP socket is tcp

0x46, 0xa0, //Sn_PORT source TCP port

192, 168, 1, 20, //eti-server IP
0x1f, 0x40, // eti-server port 8000

04, //04=tcp client, 01=tcp server
0x0E, // reg id of dac
0x48, //CCI Interpolation Rate<7:2> Spectral Invert Inverse CCI Bypass:
0x80, //Auxiliary DAC Control Register: 1.0
0x00, 0x00, //Phase Offset Word
0x54, 0x3A, 0xAB, 0x00, //FTW: 2^32 / (24576000 * 24) * 194064000 => 0x543AAB00
0xFF, // ZeroMQ flag: 0xFF disable, 0x01 - enable
//OFFSET:
0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,
0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,
//YWRtaW46YWRtaW4= which means admin:admin password
0x59,0x57,0x52,0x74,0x61,0x57,0x34,0x36,0x59,0x57,0x52,0x74,0x61,0x57,0x34,0x3D,0x00,
//OFFSET:
0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,
0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,
0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,
// ZeroMQ query string:
0xff,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x01,0x7f,
0x03,0x00,
0x4e,0x55,0x4c,0x4c,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
// ZeroMQ query after handshake:
0x04,0x19,0x05,0x52,0x45,0x41,0x44,0x59,0x0b,0x53,0x6f,0x63,0x6b,0x65,0x74,0x2d,0x54,0x79,0x70,0x65,0x00,0x00,0x00,0x03,0x53,0x55,0x42,
0x00,0x01,0x01

];

var uint8_default = new Uint8Array(default_config);

function gElVal(doc) { return document.getElementById(doc); }

function log(msg, clr) {
    gElVal("status").innerHTML = msg;
    gElVal("status").style.color = clr;
}

function dec2hex(d, padding) {
    var hex = Number(d).toString(16);
    padding = typeof (padding) === "undefined" || padding === null ? padding = 2 : padding;

    while (hex.length < padding) {
        hex = "0" + hex;
    }

    return hex;
}


function getBinary(file, callback, callback_args)
{
  var oReq = new XMLHttpRequest();
  oReq.open("GET", file, true);
  oReq.responseType = "arraybuffer";

  oReq.onload = function (oEvent) {
    var arrayBuffer = oReq.response; // Note: not oReq.responseText
    if (arrayBuffer) {
      var byteArray = new Uint8Array(arrayBuffer);
      console.log("data.length:" + byteArray.length);
      console.log("data.BYTES_PER_ELEMENT:"+byteArray.BYTES_PER_ELEMENT);
      console.log("data:" + typeof byteArray);
      var dbgArray = byteArray.subarray(0, 128);
      console.log(Array.apply([], dbgArray).join(","));

      if(callback) {
        callback(byteArray, callback_args);
      }
    }
  };

  oReq.send(null);
};





function sendBinary(file, binary, callback, callback_args)
{
  var oReq = new XMLHttpRequest();
  oReq.open("POST", file, true);
  oReq.responseType = "arraybuffer";
  oReq.overrideMimeType('application\/octet-stream');

  oReq.upload.onprogress = function(event) {
    console.log(event.loaded + ' / ' + event.total);
  }

  oReq.onload = function (oEvent) {
    var arrayBuffer = oReq.response; // Note: not oReq.responseText
    if (arrayBuffer) {
      var byteArray = new Uint8Array(arrayBuffer);
      console.log("data.length:" + byteArray.length);
      console.log("data.BYTES_PER_ELEMENT:"+byteArray.BYTES_PER_ELEMENT);
      console.log("data:" + typeof byteArray);
      console.log(Array.apply([], byteArray).join(","));

      if(callback) {
        callback(byteArray, callback_args);
      }
    }
  };


  oReq.send(binary);
};

function arr2str(arr, pos) {
  var val="";
  for (var i=pos; i<arr.byteLength && arr[i] != 0x00; i++) {
    val += String.fromCharCode(arr[i])
  }
  console.log("arr2str:"+val);
  return val;
}

b64dec=function(f){var g={},b=65,d=0,a,c=0,h,e="",k=String.fromCharCode,l=f.length;for(a="";91>b;)a+=k(b++);a+=a.toLowerCase()+"0123456789+/";for(b=0;64>b;b++)g[a.charAt(b)]=b;for(a=0;a<l;a++)for(b=g[f.charAt(a)],d=(d<<6)+b,c+=6;8<=c;)((h=d>>>(c-=8)&255)||a<l-2)&&(e+=k(h));return e};

b64enc=function(f){
  var b64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
  var o1, o2, o3, h1, h2, h3, h4, bits, i = 0, ac = 0, enc = '', tmp_arr = [];
  if (!f) { return f; }
  f = unescape(encodeURIComponent(f));
  do {
    // pack three octets into four hexets
    o1 = f.charCodeAt(i++);
    o2 = f.charCodeAt(i++);
    o3 = f.charCodeAt(i++);

    bits = o1 << 16 | o2 << 8 | o3;

    h1 = bits >> 18 & 0x3f;
    h2 = bits >> 12 & 0x3f;
    h3 = bits >> 6 & 0x3f;
    h4 = bits & 0x3f;

    // use hexets to index into b64, and append result to encoded string
    tmp_arr[ac++] = b64.charAt(h1) + b64.charAt(h2) + b64.charAt(h3) + b64.charAt(h4);
  } while (i < f.length);

  enc = tmp_arr.join('');
  var r = f.length % 3;
  return (r ? enc.slice(0, r - 3) : enc) + '==='.slice(r || 3);
}




function setUIConfig(sample)
{
 var d_o = new Uint8Array(sample);
 gw_a = gElVal("cfg_gw").value.split(".", 4);
 d_o[1] = gw_a[0];
 d_o[2] = gw_a[1];
 d_o[3] = gw_a[2];
 d_o[4] = gw_a[3];

 mask_a = gElVal("cfg_mask").value.split(".", 4);
 d_o[5] = mask_a[0];
 d_o[6] = mask_a[1];
 d_o[7] = mask_a[2];
 d_o[8] = mask_a[3];

 mac_a = gElVal("cfg_mac").value.split(":", 6);
 d_o[9]  = parseInt(mac_a[0], 16);
 d_o[10] = parseInt(mac_a[1], 16);
 d_o[11] = parseInt(mac_a[2], 16);
 d_o[12] = parseInt(mac_a[3], 16);
 d_o[13] = parseInt(mac_a[4], 16);
 d_o[14] = parseInt(mac_a[5], 16);

 ip_a = gElVal("cfg_ip").value.split(".", 4);
 d_o[15] = ip_a[0];
 d_o[16] = ip_a[1];
 d_o[17] = ip_a[2];
 d_o[18] = ip_a[3];

 d_o[19] = 0x01; // tcp

 l_p = gElVal("cfg_local_port").value;
 d_o[20] = l_p / 256;
 d_o[21] = l_p % 256;

 r_ip_a = gElVal("cfg_remote_ip").value.split(".", 4);
 d_o[22] = r_ip_a[0];
 d_o[23] = r_ip_a[1];
 d_o[24] = r_ip_a[2];
 d_o[25] = r_ip_a[3];

 r_p = gElVal("cfg_remote_port").value;
 d_o[26] = r_p / 256;
 d_o[27] = r_p % 256;


 if(gElVal("cfg_mode_server").checked) { d_o[28] = 0x02; }
 else if(gElVal("cfg_mode_client").checked) {
    d_o[28] = 0x04;
    if(gElVal("cfg_remote_zmq").checked) { d_o[38] = 0x01 };
 }
 else if(gElVal("cfg_mode_off").checked) { d_o[28] = 0x00; }
 else { d_o[28] = 0x00; }

 if((gElVal("cfg_mode_server").checked || gElVal("cfg_mode_client").checked) && !gElVal("cfg_tcp_nodelay").checked) { d_o[19] |= 0x20; }

 d_o[31] = Math.ceil(gElVal("cfg_amplitude").value * 255 / 2);
 ftw = Math.round(gElVal("cfg_frequency").value * 4294967296 / (24576000 * 24));
 console.log('ftw='+ftw);
 ftw = ftw.toString(16);
 console.log('ftw='+ftw);
 ftw = ("00000000"+ftw).substr(-8);
 console.log('ftw='+ftw);
 d_o[34] = parseInt(ftw.substr(0,2), 16);
 d_o[35] = parseInt(ftw.substr(2,2), 16);
 d_o[36] = parseInt(ftw.substr(4,2), 16);
 d_o[37] = parseInt(ftw.substr(6,2), 16);

 l_p = b64enc(gElVal("cfg_login").value+":"+gElVal("cfg_password").value);
 console.log('l_p='+l_p);
 var i = 0;
 do {
   d_o[0x40+i] = l_p.charCodeAt(i);
   i++;
 } while (i < l_p.length);
 d_o[0x40+i] = 0x00; //null-termination
// console.log(Array.apply([], d_o).join(","));
 return d_o;
}
// 