
function getStatus_cb(data, next)
{
    console.log("getStatus_cb():" + data.length);

// 04 01 17 => connected (client)
// 02 01 14 => listening (noone)
// 02 01 17 => connected (server have client)
//#tcp_c_s_d{color:ee0000;}
//#tcp_c_s_c{color:00aa00;}
 gElVal("eti_socket_action").enabled = true;
 gElVal("eti_socket_action").value = "Turn OFF ETI socket";

 gElVal("fe_action").enabled = true;

 if((data[4] & 0x50) != 0) {
  gElVal("fe_action").value = "Turn ON RF-frontend";
  gElVal("fe_s").innerHTML="&#9711; Off"; gElVal("fe_s").style.color="aaaaaa";
 } else if (data[4] == 0x02) {
  gElVal("fe_action").value = "Turn OFF RF-frontend";
  gElVal("fe_s").innerHTML="&#11044; Broadcasting"; gElVal("fe_s").style.color="00aa00";
 } else {
  gElVal("fe_s").innerHTML="&#9711; Unknown "+dec2hex(data[4]); gElVal("fe_s").style.color="ee0000";
 }

 if((data[9] == 0x02 || data[9] == 0x04) && data[11] == 0x17) {  gElVal("conn_s").innerHTML="&#11044; Connected"; gElVal("conn_s").style.color="00aa00"; }
 else if(data[9] == 0x00 || data[9] == 0x01) {
    gElVal("eti_socket_action").value = "Turn ON ETI socket";
  if(data[10] == 0x01) {
    gElVal("conn_s").innerHTML="&#11044; Admin Off"; gElVal("conn_s").style.color="aaaaaa";
    gElVal("eti_socket_action").enabled = true;
  } else {
    gElVal("conn_s").innerHTML="&#11044; Flash Off"; gElVal("conn_s").style.color="aaaaaa";
    gElVal("eti_socket_action").enabled = false;
  }
 }
 else if(data[9] == 0x02 && data[11] == 0x14) {  gElVal("conn_s").innerHTML="&#11044; Listening"; gElVal("conn_s").style.color="aaaa00"; }
 else if(data[9] == 0x04 && (data[11] == 0x13|data[11] == 0x00)) {  gElVal("conn_s").innerHTML="&#11044; Connecting"; gElVal("conn_s").style.color="aaaa00"; }
 else {  gElVal("conn_s").innerHTML="&#11044; unknown:"+dec2hex(data[9])+":"+dec2hex(data[10])+":"+dec2hex(data[11]); gElVal("conn_s").style.color="ee0000"; }

 log("Status received", "00aa00");
 if(next) {
  console.log("have next callback, executing...");
  next();
 }
}

function getStatus(next)
{
 log("Getting status...", "aaaa00");

 gElVal("fe_action").enabled = false;
 gElVal("eti_socket_action").enabled = true;

 getBinary("s_000000", getStatus_cb, next);
// getConfig_cb(global_arr);
}

function switchConnection(id)
{
 if(gElVal("eti_socket_action").value == "Turn ON ETI socket") {
   if(c_mode=="server") {
     getBinary("s_010200", getStatus_cb);
   } else if(c_mode=="client") {
     getBinary("s_010400", getStatus_cb);
   }
 } else {
   getBinary("s_010000", getStatus_cb);
 }
// getConfig_cb(global_arr);
}

function switchFE(id)
{
 if(gElVal("fe_action").value == "Turn OFF RF-frontend") {
  getBinary("s_025000", getStatus_cb);
 } else {
  getBinary("s_020000", getStatus_cb);
 }
}



// 