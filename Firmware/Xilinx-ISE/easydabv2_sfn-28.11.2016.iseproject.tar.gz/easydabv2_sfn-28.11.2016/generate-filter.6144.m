#!/usr/bin/octave

n = 151; % num of coefficients
f = [0 0.26 1]; % frequency 0...819khz
a = [15 0]; % gain
up = [15.1 0.0001]; % ripple up
lo = [14.9 -0.0001]; % ripple down
h = fircls(n,f,a,up,lo); % fir sync
fprintf([repmat('%f, ', 1, size(h, 2)) '\n'], h'); % print coeffs
fvtool(h,1); % display graph
