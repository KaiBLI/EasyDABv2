


#include <ap_int.h>
#include <ap_utils.h>
#include <hls_stream.h>

#include "dab_prep.h"



//3*1024*18/(6912*8)
static ap_uint<9> cif_buffer_9_0[6144]; //+256bytes: 2048x1
static ap_uint<9> cif_buffer_9_1[6144]; //+256bytes: 2048x1
static ap_uint<9> cif_buffer_9_2[6144]; //+256bytes: 2048x1
static ap_uint<9> fin_cnt_9 = 0;

static void framemux_fill_pos(hls::stream<u8stream > &input, ap_uint<10> pos8, ap_uint<9> *buffer)
{
//#pragma HLS inline

//	bool is1bit=false;
	ap_uint<13> pos = pos8;
	pos <<= 3; //x8

	u8stream val;
	do {
#pragma HLS loop_tripcount min=0 max=6912 avg=768
		val = input.read();

		if(pos < 6144) {
			buffer[pos] = (buffer[pos] & 0x100) | val.data;
		} else if(pos < 6912) {
			buffer[(pos - 6144)*8    ].set(8, val.data.bit(0));
			buffer[(pos - 6144)*8 + 1].set(8, val.data.bit(1));
			buffer[(pos - 6144)*8 + 2].set(8, val.data.bit(2));
			buffer[(pos - 6144)*8 + 3].set(8, val.data.bit(3));
			buffer[(pos - 6144)*8 + 4].set(8, val.data.bit(4));
			buffer[(pos - 6144)*8 + 5].set(8, val.data.bit(5));
			buffer[(pos - 6144)*8 + 6].set(8, val.data.bit(6));
			buffer[(pos - 6144)*8 + 7].set(8, val.data.bit(7));
		}
		pos++;
	} while(!val.last);

}

static void framemux_stream(hls::stream<ap_uint<9> > &output, ap_uint<9> *buffer)
{
//#pragma HLS inline
	ap_uint<13> pos = 0;
	ap_uint<8> val;
	do {
#pragma HLS loop_tripcount min=6912 max=6912 avg=6912
		if(pos < 6144) {
			val = buffer[pos].range(7,0);
		} else {
#if 1
			val.set(0, buffer[(pos - 6144)*8    ].bit(8));
			val.set(1, buffer[(pos - 6144)*8 + 1].bit(8));
			val.set(2, buffer[(pos - 6144)*8 + 2].bit(8));
			val.set(3, buffer[(pos - 6144)*8 + 3].bit(8));
			val.set(4, buffer[(pos - 6144)*8 + 4].bit(8));
			val.set(5, buffer[(pos - 6144)*8 + 5].bit(8));
			val.set(6, buffer[(pos - 6144)*8 + 6].bit(8));
			val.set(7, buffer[(pos - 6144)*8 + 7].bit(8));
#else
			val      = (buffer[(pos - 6144)*8 + 7].bit(8), buffer[(pos - 6144)*8 + 6].bit(8), buffer[(pos - 6144)*8 + 5].bit(8), buffer[(pos - 6144)*8 + 4].bit(8),
						buffer[(pos - 6144)*8 + 3].bit(8), buffer[(pos - 6144)*8 + 2].bit(8), buffer[(pos - 6144)*8 + 1].bit(8), buffer[(pos - 6144)*8    ].bit(8)
			);
#endif
		}
		output.write(val);

		fin_cnt_9--;
		if(fin_cnt_9==0)
			fin_cnt_9=384;

		pos++;
	} while(pos<6912);

}

static ap_uint<7> FC_NST=0;
static ap_uint<7> SUBCH_COUNT=0;
static ap_uint<3> FC_FP01=0;

//orig:160-429-267-0-9-10

//131-433-267-0-9-10
//130-432-267-0-9-10
void framemux(hls::stream<u8stream > &input, hls::stream<ap_uint<9> > &output)
{
#pragma HLS ARRAY_PARTITION variable=cif_buffer_9_0 block factor=3 dim=1
#pragma HLS ARRAY_PARTITION variable=cif_buffer_9_1 block factor=3 dim=1
#pragma HLS ARRAY_PARTITION variable=cif_buffer_9_2 block factor=3 dim=1

//#pragma HLS ARRAY_MAP variable=cif_buffer_9 instance=packed0 vertical


#pragma HLS INTERFACE ap_fifo port=input
#pragma HLS INTERFACE ap_fifo port=output
//#pragma HLS RESOURCE variable=input  core=AXIS metadata="-bus_bundle S_AXIS"
//#pragma HLS RESOURCE variable=output core=AXIS metadata="-bus_bundle M_AXIS"
#pragma HLS INTERFACE ap_ctrl_none port=return

	u8stream val = input.read();
	const ap_uint<8> block_type = val.data;

	//0 0 91 149
  switch(block_type) {
	case 0xC1:
	case 0xFA:
	{
		/******************************************************************************************
		 * CIF Staff
		 ******************************************************************************************/
		ap_uint<3> i = 0;
		ap_uint<32> temp_buff_STC;
		do {
			val = input.read();
			temp_buff_STC = temp_buff_STC << 8 | val.data;
			i++;
		} while (i<4);

#ifndef  __SYNTHESIS__
		fprintf(stderr, "[HARD FPGA] subchannel[%d]: id=%d SAD=%d\n", (uint8_t)SUBCH_COUNT, (uint8_t)temp_buff_STC.range(31,26), (uint16_t)temp_buff_STC.range(25,16) * 8);
#endif
		switch(FC_FP01) {
		case 0:
			framemux_fill_pos(input, temp_buff_STC.range(25,16), cif_buffer_9_0);
			break;
		case 1:
			framemux_fill_pos(input, temp_buff_STC.range(25,16), cif_buffer_9_1);
			break;
		case 2:
			framemux_fill_pos(input, temp_buff_STC.range(25,16), cif_buffer_9_2);
			break;
		case 3:
			/* HACK: re-use cif_buffer_9_0 storage, since we send it's content during FIC reception phase */
			framemux_fill_pos(input, temp_buff_STC.range(25,16), cif_buffer_9_0);
			SUBCH_COUNT++;
			if(SUBCH_COUNT > FC_NST && fin_cnt_9!=0) {
				//send 4th CIF that lives inside cif_buffer_9_0
				framemux_stream(output, cif_buffer_9_0);
			}
			break;
		}

		break;
	}

	case 0xF1: {
		/******************************************************************************************
		 * FIC Staff
		 * Sending FIC as-is, just pass fic phase as part of block type: F0/F1/F2/F3
		 ******************************************************************************************/

		ap_uint<3> i = 0;
		ap_uint<32> temp_buff_FC;
		do {
			val = input.read();
			temp_buff_FC = temp_buff_FC << 8 | val.data;
			i++;
		} while (i<4);

		FC_NST=temp_buff_FC.range(22,16);
		FC_FP01=temp_buff_FC.range(14,13);
#ifndef  __SYNTHESIS__
		fprintf(stderr, "[HARD FPGA] fic[%d]: FC_NST=%d FC_FP=%d\n", (uint16_t)temp_buff_FC.range(31,24), (uint8_t)FC_NST, (uint8_t)FC_FP01);
#endif

		if(FC_FP01 == 0x00) {
			output.write(0b100000000);
			fin_cnt_9 = 384;
		}

		do {
#pragma HLS loop_tripcount min=288 max=384 avg=288
			val = input.read();
			if(fin_cnt_9!=0) {
				fin_cnt_9--;
				if(fin_cnt_9==0) {
					fin_cnt_9=384;
				}
				output.write(val.data);
			}
		} while (!val.last);


		if(FC_FP01 == 0x03 && fin_cnt_9!=0) {
			SUBCH_COUNT=0;
			framemux_stream(output, cif_buffer_9_0);
			framemux_stream(output, cif_buffer_9_1);
			framemux_stream(output, cif_buffer_9_2);
		}
		break;
	}
  }
}
