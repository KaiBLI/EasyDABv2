
#include <ap_int.h>
#include <ap_utils.h>
#include "dab_prep.h"
/*

*/

static hls::stream<ap_uint<9> > fm2mi;
static hls::stream<ap_uint<3> > mi2dqpsk;
static hls::stream<ap_uint<6> > dqpsk2pifft;

void dab_prep(hls::stream<u8stream > &input, hls::stream<cplxi16stream > &output,
		const ap_uint<13> comb_pat_in)
{
#pragma HLS DATAFLOW

#pragma HLS STREAM variable=dqpsk2pifft depth=15
#pragma HLS STREAM variable=mi2dqpsk depth=15
#pragma HLS STREAM variable=fm2mi depth=15

#pragma HLS RESOURCE variable=dqpsk2pifft core=FIFO_SRL
#pragma HLS RESOURCE variable=fm2mi core=FIFO_SRL
#pragma HLS RESOURCE variable=mi2dqpsk core=FIFO_SRL

#pragma HLS INTERFACE ap_fifo port=input
#pragma HLS INTERFACE ap_fifo port=output

#pragma HLS DATA_PACK variable=input
#pragma HLS DATA_PACK variable=output

#pragma HLS INTERFACE ap_none port=comb_pat_in

//#pragma HLS RESOURCE variable=input  core=AXIS metadata="-bus_bundle S_AXIS"
#pragma HLS RESOURCE variable=input core=FIFO_SRL  metadata="-bus_bundle S_FIFO"
#pragma HLS RESOURCE variable=output core=AXIS metadata="-bus_bundle M_AXIS"
//#pragma HLS RESOURCE variable=output core=FIFO_SRL

#pragma HLS INTERFACE ap_ctrl_none port=return

	framemux(input, fm2mi);
	map_interleave(fm2mi, mi2dqpsk);
	dqpsk_modulator(mi2dqpsk, dqpsk2pifft, comb_pat_in);
	pre_ifft_reord(dqpsk2pifft, output);
}

