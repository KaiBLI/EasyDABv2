

#include <ap_int.h>
#include <ap_utils.h>
#include "dab_prep.h"





typedef struct {
	ap_int<3> real;
	ap_int<3> imag;
} cint3;

typedef struct {
//	cint3	   data;
	ap_uint<6> data;
	ap_uint<1> dest;
	ap_uint<1> last;
} cplxi3stream;



typedef struct {
	ap_int<16> real;
	ap_int<16> imag;
} cint16;


const ap_int<16> f_tab[4] = { 0, 32767, 23170, 5193 }; //last one - is amplitude of TII (1:48)

const ap_int<16> remap_int(ap_int<3> x)
{
#pragma HLS inline
#pragma HLS ARRAY_PARTITION variable=f_tab complete dim=1
	if(x<0)
		return -(f_tab[-(x)]);
	else
		return f_tab[x];
}

const ap_uint<32> remap_int2(ap_uint<6> x)
{
#pragma HLS inline
#if 1
	ap_int<3> re=x.range(2,0);
	ap_int<3> im=x.range(5,3);
	cint16 o;
	o.real = remap_int(re);
	o.imag = remap_int(im);
	ap_uint<32> *dO = (ap_uint<32> *) &o;

	return (*dO);
//reinterpret_cast<ap_uint<32>*>
#else
	return ((ap_uint<16>)remap_int((ap_int<3>)x.range(2,0)), (ap_uint<16>)remap_int((ap_int<3>)x.range(5,3)));
#endif
}

//21-74-45
//22-68-38
//22-71-38
void pre_ifft_reord(hls::stream<ap_uint<6> > &input, hls::stream<cplxi16stream> &output)
{
#pragma HLS INTERFACE ap_fifo port=input
#pragma HLS INTERFACE ap_fifo port=output

//#pragma HLS DATA_PACK variable=output
//#pragma HLS RESOURCE variable=input  core=AXIS metadata="-bus_bundle S_AXIS"
//#pragma HLS RESOURCE variable=output core=AXIS metadata="-bus_bundle M_AXIS"
//#pragma HLS INTERFACE axis port=input
//#pragma HLS INTERFACE axis port=output

//#pragma HLS INTERFACE ap_ctrl_none port=return
//#pragma HLS PIPELINE off
//#pragma HLS DATAFLOW
//#pragma HLS PIPELINE II=1
#pragma HLS INTERFACE ap_ctrl_none port=return


	ap_uint<12> i;
	ap_uint<6> x;
	cplxi16stream y;
#if 0
	//101-273-165-0-2-6

	if(!input.empty()) {
		x = input.read(); //data=0 -> -0.7071, data=1 -> 0.7071
		LOOP11:for(i = 0; i < 2048; i++) {
	#pragma HLS loop_tripcount min=2048 max=2048 avg=2048
#if 1
			if(i==0) {
				/* zero frequency */
				y.data = 0; //will be 0 or 1
				y.last = 0;
				output.write(y); i++;
				//output.write((cplxi16stream){0,0}); i++;
				//output.write({0,0}); i++;
			} else if (i < 769) {
				x = input.read();
			} else if(i < 1280){
				x = 0;
			} else {
				x = input.read();
			}
#else
			if(i==0) {
				/* zero frequency */
				y.data = 0; //will be 0 or 1
				y.last = 0;
				output.write(y); i++;
				//output.write((cplxi16stream){0,0}); i++;
				//output.write({0,0}); i++;
			} else if (i < 769 || (i >= 1280)) {
				x = input.read();
			} else {
				x = 0;
			}
#endif
			y.data = remap_int2(x);
			y.last = (i==2047) ? 1 : 0;
			output.write(y);
		}
	}
#else


    if(!input.empty()) {
        //106-258-162-0-2-6
        //96-233-160-0-2-6
        //87-244-161-0-2-6
    	//98-246-161-0-2-6
        LOOP11:for(i = 0; i < 2048; i++) {
#pragma HLS loop_tripcount min=2048 max=2048 avg=2048
        	if(i!=0 && (i < 769 || (i >= 1280))) {
        		//1...768, 1280...2047: 0...767, 0...767
        		x = input.read();
            } else {
            	x = 0;
            }
                y.last = (i==2047) ? 1 : 0;
                y.data = remap_int2(x);
                output.write(y);
        }
    }

#endif
}
