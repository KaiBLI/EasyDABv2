

#include <ap_int.h>
#include <ap_utils.h>
#include <hls_stream.h>

enum {
	I3_ZERO=0,
	I3_ONE,
	I3_07071,
	I3_05,
};

enum {
	UI1_MINUS07071=0,
	UI1_PLUS07071
};



typedef struct {
	ap_uint<32> data;
	ap_uint<1>  last;
} cplxi16stream;

typedef struct {
	ap_uint<8> data;
	ap_uint<1> last;
} u8stream;

void framemux(hls::stream<u8stream > &input, hls::stream<ap_uint<9> > &output);
void map_interleave(hls::stream<ap_uint<9> > &input, hls::stream<ap_uint<3> > &output);
void dqpsk_modulator(hls::stream<ap_uint<3> > &input, hls::stream<ap_uint<6> > &output, const ap_uint<13> comb_pat);
void pre_ifft_reord(hls::stream<ap_uint<6> > &input, hls::stream<cplxi16stream> &output);
