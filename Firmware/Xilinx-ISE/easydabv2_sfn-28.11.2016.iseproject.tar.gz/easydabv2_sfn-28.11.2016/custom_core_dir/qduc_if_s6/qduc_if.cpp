#include <ap_int.h>
#include <ap_utils.h>
#include <hls_stream.h>

#if 0

static ap_uint<20> samples_cnt;
static bool ts_readed = true;
static ap_uint<42> ts;
static ap_uint<42> val2;
static ap_uint<36> val;
static bool sfn_en_n_val=false;


//73-176-136
void qduc_if(
		//HLS stream
		hls::stream<ap_uint<36> > &input,
		//QDUC
		hls::stream<ap_uint<18> > &out,
		hls::stream<ap_uint<8> > &tist,
		volatile ap_uint<42> *cnt,
		volatile bool *sfn_en_n,
		volatile ap_uint<14> *sfn_delay
//		volatile bool *out_enable,
//		volatile bool *out_clk,
//		volatile bool *fifo_empty
)
{

//#pragma HLS INTERFACE ap_none port=out bundle=QDUC
//#pragma HLS INTERFACE ap_none port=out_enable bundle=QDUC
//#pragma HLS INTERFACE ap_none port=out_clk bundle=QDUC

//#pragma HLS INTERFACE ap_none port=tist bundle=QDUC
//#pragma HLS INTERFACE ap_none port=fifo_empty bundle=FIFO

#pragma HLS INTERFACE ap_none port=cnt bundle=QDUC
#pragma HLS INTERFACE ap_none port=sfn_en_n
#pragma HLS INTERFACE ap_none port=sfn_delay

//#pragma HLS INTERFACE ap_fifo port=input
#pragma HLS INTERFACE axis port=input
//#pragma HLS RESOURCE variable=input  core=AXIS metadata="-bus_bundle S_AXIS"

#pragma HLS INTERFACE axis port=out
//#pragma HLS RESOURCE variable=out  core=AXIS metadata="-bus_bundle M_AXIS"
#pragma HLS INTERFACE axis port=tist
//#pragma HLS INTERFACE ap_fifo port=tist
//#pragma HLS RESOURCE variable=tist  core=AXIS metadata="-bus_bundle S_TIME_AXIS"

#pragma HLS INTERFACE ap_ctrl_none port=return


#if 0
  while(1) {

	if(!input.empty()) {
		val = input.read();
		*out_enable = true;
	} else {
		*out_enable = false;
	}
	ap_wait_until(((bool)*out_clk) == true);
	*out = val.range(17,0);
	ap_wait_until(((bool)*out_clk) == false);
	ap_wait_until(((bool)*out_clk) == true);
	*out = val.range(35,18);
	ap_wait_until(((bool)*out_clk) == false);
  }
#endif

#if 0
  ap_wait_until(((bool)*out_clk) == false);
  ap_wait_until(((bool)*out_clk) == true);

  while(1) {

	  *out_enable = input.read_nb(val);
	  *out = val.range(17,0);
	  ap_wait_until(((bool)*out_clk) == false);
	  ap_wait_until(((bool)*out_clk) == true);
	  *out = val.range(35,18);
	  ap_wait_until(((bool)*out_clk) == false);
	  ap_wait_until(((bool)*out_clk) == true);
  }
#endif

  //
  //frequency: 16mhz (8kS/s)
  //((2048+504)*76+(2048+608))/2048000 = 96ms
  //((2048+504)*76 * 125/32 + (2048+608) * 125/32) / 8000000 = 96ms
  //((2048+504)*76 * 3 + (2048+608) * 3) / 6144000 = 96ms

  //send 4150 zeroes between each 303050 total samples: 307200samp.

  //((2048+504)*76 * 3 + (2048+608) * 3) / 6144000
  //send 7968 zeroes between each 581856 total samples: 589824samp.





//=======================================================================
//   WORKS OK!!!!!!!!!!!!!!!!
//=======================================================================
#if 0
  ap_uint<20> samples_cnt = 0;
  while(1) {
	  if(samples_cnt < 4150) {
		  ap_wait_n(2);
      } else {
    	  ap_uint<36> val = input.read();
		  out.write(val.range(17,0));
		  out.write(val.range(35,18));
	  }

	  samples_cnt++;
	  if(samples_cnt >= 307200) samples_cnt = 0;
  }
#endif

  //=======================================================================
  //   WORKS OK!!!!!!!!!!!!!!!!
  //   Without TIST!!!!!!
  //=======================================================================
#if 0
  bool ts_readed = false;
  ap_uint<10> ts;
  LOOP0:while(1) {
//	  ap_uint<10> ts = 0x3FF;
	  if(!ts_readed) {
		  ts = tist.read();
	  	  ts = ts << 8 | tist.read();
	  	  ts_readed = true;
	  }
	  ap_uint<10> val2 = (ap_uint<10>) *cnt;
	  ap_wait_n(2);

	  if(/*ts == val2 ||*/ ts == 0x3FF) {
//	  if(((bool) *fifo_empty) == false) {
//		  ap_wait();
		  ap_uint<20> samples_cnt = 0;
		  LOOP0_1:do {
#pragma HLS loop_tripcount min=303050 max=303050 avg=303050
			  ap_uint<36> val = input.read();
			  out.write(val.range(17,0));
			  out.write(val.range(35,18));
			  samples_cnt++;
		  } while(samples_cnt < (307200-4150));

		  LOOP0_2:while(ts == 0x3FF && samples_cnt < (307200 - 2)) {
#pragma HLS loop_tripcount min=4148 max=4148 avg=4148
			  ap_wait_n(2);
			  samples_cnt++;
		  };
		  ts_readed = false;
	  } /*else if(val2 > ts && ts > 0x60) {
		  ap_uint<20> samples_cnt = 0;
		  LOOP0_1:do {
			  input.read();
			  samples_cnt++;
		  } while(samples_cnt < (307200-4150));
		  ts_readed = false;
	  }*/
		  //	  samples_cnt++;
		  //	  if(samples_cnt >= 307200) samples_cnt = 0;
	}
#endif


#if 0
//  ap_uint<7> ts_val_readed = 0;
  ap_uint<7> ts_val_readed = 0;
  ap_uint<64> ts;

  ap_wait();

  LOOP0:while(1) {
//	  ap_uint<10> ts = 0x3FF;
	  while(ts_val_readed < 64) {
#pragma HLS loop_tripcount min=8 max=8 avg=8
		  ts = ((ap_uint<64>) tist.read())<< (ts_val_readed);
		  ts_val_readed+=8;
	  }
	  ap_uint<64> val2 = (ap_uint<64>) *cnt;
//	  ap_wait_n(2);

	  if(((ts & 0xFFFF) == 0x3FF || ts == val2) && !input.empty()) {
//	  if(((bool) *fifo_empty) == false) {
//		  ap_wait();
		  ap_uint<20> samples_cnt = 0;
		  LOOP0_1:do {
#pragma HLS loop_tripcount min=303050 max=303050 avg=303050
			  ap_uint<36> val = input.read();
			  out.write(val.range(17,0));
			  out.write(val.range(35,18));
			  samples_cnt++;
		  } while(samples_cnt < (307200-4150));

//		  LOOP0_2:while((ts & 0xFFFF) == 0x3FF && samples_cnt < (307200 - 2)) {
		  LOOP0_2:while((ts & 0xFFFF) == 0x3FF && samples_cnt < (307200 - 8)) {
//#pragma HLS loop_tripcount min=4148 max=4148 avg=4148
#pragma HLS loop_tripcount min=4142 max=4142 avg=4142
			  ap_wait_n(2);
			  samples_cnt++;
		  };
		  ts_val_readed = 0;
//	  } else if(val2 > ts && ts > 0x60) {
	  } else if(val2 > ts) {
		  ap_uint<20> samples_cnt = 0;
		  LOOP0_3:do {
			  input.read();
			  samples_cnt++;
		  } while(samples_cnt < (307200-4150));
		  ts_val_readed = 0;
	  }
		  //	  samples_cnt++;
		  //	  if(samples_cnt >= 307200) samples_cnt = 0;
	}
#endif

#if 1
//  ap_uint<7> ts_val_readed = 0;
// FIXME: skip first content to prevent timestamp stucking...
//  bool ts_readed = false;
//  ap_uint<64> ts;

  ap_wait();

  ts_readed = true;
  ts = 0;

  LOOP0:while(1) {
//	  ap_uint<10> ts = 0x3FF;
	  if(!ts_readed) {
#if 1
#if 1
		  ap_uint<8> ts0 = tist.read();//usec LSB
		  ap_uint<2> ts1 = tist.read();//usec MSB
		  ap_uint<11> ts_ms = (ts1, ts0);
		  ap_uint<14> sfn_delay_val = (ap_uint<14>) *sfn_delay;
		  //if(((bool) *sfn_en_n) == true) { ts0 = 0xFF; ts1 = 0b11; }
		  ap_uint<1> ts_1s_add = 0;
		  if(ts_ms != 0x3FF) {
			  if(((bool) *sfn_en_n) == true) {
				  ts_ms = 0x3FF;
			  } else {
				  ts_ms += sfn_delay_val.range(9,0);
				  if(ts_ms >= 1000) {
					  ts_ms -= 1000;
					  ts_1s_add = 1;
				  }
			  }
		  }
		  ap_uint<8> ts2 = tist.read();//32bit
		  ap_uint<8> ts3 = tist.read();//32bit
		  ap_uint<8> ts4 = tist.read();//32bit
		  ap_uint<8> ts5 = tist.read();//32bit
		  ap_uint<32> ts_s = (ts5, ts4, ts3, ts2) + sfn_delay_val.range(13,10) + ts_1s_add;

		  ts = (ts_s, ts_ms.range(9,0));
//		  ts = (ap_uint<64>) (((ap_uint<64>)ts7)<<56) | (((ap_uint<56>)ts6)<<48) | (((ap_uint<48>)ts5)<<40) |(((ap_uint<40>)ts4)<<32) | (((ap_uint<32>)ts3)<<24) | (((ap_uint<24>)ts2)<<16) | (((ap_uint<16>)ts1)<<8) | ts0;
#else
		  ts = tist.read();
		  ts |=  ((ap_uint<16>)tist.read()) << 8;
		  ts |=  ((ap_uint<24>)tist.read()) << 16;
		  ts |=  ((ap_uint<32>)tist.read()) << 24;
		  ts |=  ((ap_uint<40>)tist.read()) << 32;
		  ts |=  ((ap_uint<48>)tist.read()) << 40;
		  ts |=  ((ap_uint<56>)tist.read()) << 48;
		  ts |=  ((ap_uint<64>)tist.read()) << 56;
#endif
#endif

#if 0
		  ap_uint<4> ts_val_readed;
		  ts = 0;
		  LOOP0_111:for(ts_val_readed=0; ts_val_readed < 8; ts_val_readed++) {
#pragma HLS loop_tripcount min=8 max=8 avg=8
			  ts |= ((ap_uint<64>) tist.read()) << (((ap_uint<7>)ts_val_readed) << 3);
		  }
#endif
//		  ap_uint<8> ts0 = tist.read();
//		  ap_uint<8> ts1 = tist.read();
//		  ts = (ap_uint<64>) (((ap_uint<16>)ts1)<<8) | ts0;
		  ts_readed = true;
	  }
	  val2 = (ap_uint<43>) *cnt;
//	  ap_wait_n(2);

	  if((ts.range(9,0) == 0x3FF || ts == val2) && !input.empty()) {
//	  if(((bool) *fifo_empty) == false) {
//		  ap_wait();
		  samples_cnt = 0;
		  LOOP0_1:do {
#pragma HLS loop_tripcount min=581856 max=581856 avg=581856
			  val = input.read();
			  out.write(val.range(17,0));
			  out.write(val.range(35,18));
			  samples_cnt++;
		  } while(samples_cnt < (589824-7968));

//		  LOOP0_2:while((ts & 0xFFFF) == 0x3FF && samples_cnt < (307200 - 2)) {
		  LOOP0_2:while((ts.range(9,0) == 0x3FF) && samples_cnt < (589824 - 8)) {
//#pragma HLS loop_tripcount min=4148 max=4148 avg=4148
#pragma HLS loop_tripcount min=7960 max=7960 avg=7960
			  ap_wait_n(2);
			  samples_cnt++;
		  };
		  ts_readed = false;
//	  } else if(val2 > ts && ts > 0x60) {
	  } else if(val2 > ts) {
		  samples_cnt = 0;
		  LOOP0_3:do {
#pragma HLS loop_tripcount min=581856 max=581856 avg=581856
			  input.read();
			  samples_cnt++;
		  } while(samples_cnt < (589824-7968));
		  ts_readed = false;
	  }
		  //	  samples_cnt++;
		  //	  if(samples_cnt >= 307200) samples_cnt = 0;
	}
#endif



#if 0
  ap_uint<20> samples_cnt = 0;
  while(1) {
	  if(samples_cnt < (307200-4150)) {
    	  ap_uint<36> val = input.read();
		  out.write(val.range(17,0));
		  out.write(val.range(35,18));
      } else {
		  ap_wait_n(2);
	  }

	  samples_cnt++;
	  if(samples_cnt >= 307200) samples_cnt = 0;
  }
#endif
}

#endif










static ap_uint<20> samples_cnt;
static bool ts_readed = true;
static ap_uint<44> ts;
static ap_uint<44> val2;
static ap_uint<36> val;
//static bool sfn_en_n_val=false;

static const ap_uint<2> ns_addon = 0b01;

//42bit:  7-223-146
//44bit: 75 225 147
void qduc_if(
		//HLS stream
		hls::stream<ap_uint<36> > &input,
		//QDUC
		hls::stream<ap_uint<18> > &out,
		hls::stream<ap_uint<8> > &tist,
		volatile ap_uint<44> *cnt,
		volatile bool *sfn_en_n,
		volatile ap_uint<14> *sfn_delay
//		volatile bool *out_enable,
//		volatile bool *out_clk,
//		volatile bool *fifo_empty
)
{
//#pragma HLS INTERFACE ap_none port=out bundle=QDUC
//#pragma HLS INTERFACE ap_none port=out_enable bundle=QDUC
//#pragma HLS INTERFACE ap_none port=out_clk bundle=QDUC
//#pragma HLS INTERFACE ap_none port=tist bundle=QDUC
//#pragma HLS INTERFACE ap_none port=fifo_empty bundle=FIFO
#pragma HLS INTERFACE ap_none port=cnt bundle=QDUC
#pragma HLS INTERFACE ap_none port=sfn_en_n
#pragma HLS INTERFACE ap_none port=sfn_delay

#pragma HLS INTERFACE ap_fifo port=input
//#pragma HLS INTERFACE axis port=input
//#pragma HLS RESOURCE variable=input  core=AXIS metadata="-bus_bundle S_AXIS"

//#pragma HLS INTERFACE axis port=out
#pragma HLS INTERFACE ap_fifo port=out
//#pragma HLS RESOURCE variable=out  core=AXIS metadata="-bus_bundle M_AXIS"
//#pragma HLS INTERFACE axis port=tist
#pragma HLS INTERFACE ap_fifo port=tist
//#pragma HLS RESOURCE variable=tist  core=AXIS metadata="-bus_bundle S_TIME_AXIS"

#pragma HLS INTERFACE ap_ctrl_none port=return

#if 0
	//old logic:
  //frequency: 16mhz (8kS/s)
  //((2048+504)*76+(2048+608))/2048000 = 96ms
  //((2048+504)*76 * 125/32 + (2048+608) * 125/32) / 8000000 = 96ms
  //((2048+504)*76 * 3 + (2048+608) * 3) / 6144000 = 96ms

  //send 4150 zeroes between each 303050 total samples: 307200samp.

  //((2048+504)*76 * 3 + (2048+608) * 3) / 6144000
  //send 7968 zeroes between each 581856 total samples: 589824samp.

//  ap_uint<7> ts_val_readed = 0;
// FIXME: skip first content to prevent timestamp stucking...
//  bool ts_readed = false;
//  ap_uint<64> ts;
#else
	//new logic:
	  //frequency: 16mhz (8kS/s)
	  //((2048+504)*77+(608-504))/2048000 = 96ms
	  //((2048+504)*77 * 3 + (608-504) * 3) / 6144000 = 96ms
	  //send (7968-7656 =) 312 zeroes between each (581856+7656 =) 589512 total samples: 589824samp.
#endif

  ap_wait();

  ts_readed = true;
  ts = 0;

  LOOP0:while(1) {
//	  ap_uint<10> ts = 0x3FF;
	  if(!ts_readed) {

		  ap_uint<8> ts0 = tist.read();//usec LSB
		  ap_uint<2> ts1 = tist.read();//usec MSB
		  ap_uint<11> ts_ms = (ts1, ts0);
		  ap_uint<14> sfn_delay_val = (ap_uint<14>) *sfn_delay;
		  //if(((bool) *sfn_en_n) == true) { ts0 = 0xFF; ts1 = 0b11; }
		  ap_uint<1> ts_1s_add = 0;
		  if(ts_ms != 0x3FF) {
			  if(((bool) *sfn_en_n) == true) {
				  ts_ms = 0x3FF;
			  } else {
				  ts_ms += sfn_delay_val.range(9,0);
				  if(ts_ms >= 1000) {
					  ts_ms -= 1000;
					  ts_1s_add = 1;
				  }
			  }
		  }
		  ap_uint<8> ts2 = tist.read();//32bit
		  ap_uint<8> ts3 = tist.read();//32bit
		  ap_uint<8> ts4 = tist.read();//32bit
		  ap_uint<8> ts5 = tist.read();//32bit
		  ap_uint<32> ts_s = (ts5, ts4, ts3, ts2) + sfn_delay_val.range(13,10) + ts_1s_add;

		  ts = (ts_s, ts_ms.range(9,0), ns_addon);
//		  ts = (ap_uint<64>) (((ap_uint<64>)ts7)<<56) | (((ap_uint<56>)ts6)<<48) | (((ap_uint<48>)ts5)<<40) |(((ap_uint<40>)ts4)<<32) | (((ap_uint<32>)ts3)<<24) | (((ap_uint<24>)ts2)<<16) | (((ap_uint<16>)ts1)<<8) | ts0;

//		  ap_uint<8> ts0 = tist.read();
//		  ap_uint<8> ts1 = tist.read();
//		  ts = (ap_uint<64>) (((ap_uint<16>)ts1)<<8) | ts0;
		  ts_readed = true;
	  }
	  val2 = (ap_uint<44>) *cnt;
//	  ap_wait_n(2);

	  if((ts.range(11,2) == 0x3FF || ts == val2) && !input.empty()) {
//	  if(((bool) *fifo_empty) == false) {
//		  ap_wait();
		  samples_cnt = 0;
		  LOOP0_1:do {
#pragma HLS loop_tripcount min=589512 max=589512 avg=589512
			  val = input.read();
			  out.write(val.range(17,0));
			  out.write(val.range(35,18));
			  samples_cnt++;
		  } while(samples_cnt < (589824-312));

//		  LOOP0_2:while((ts & 0xFFFF) == 0x3FF && samples_cnt < (307200 - 2)) {
		  LOOP0_2:while((ts.range(11,2) == 0x3FF) && samples_cnt < (589824 - 8)) {
//#pragma HLS loop_tripcount min=4148 max=4148 avg=4148
#pragma HLS loop_tripcount min=304 max=304 avg=304
			  ap_wait_n(2);
			  samples_cnt++;
		  };
		  ts_readed = false;
//	  } else if(val2 > ts && ts > 0x60) {
	  } else if(val2 > ts) {
		  samples_cnt = 0;
		  LOOP0_3:do {
#pragma HLS loop_tripcount min=589512 max=589512 avg=589512
			  input.read();
			  samples_cnt++;
		  } while(samples_cnt < (589824-312));
		  ts_readed = false;
	  }
		  //	  samples_cnt++;
		  //	  if(samples_cnt >= 307200) samples_cnt = 0;
	}


}
