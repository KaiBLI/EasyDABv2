
#include <ap_int.h>
#include <ap_utils.h>
#include <hls_stream.h>

typedef struct {
	ap_uint<8> data;
	ap_uint<1> last;
} u8stream;

/**************************************************************************************************
 * THIS WORKS FINE, but needs BRAM optimizations!
 **************************************************************************************************/


/**************************************************************************************************
OPTIMIZATIONS:

NONE:
#=== Resource usage ===
SLICE:          165
LUT:            446
FF:             406
DSP:              0
BRAM:             3
SRL:              0


#pragma HLS ARRAY_PARTITION variable=rules_data_val complete dim=1
#=== Resource usage ===
SLICE:          145
LUT:            476
FF:             406
DSP:              0
BRAM:             3
SRL:              0
#pragma HLS ARRAY_PARTITION variable=bitrates_in_cu_data complete dim=1
#=== Resource usage ===
SLICE:          201
LUT:            504
FF:             403
DSP:              0
BRAM:             2
SRL:              0

**************************************************************************************************/


//#define AESL_TB

enum {
	P1=0,
	P2,
	P3,
	P4,
	P5,
	P6,
	P7,
	P8,
	P9,
	P10,
	P11,
	P12,
	P13,
	P14,
	P15,
	P16,
	P17,
	P18,
	P19,
	P20,
	P21,
	P22,
	P23,
	P24
} rulen_num;



const ap_uint<8> packed_data[(280)+(280+18)+(14)] = {
	//sizes_data[280] :
	3,5,13,3,		3,4,14,3,		3,4,14,3,		3,3,18,0,		3,4,17,0,
	3,5,25,3,		3,4,26,3,		3,4,26,3,		3,4,26,3,		3,4,26,3,
	0,0,0,0,		6,10,23,3,		6,12,21,3,		6,10,23,3,		6,10,23,3,
	6,11,28,3,		6,10,29,3,		6,12,27,3,		6,9,33,0,		6,9,31,2,
	6,10,41,3,		6,10,41,3,		6,11,40,3,		6,10,41,3,		6,10,41,3,
	6,13,50,3,		6,10,53,3,		6,12,51,3,		7,10,52,3,		7,9,53,3,
	0,0,0,0,		11,21,49,3,		11,23,47,3,		11,21,49,3,		14,17,50,3,
	11,20,62,3, 	11,21,61,3,		11,22,60,3,		11,21,61,3,		12,19,62,3,
	11,22,84,3, 	11,21,85,3,		11,24,82,3,		11,23,83,3,		11,19,87,3,
	11,21,109,3,	11,20,110,3,	11,24,106,3,	11,22,108,3,	11,20,110,3,
	11,24,130,3,	11,22,132,3,	11,20,134,3,	12,26,127,3,	12,22,131,3,
	11,26,152,3,	11,22,156,3,	11,27,151,3,	11,24,154,3,	11,24,154,3,
	0,0,0,0,		11,26,200,3,	0,0,0,0,		11,25,201,3,	11,26,200,3,
	12,28,245,3,	0,0,0,0,		11,24,250,3,	0,0,0,0,		11,27,247,3,
	//rules_data[280+18]
	P24,P17,P12,P17,	P22,P13,P8,P13,		P15,P9,P6,P8,	P11,P6,P5,0,	P5,P3,P2,0,
	P24,P18,P13,P18,	P24,P14,P8,P15,		P15,P10,P6,P9,	P9,P6,P4,P6,	P5,P4,P2,P3,
	0,0,0,0, 			P23,P13,P8,P13,		P16,P7,P6,P9,	P9,P6,P4,P5,	P5,P4,P2,P3,
	P24,P18,P12,P18,	P23,P13,P8,P13,		P16,P8,P6,P9,	P11,P6,P5,0,	P5,P3,P2,P3,
	P24,P17,P12,P18,	P23,P13,P8,P13,		P16,P8,P6,P7,	P11,P6,P5,P6,	P6,P3,P2,P3,
	P24,P18,P13,P19,	P22,P12,P9,P12,		P16,P9,P6,P10,	P9,P6,P4,P6,	P5,P4,P2,P4,
	0,0,0,0,			P23,P12,P9,P14,		P16,P8,P6,P9,	P9,P6,P4,P8,	P5,P4,P2,P5,
	P24,P17,P13,P19,	P22,P12,P9,P14,		P16,P9,P6,P10,	P11,P6,P5,P7,	P5,P3,P2,P4,
	P24,P18,P12,P19,	P22,P11,P9,P13,		P16,P8,P6,P11,	P11,P6,P5,P9,	P5,P4,P2,P4,
	P24,P20,P13,P24,	P22,P13,P9,P13,		P16,P10,P6,P11,	P10,P6,P4,P9,	P6,P4,P2,P5,
	P24,P20,P12,P20,	P24,P16,P10,P15,	P16,P10,P7,P9,	P12,P8,P4,P11,	P8,P6,P2,P6,
	P24,P19,P14,P18,	P24,P14,P10,P13,	P16,P10,P7,P10,	P12,P9,P5,P10,	P6,P5,P2,P5,
	0,0,0,0,			P24,P17,P9,P17,		0,0,0,0,		P13,P9,P5,P10,	P8,P5,P2,P6,
	P24,P20,P14,P23,	0,0,0,0,			P16,P9,P7,P10,	0,0,0,0,		P8,P6,P2,P7,
	/* 18 x EEP rules: */
	P24,P23,	P14,P13,	P8,P7,	P3,P2,
	P10,P9,		P6,P5,		P4,P3,	P2,P1,
	P13,P12, /* <== (bitrate_in_cu = 1 && protectionLevel == 1 && protectionOption == 0) */
	//bitrates_in_cu_data[14]
	4,6,7,8,10,12,14,16,20,24,28,32,40,48
};






#if 0
typedef struct {
	ap_uint<8> FCT;
	ap_uint<1> FICF;
	ap_uint<7> NST;
	ap_uint<3> FP;
	ap_uint<2> MID;
	ap_uint<11> FL;
} FC_t;

static FC_t FC;

void bytes2fc(hls::stream<u8stream > &input, FC_t *result)
{
#pragma HLS inline
	ap_uint<32> buff=0;
	for(ap_uint<3> i = 0; i<4; i++) {
		u8stream val = input.read();
		buff = buff << 8 | val.data;
	}
#ifndef  __SYNTHESIS__
	fprintf(stderr, "[HARD] buff=0x%08x\n", (uint32_t)buff);
#endif
	result->FCT = buff.range(31,24);
	result->FICF = buff.bit(23);
	result->NST = buff.range(22,16);
	result->FP = buff.range(15,13);
	result->MID = buff.range(12,11);
	result->FL = buff.range(10,0);
}
#endif


#if 0
typedef struct {
	ap_uint<6> SCID;
	ap_uint<10> SAD;
	ap_uint<6> TPL;
	ap_uint<10> STL;
} STC_t;

static STC_t STC;



void bytes2stc(hls::stream<u8stream > &input, STC_t *result)
{
#pragma HLS inline
	ap_uint<32> buff=0;
	for(ap_uint<3> i = 0; i<4; i++) {
		u8stream val = input.read();
		buff = buff << 8 | val.data;
	}
#ifndef  __SYNTHESIS__
	fprintf(stderr, "[HARD] buff=0x%08x\n", (uint32_t)buff);
#endif
	result->SCID = buff.range(31,26);
	result->SAD = buff.range(25,16);
	result->TPL = buff.range(15,10);
	result->STL = buff.range(9,0);
//	STC_t data = *((STC_t *) &buff);
//	fprintf(stderr, "[HARD] data: scid=%d, sad=%d, tpl=0x%02x, stl=%d\n",
//			(int) data.SCID, (int) data.SAD, (int) data.TPL, (int) data.STL);
}
#else
static ap_uint<6> STC_TPL;
static ap_uint<10> STC_STL;
#endif

//const rules_t FIC_RULES_288[3] = { {336, 0xeeeeeeee}, {48, 0xeeeeeeec}, {3, 0x00cccccc} };
//rules_t CIF_RULES_963[5] = { {96, 0xeeeeeeee}, {176, 0xcccccccc}, {640, 0xccc8ccc8}, {48, 0xccccccc8}, {3, 0x00cccccc} };

//#define AESL_TB


//12bit for mask instead of 32



#if 0

enum {
	M88,
	MC8,
	MCC,
	MEC,
	MEE,
	MFE,
	MFF
} mask0;

enum {
	S0,	S2,	S3,	S4,	S5,	S6,	S7,	S9,//8
	S10, S11,	S12,	S13,	S14,	S17,	S18,	S19,//8
	S21,	S20,	S22,	S23,	S24,	S25,	S26,	S27,	S28,	S29,//10
	S31,	S33,	S40,	S41,	S47,	S49,//6
	S50,	S51,	S52,	S53,//4
	S60,	S61,	S62,//3
	S82,	S83,	S84,	S85,	S87,//5
	S106,	S108,	S109,	S110,//4
	S127,//1
	S130,	S131,	S132,	S134,//4
	S151,	S152,	S154,	S156,//4
	S200,	S201,//2
	S245,	S247,	S250//3
} sz_t;

const ap_uint<8> sizes_translation[62] = {};

const ap_uint<6> sizes_data[280] = {
	S3,S5,S13,S3,		S3,S4,S14,S3,		S3,S4,S14,S3,		S3,S3,S18,S0,		S3,S4,S17,S0,
	S3,S5,S25,S3,		S3,S4,S26,S3,		S3,S4,S26,S3,		S3,S4,S26,S3,		S3,S4,S26,S3,
	S0,S0,S0,S0,		S6,S10,S23,S3,		S6,S12,S21,S3,		S6,S10,S23,S3,		S6,S10,S23,S3,
	S6,S11,S28,S3,		S6,S10,S29,S3,		S6,S12,S27,S3,		S6,S9,S33,S0,		S6,S9,S31,S2,
	S6,S10,S41,S3,		S6,S10,S41,S3,		S6,S11,S40,S3,		S6,S10,S41,S3,		S6,S10,S41,S3,
	S6,S13,S50,S3,		S6,S10,S53,S3,		S6,S12,S51,S3,		S7,S10,S52,S3,		S7,S9,S53,S3,
	S0,S0,S0,S0,		S11,S21,S49,S3,		S11,S23,S47,S3,		S11,S21,S49,S3,		S14,S17,S50,S3,
	S11,S20,S62,S3, 	S11,S21,S61,S3,		S11,S22,S60,S3,		S11,S21,S61,S3,		S12,S19,S62,S3,
	S11,S22,S84,S3, 	S11,S21,S85,S3,		S11,S24,S82,S3,		S11,S23,S83,S3,		S11,S19,S87,S3,
	S11,S21,S109,S3,	S11,S20,S110,S3,	S11,S24,S106,S3,	S11,S22,S108,S3,	S11,S20,S110,S3,
	S11,S24,S130,S3,	S11,S22,S132,S3,	S11,S20,S134,S3,	S12,S26,S127,S3,	S12,S22,S131,S3,
	S11,S26,S152,S3,	S11,S22,S156,S3,	S11,S27,S151,S3,	S11,S24,S154,S3,	S11,S24,S154,S3,
	S0,S0,S0,S0,		S11,S26,S200,S3,	S0,S0,S0,S0,		S11,S25,S201,S3,	S11,S26,S200,S3,
	S12,S28,S245,S3,	S0,S0,S0,S0,		S11,S24,S250,S3,	S0,S0,S0,S0,		S11,S27,S247,S3,
};
#endif

#if 1
const ap_uint<8> sizes_data[280] = {
	3,5,13,3,		3,4,14,3,		3,4,14,3,		3,3,18,0,		3,4,17,0,
	3,5,25,3,		3,4,26,3,		3,4,26,3,		3,4,26,3,		3,4,26,3,
	0,0,0,0,		6,10,23,3,		6,12,21,3,		6,10,23,3,		6,10,23,3,
	6,11,28,3,		6,10,29,3,		6,12,27,3,		6,9,33,0,		6,9,31,2,
	6,10,41,3,		6,10,41,3,		6,11,40,3,		6,10,41,3,		6,10,41,3,
	6,13,50,3,		6,10,53,3,		6,12,51,3,		7,10,52,3,		7,9,53,3,
	0,0,0,0,		11,21,49,3,		11,23,47,3,		11,21,49,3,		14,17,50,3,
	11,20,62,3, 	11,21,61,3,		11,22,60,3,		11,21,61,3,		12,19,62,3,
	11,22,84,3, 	11,21,85,3,		11,24,82,3,		11,23,83,3,		11,19,87,3,
	11,21,109,3,	11,20,110,3,	11,24,106,3,	11,22,108,3,	11,20,110,3,
	11,24,130,3,	11,22,132,3,	11,20,134,3,	12,26,127,3,	12,22,131,3,
	11,26,152,3,	11,22,156,3,	11,27,151,3,	11,24,154,3,	11,24,154,3,
	0,0,0,0,		11,26,200,3,	0,0,0,0,		11,25,201,3,	11,26,200,3,
	12,28,245,3,	0,0,0,0,		11,24,250,3,	0,0,0,0,		11,27,247,3,
};
#endif



#if 0
#define P1  0xc8888888
#define P2  0xc888c888
#define P3  0xc8c8c888
#define P4  0xc8c8c8c8
#define P5  0xccc8c8c8
#define P6  0xccc8ccc8
#define P7  0xccccccc8
#define P8  0xcccccccc
#define P9  0xeccccccc
#define P10 0xeccceccc
#define P11 0xecececcc
#define P12 0xecececec
#define P13 0xeeececec
#define P14 0xeeeceeec
#define P15 0xeeeeeeec
#define P16 0xeeeeeeee
#define P17 0xfeeeeeee
#define P18 0xfeeefeee
#define P19 0xfefefeee
#define P20 0xfefefefe
#define P21 0xfffefefe
#define P22 0xfffefffe
#define P23 0xfffffffe
#define P24 0xffffffff

//const ap_uint<32> rules_data[280+32+4+4] = {
const ap_uint<32> rules_data[280] = {
	P24,P17,P12,P17,	P22,P13,P8,P13,		P15,P9,P6,P8,	P11,P6,P5,0,	P5,P3,P2,0,
	P24,P18,P13,P18,	P24,P14,P8,P15,		P15,P10,P6,P9,	P9,P6,P4,P6,	P5,P4,P2,P3,
	0,0,0,0, 			P23,P13,P8,P13,		P16,P7,P6,P9,	P9,P6,P4,P5,	P5,P4,P2,P3,
	P24,P18,P12,P18,	P23,P13,P8,P13,		P16,P8,P6,P9,	P11,P6,P5,0,	P5,P3,P2,P3,
	P24,P17,P12,P18,	P23,P13,P8,P13,		P16,P8,P6,P7,	P11,P6,P5,P6,	P6,P3,P2,P3,
	P24,P18,P13,P19,	P22,P12,P9,P12,		P16,P9,P6,P10,	P9,P6,P4,P6,	P5,P4,P2,P4,
	0,0,0,0,			P23,P12,P9,P14,		P16,P8,P6,P9,	P9,P6,P4,P8,	P5,P4,P2,P5,
	P24,P17,P13,P19,	P22,P12,P9,P14,		P16,P9,P6,P10,	P11,P6,P5,P7,	P5,P3,P2,P4,
	P24,P18,P12,P19,	P22,P11,P9,P13,		P16,P8,P6,P11,	P11,P6,P5,P9,	P5,P4,P2,P4,
	P24,P20,P13,P24,	P22,P13,P9,P13,		P16,P10,P6,P11,	P10,P6,P4,P9,	P6,P4,P2,P5,
	P24,P20,P12,P20,	P24,P16,P10,P15,	P16,P10,P7,P9,	P12,P8,P4,P11,	P8,P6,P2,P6,
	P24,P19,P14,P18,	P24,P14,P10,P13,	P16,P10,P7,P10,	P12,P9,P5,P10,	P6,P5,P2,P5,
	0,0,0,0,			P24,P17,P9,P17,		0,0,0,0,		P13,P9,P5,P10,	P8,P5,P2,P6,
	P24,P20,P14,P23,	0,0,0,0,			P16,P9,P7,P10,	0,0,0,0,		P8,P6,P2,P7
#if 0

	,P24,P23,0,0,	P14,P13,0,0,	P8,P7,0,0,	P3,P2,0,0,
	P10,P9,0,0,		P6,P5,0,0,		P4,P3,0,0,	P2,P1,0,0,
	P13,P12,0,0, /* <== (bitrate_in_cu = 1 && protectionLevel == 1 && protectionOption == 0) */
	/* FIC288 rule */
	P16,P15,0,0
#endif
};

#define ruleVal(x) x

#else





#if 0
/*
#=== Resource usage ===
SLICE:          403
LUT:           1053
FF:             546
DSP:              0
BRAM:             0
SRL:              0
*/
#if 0
const ap_uint<32> rules_data_val[24] = {
//0:0x88888888
	0xc8888888, //4 byte: |0x40
	0xc888c888, //2x16
	0xc8c8c888, //3 byte: |0x40
	0xc8c8c8c8, //2x16
	0xccc8c8c8, //4 byte: |0x04
	0xccc8ccc8, //2x16
	0xccccccc8, //3 byte: |0x04
	0xcccccccc, //2x16

	0xeccccccc, //4 byte: |0x20
	0xeccceccc, //2x16
	0xecececcc, //3 byte: |0x20
	0xecececec, //2x16
	0xeeececec, //4 byte: |0x02
	0xeeeceeec, //2x16
	0xeeeeeeec, //3 byte: |0x02
	0xeeeeeeee, //2x16

	0xfeeeeeee, //4 byte: |0x10
	0xfeeefeee, //2x16
	0xfefefeee, //3 byte: |0x10
	0xfefefefe, //2x16
	0xfffefefe, //4 byte: |0x01
	0xfffefffe, //2x16
	0xfffffffe, //3 byte: |0x01
	0xffffffff  //2x16
};

#define ruleVal(x) rules_data_val[x]
#else
const ap_uint<16> rules_data_val_hi[24] = {
//0:0x88888888
	0xc888, //4 byte: |0x40
	0xc888, //2x16
	0xc8c8, //3 byte: |0x40
	0xc8c8, //2x16
	0xccc8, //4 byte: |0x04
	0xccc8, //2x16
	0xcccc, //3 byte: |0x04
	0xcccc, //2x16

	0xeccc, //4 byte: |0x20
	0xeccc, //2x16
	0xecec, //3 byte: |0x20
	0xecec, //2x16
	0xeeec, //4 byte: |0x02
	0xeeec, //2x16
	0xeeee, //3 byte: |0x02
	0xeeee, //2x16

	0xfeee, //4 byte: |0x10
	0xfeee, //2x16
	0xfefe, //3 byte: |0x10
	0xfefe, //2x16
	0xfffe, //4 byte: |0x01
	0xfffe, //2x16
	0xffff, //3 byte: |0x01
	0xffff  //2x16
};
const ap_uint<16> rules_data_val_lo[24] = {
//0:0x88888888
	0x8888, //4 byte: |0x40
	0xc888, //2x16
	0xc888, //3 byte: |0x40
	0xc8c8, //2x16
	0xc8c8, //4 byte: |0x04
	0xccc8, //2x16
	0xccc8, //3 byte: |0x04
	0xcccc, //2x16

	0xcccc, //4 byte: |0x20
	0xeccc, //2x16
	0xeccc, //3 byte: |0x20
	0xecec, //2x16
	0xecec, //4 byte: |0x02
	0xeeec, //2x16
	0xeeec, //3 byte: |0x02
	0xeeee, //2x16

	0xeeee, //4 byte: |0x10
	0xfeee, //2x16
	0xfeee, //3 byte: |0x10
	0xfefe, //2x16
	0xfefe, //4 byte: |0x01
	0xfffe, //2x16
	0xfffe, //3 byte: |0x01
	0xffff  //2x16
};

ap_uint<32> ruleVal(ap_uint<5> ruleId)
{
	ap_uint<32> ret = rules_data_val_hi[ruleId];
	ret = ret << 16 | rules_data_val_lo[ruleId];
	return ret;
}

#endif


#else

#if 0
const ap_uint<32> rules_data_val[24] = {
//	0x88888888,
	0x88888888 | 0x40000000,
	0x88888888 | 0x40004000,
	//0xc8c8c888, //3 byte: |0x40
	0x88888888 | 0x40404000,
	//0xc8c8c8c8, //2x16
	0x88888888 | 0x40404040,
	//0xccc8c8c8, //4 byte: |0x04
	0x88888888 | 0x44404040,
	//0xccc8ccc8, //2x16
	0x88888888 | 0x44404440,
	//0xccccccc8, //3 byte: |0x04
	0x88888888 | 0x44444440,
	//0xcccccccc, //2x16
	0x88888888 | 0x44444444,
	//0xeccccccc, //4 byte: |0x20
	0x88888888 | 0x44444444 | 0x20000000,
	//0xeccceccc, //2x16
	0x88888888 | 0x44444444 | 0x20002000,
	//0xecececcc, //3 byte: |0x20
	0x88888888 | 0x44444444 | 0x20202000,
	//0xecececec, //2x16
	0x88888888 | 0x44444444 | 0x20202020,
	//0xeeececec, //4 byte: |0x02
	0x88888888 | 0x44444444 | 0x22202020,
	//0xeeeceeec, //2x16
	0x88888888 | 0x44444444 | 0x22202220,
	//0xeeeeeeec, //3 byte: |0x02
	0x88888888 | 0x44444444 | 0x22222220,
	//0xeeeeeeee, //2x16
	0x88888888 | 0x44444444 | 0x22222222, //ID:16/15 =>
	//0xfeeeeeee, //4 byte: |0x10
	0x88888888 | 0x44444444 | 0x22222222 | 0x10000000,
	//0xfeeefeee, //2x16
	0x88888888 | 0x44444444 | 0x22222222 | 0x10001000,
	//0xfefefeee, //3 byte: |0x10
	0x88888888 | 0x44444444 | 0x22222222 | 0x10101000,
	//0xfefefefe, //2x16
	0x88888888 | 0x44444444 | 0x22222222 | 0x10101010,
	//0xfffefefe, //4 byte: |0x01
	0x88888888 | 0x44444444 | 0x22222222 | 0x11101010,
	//0xfffefffe, //2x16
	0x88888888 | 0x44444444 | 0x22222222 | 0x11101110,
	//0xfffffffe, //3 byte: |0x01
	0x88888888 | 0x44444444 | 0x22222222 | 0x11111110,
	//0xffffffff  //2x16
	0x88888888 | 0x44444444 | 0x22222222 | 0x11111111
};
#endif
//#define ruleVal(x) rules_data_val[x]
//

#if 0
const ap_uint<32> rules_data_val[8] = {
		0x40000000, 0x40004000, 0x40404000, 0x40404040,
		0x44404040, 0x44404440, 0x44444440, 0x44444444};

ap_uint<32> ruleVal(ap_uint<5> ruleId)
{
#pragma HLS inline
//#pragma HLS ARRAY_PARTITION variable=rules_data_val complete dim=1
	ap_uint<32> result=rules_data_val[ruleId.range(2,0)];
	if(ruleId.bit(3))
		result = result >> 1 | rules_data_val[7];
	if(ruleId.bit(4))
		result = result >> 1 | rules_data_val[7];

	return result | 0x88888888;

}
#else


#if 0
const ap_uint<16> rules_data_val[5] = {
		  0x0000,
		//0x40000000,
		//0x40004000,
		  0x4000,
		//0x40404000,
		//0x40404040,
		  0x4040,
		//0x44404040,
		//0x44404440,
		  0x4440,
		//0x44444440,
		//0x44444444
		  0x4444,
};

ap_uint<32> ruleVal(ap_uint<5> ruleId)
{
#pragma HLS inline
//#pragma HLS ARRAY_PARTITION variable=rules_data_val complete dim=1
	//0 => 0+1 <<16 | 0 => 0x40000000 OK
	//1 => 0+1 <<16 | 1 => 0x40004000 OK
	//2 => 1+1 <<16 | 1+0 => 0x40404000 OK
	//3 => 1+1 <<16 | 1+1 => 0x40404040 OK
	//4 => 2+1 <<16 | 2+0 => 0x44404040 OK
	//5 => 2+1 <<16 | 2+1 => 0x44404440 OK
	//6 => 3+1 <<16 | 3+0 => 0x44444440 OK
	//7 => 3+1 <<16 | 3+1 => 0x44444444 OK

	ap_uint<32> result=rules_data_val[ruleId.range(2,1)+1];
	result = result << 16 | rules_data_val[ruleId.range(2,1) + ruleId.bit(0)];
	//| rules_data_val[ruleId.range(2,1) + ruleId.bit(0)];
#ifndef  __SYNTHESIS__
	fprintf(stderr, "[HARD] result=0x%08x\n", (uint32_t)result);
#endif

	if(ruleId.bit(3))
		result = (result >> 1) | 0x44444444;
#ifndef  __SYNTHESIS__
	fprintf(stderr, "[HARD] result=0x%08x\n", (uint32_t)result);
#endif
	if(ruleId.bit(4))
		result = (result >> 1) | 0x44444444;

#ifndef  __SYNTHESIS__
	fprintf(stderr, "[HARD] result=0x%08x\n", (uint32_t)result, (uint32_t)(result | 0x88888888));
#endif
	return result | 0x88888888;

}

#else


/*******************************************************************************************************
 * Best realization!
 *******************************************************************************************************/
#if 1
ap_uint<32> ruleVal(ap_uint<5> ruleId)
{
#pragma HLS inline
	ap_uint<32> result = 0;
	ap_uint<4> passed = 0;
	ap_uint<5> bitSet = 30;
	do {
		result.set(bitSet,true);
		passed++;
		bitSet -= 16;
		if(passed==2||passed==6)
			bitSet -= 8;
		if(passed==4)
			bitSet += 4;
	} while(passed <= ruleId.range(2,0));

	for(passed=ruleId.range(4,3);passed>0;passed--)
		result = (result >> 1) | 0x44444444;

	return (result | 0x88888888);
}
#endif

#endif



#endif

#endif






const ap_uint<5> rules_data[280+18] = {
	P24,P17,P12,P17,	P22,P13,P8,P13,		P15,P9,P6,P8,	P11,P6,P5,0,	P5,P3,P2,0,
	P24,P18,P13,P18,	P24,P14,P8,P15,		P15,P10,P6,P9,	P9,P6,P4,P6,	P5,P4,P2,P3,
	0,0,0,0, 			P23,P13,P8,P13,		P16,P7,P6,P9,	P9,P6,P4,P5,	P5,P4,P2,P3,
	P24,P18,P12,P18,	P23,P13,P8,P13,		P16,P8,P6,P9,	P11,P6,P5,0,	P5,P3,P2,P3,
	P24,P17,P12,P18,	P23,P13,P8,P13,		P16,P8,P6,P7,	P11,P6,P5,P6,	P6,P3,P2,P3,
	P24,P18,P13,P19,	P22,P12,P9,P12,		P16,P9,P6,P10,	P9,P6,P4,P6,	P5,P4,P2,P4,
	0,0,0,0,			P23,P12,P9,P14,		P16,P8,P6,P9,	P9,P6,P4,P8,	P5,P4,P2,P5,
	P24,P17,P13,P19,	P22,P12,P9,P14,		P16,P9,P6,P10,	P11,P6,P5,P7,	P5,P3,P2,P4,
	P24,P18,P12,P19,	P22,P11,P9,P13,		P16,P8,P6,P11,	P11,P6,P5,P9,	P5,P4,P2,P4,
	P24,P20,P13,P24,	P22,P13,P9,P13,		P16,P10,P6,P11,	P10,P6,P4,P9,	P6,P4,P2,P5,
	P24,P20,P12,P20,	P24,P16,P10,P15,	P16,P10,P7,P9,	P12,P8,P4,P11,	P8,P6,P2,P6,
	P24,P19,P14,P18,	P24,P14,P10,P13,	P16,P10,P7,P10,	P12,P9,P5,P10,	P6,P5,P2,P5,
	0,0,0,0,			P24,P17,P9,P17,		0,0,0,0,		P13,P9,P5,P10,	P8,P5,P2,P6,
	P24,P20,P14,P23,	0,0,0,0,			P16,P9,P7,P10,	0,0,0,0,		P8,P6,P2,P7,
#if 1
	/* 18 x EEP rules: */
	P24,P23,	P14,P13,	P8,P7,	P3,P2,
	P10,P9,		P6,P5,		P4,P3,	P2,P1,
	P13,P12 /* <== (bitrate_in_cu = 1 && protectionLevel == 1 && protectionOption == 0) */
#endif
};
#endif

#if 0
const ap_uint<5> eep_rules_data[18] = {
		P24,P23,	P14,P13,	P8,P7,	P3,P2,
		P10,P9,		P6,P5,		P4,P3,	P2,P1,
		P13,P12 /* <== (bitrate_in_cu = 1 && protectionLevel == 1 && protectionOption == 0) */
};
#endif


#if 1

/*
#=== Resource usage ===
SLICE:          224
LUT:            610
FF:             430
DSP:              0
BRAM:             1
SRL:              0

#=== Resource usage ===
SLICE:          207
LUT:            563
FF:             445
DSP:              0
BRAM:             1
SRL:              0
 * */


const ap_uint<6> bitrates_in_cu_data[14] = {4,6,7,8,10,12,14,16,20,24,28,32,40,48};

static ap_uint<8> sizes_data_arr[4] = {0,0,0,0};
static ap_uint<5> rules_data_arr[4] = {0,0,0,0};

bool search_subchannel_rules(const ap_uint<8> packed_data_ext[(256)+(280)+(280+18)+(14)])
{
#pragma HLS inline
//#pragma HLS ARRAY_PARTITION variable=eep_rules_data complete dim=1
//#pragma HLS ARRAY_PARTITION variable=bitrates_in_cu_data complete dim=1

//#pragma HLS ARRAY_PARTITION variable=sizes_data complete dim=1
//#pragma HLS ARRAY_PARTITION variable=rules_data complete dim=1
//#pragma HLS ARRAY_MAP variable=bitrates_in_cu_data instance=packed1 horizontal
//#pragma HLS ARRAY_PARTITION variable=sizes_data complete dim=1
//#pragma HLS ARRAY_PARTITION variable=rules_data complete dim=1

//	rules_data[rules_num].size = 96, 0xeeeeeeee};
//	rules_data[rules_num].size = 176, 0xcccccccc};
//	rules_data[rules_num].size = 640, 0xccc8ccc8};
//	rules_data[rules_num].size = 48, 0xccccccc8};
	//rules_data[rules_num].size = };
//	 fprintf(stderr, "Division by 3 (STC.STL=%d): %d == %d ?\n", (int)STC.STL, (int)bitrate_in_cu, (int)STC.STL/3);

    ap_uint<10> rule_data_id = 0;
    bool error = false;

//	const ap_uint<8> *sizes_ptr;
//	const ap_uint<32> *rules_ptr;
	ap_uint<3> protectionLevel = STC_TPL.range(2,0);
	ap_uint<10> bitrate_in_cu0 = STC_STL;// / 3;
	ap_uint<9> bitrate_in_cu=0;
	//division by 3 without DSP48A1
	while(bitrate_in_cu0 >= 3) {
		bitrate_in_cu0-=3;
		bitrate_in_cu++;
	}

	if (STC_TPL.bit(5)) { //is EEP
		protectionLevel &= 3;
		bitrate_in_cu <<= 1;

        	ap_uint<3> protectionOption = STC_TPL.range(4,2);

        	rule_data_id = (protectionOption * 2 + protectionLevel)*2;

            if (protectionOption == 1 || protectionLevel==0 || protectionLevel==2) {
            	sizes_data_arr[0] = ((3 * bitrate_in_cu) - 3);
            	sizes_data_arr[1] = 3;
            } else if(protectionLevel == 1) {
            	if(bitrate_in_cu == 2) {
            		sizes_data_arr[0] = 5;
            		sizes_data_arr[1] = 1;
            		rule_data_id = 4*2 * 2;
            	} else {
                	sizes_data_arr[0] = ((bitrate_in_cu) - 3);
                	sizes_data_arr[1] = ((2 * bitrate_in_cu) + 3);
            	}
            } else if(protectionLevel == 3) {
            	sizes_data_arr[0] = ((2 * bitrate_in_cu) - 3);
            	sizes_data_arr[1] = ((bitrate_in_cu) + 3);
            } else {
                error = true; //produce error
            }
#if 0
            rules_data_arr[0] = eep_rules_data[rule_data_id];
            rules_data_arr[1] = eep_rules_data[rule_data_id+1];
#else
            rule_data_id += 280;
            //rules_data_arr[0] = rules_data[rule_data_id];
            //rules_data_arr[1] = rules_data[rule_data_id+1];
            rules_data_arr[0] = packed_data_ext[(256)+(280)+rule_data_id];
            rules_data_arr[1] = packed_data_ext[(256)+(280)+rule_data_id+1];
#endif

    } else {
        ap_uint<4> cnt=0;

#if 0
        switch (bitrate_in_cu) {
        case 4:
        	rule_data_id = 0;
            break;
        case 6:
        	rule_data_id = 1 *5*4;
            break;
        case 7:
        	rule_data_id = 2 *5*4;
            break;
        case 8:
        	rule_data_id = 3 *5*4;
            break;
        case 10:
        	rule_data_id = 4 *5*4;
            break;
        case 12:
        	rule_data_id = 5 *5*4;
            break;
        case 14:
        	rule_data_id = 6 *5*4;
            break;
        case 16:
        	rule_data_id = 7 *5*4;
            break;
        case 20:
        	rule_data_id = 8 *5*4;
            break;
        case 24:
        	rule_data_id = 9 *5*4;
            break;
        case 28:
        	rule_data_id = 10 *5*4;
            break;
        case 32:
        	rule_data_id = 11 *5*4;
            break;
        case 40:
        	rule_data_id = 12 *5*4;
            break;
        case 48:
        	rule_data_id = 13 *5*4;
            break;
        default:
        	error = true;
            break;
        }
        rule_data_id += protectionLevel*4;
#else
        do {
        	//if (bitrate_in_cu == bitrates_in_cu_data[cnt])
        	if (bitrate_in_cu == packed_data_ext[(256)+(280)+(280+18)+cnt])
        		break;
        	cnt++;
        } while (cnt < 14);

        if(cnt==14)
        	return true;

        rule_data_id = cnt*5*4 + protectionLevel*4;
#endif
/*
#=== Resource usage ===
SLICE:          177
LUT:            459
FF:             434
DSP:              0
BRAM:             1
SRL:              0
        for(ap_uint<3> cnt2=0;cnt2<4;cnt2++) {
        	sizes_data_arr[cnt2] = sizes_data[rule_data_id+cnt2];
            rules_data_arr[cnt2] = rules_data[rule_data_id+cnt2];
        };
        */
/*
#=== Resource usage ===
SLICE:          143
LUT:            467
FF:             434
DSP:              0
BRAM:             1
SRL:              0*/
        for(cnt=0;cnt<4;cnt++) {
        	//sizes_data_arr[cnt] = sizes_data[rule_data_id+cnt];
        	sizes_data_arr[cnt] = packed_data_ext[(256)+rule_data_id+cnt];
            //rules_data_arr[cnt] = rules_data[rule_data_id+cnt];
        	rules_data_arr[cnt] = packed_data_ext[(256)+(280)+rule_data_id+cnt];
        };
    }

	return error;
}

#endif

void puncture_stream(hls::stream<u8stream > &input, hls::stream<u8stream > &output, bool is_subchannel, const ap_uint<8> packed_data_ext[(256)+(280)+(280+18)+(14)])
{
#pragma HLS inline
//#pragma HLS ARRAY_MAP variable=sizes_data instance=packed1 vertical
//#pragma HLS ARRAY_MAP variable=rules_data instance=packed1 vertical

//#pragma HLS ARRAY_MAP variable=eep_rules_data instance=packed1 horizontal
//#pragma HLS ARRAY_MAP variable=rules_data_val_hi instance=packed1 horizontal
//#pragma HLS ARRAY_MAP variable=rules_data_val_lo instance=packed1 horizontal

//#pragma HLS ARRAY_MAP variable=sizes_data instance=packed1 horizontal
//#pragma HLS ARRAY_MAP variable=rules_data instance=packed1 horizontal
//#pragma HLS ARRAY_MAP variable=bitrates_in_cu_data instance=packed1 horizontal

//#pragma HLS ARRAY_MAP variable=bitrates_in_cu_data instance=packed1 vertical

//#pragma HLS ARRAY_PARTITION variable=bitrates_in_cu_data complete dim=1

	u8stream val;
    u8stream y;
    ap_uint<9> counter = 0;
    ap_uint<4> rule_id = 0;
    #ifndef  __SYNTHESIS__
        int out_count=0;
    #endif
        ap_uint<4> bit_count=0;
        ap_uint<8> out = 0;

   	sizes_data_arr[0] = 21;
   	sizes_data_arr[1] = 3;
   	sizes_data_arr[2] = 0;
   	sizes_data_arr[3] = 0;
	rules_data_arr[0] = P16;
	rules_data_arr[1] = P15;

//   	rules_data_arr[0] = 0;
//   	rules_data_arr[1] = 0;
//   	rules_data_arr[2] = 0;
//   	rules_data_arr[3] = 0;

    if(is_subchannel)
    	if(search_subchannel_rules(packed_data_ext))
    		return;


#if 0
		ap_uint<3> size_id=0;
		do {
	        y.data =sizes_data_arr[size_id];
			output.write(y);

			ap_uint<32> pattern0 = ruleVal(rules_data_arr[size_id]);
	        y.data =pattern0.range(31,24);
			output.write(y);
	        y.data =pattern0.range(23,16);
			output.write(y);
			y.data =pattern0.range(15,8);
			output.write(y);
			y.data =pattern0.range(7,0);
			output.write(y);

			size_id++;
		} while(size_id<4);
#endif

	val.last=0;
    y.last=0;

    do {
#ifndef  __SYNTHESIS__
    	if(rule_id == 4) {
    		fprintf(stderr, "[HARD] do: length=%d, pattern=%08x\n",  3, 0x00cccccc);
    	} else {
    		fprintf(stderr, "[HARD] do: length=%d, pattern=%08x\n",  (int)sizes_data_arr[rule_id]*16,
    				(uint32_t)ruleVal(rules_data_arr[rule_id]));
    	}
#endif
    	ap_uint<3> length2check=4;
    	ap_int<12> length = 3;
    	ap_uint<32> pattern = 0x00cccccc;
    	if(rule_id != 4) {
    		length = sizes_data_arr[rule_id]*16;
    		pattern = ruleVal(rules_data_arr[rule_id]);
    	}




    	for (;  length > 0; length -= 4) {
//#ifndef  __SYNTHESIS__
//        	fprintf(stderr, "[HARD] length=%d, pattern=%08x\n", (int)length, (uint32_t)pattern);
//#endif
        	ap_uint<32> mask = 0x80000000;
        	if(rule_id == 4) {
        		mask >>= 8;
        		length2check=3;
        	}


        	for (ap_uint<3> i = 0; i < length2check; ++i) {
            	//uint8_t data = in[in_count++];
            	val = input.read();
            	ap_uint<8> data = val.data;
                //for (ap_uint<4> j = 0; j < 8; ++j) {
            	for (ap_uint<4> j = 0; j < 8; ++j) {
                    if (pattern & mask) {
                        out <<= 1;
                        out |= data >> 7;
                        //out |= data.bit(7-j);
                        /*write resulted data after doing 8 bit logic operations */
                        if (++bit_count == 8) {
                            bit_count = 0;
#ifndef  __SYNTHESIS__
                            ++out_count;
#endif
                            y.data = out;
                            if(rule_id == 4 && i == length2check-1) {
#ifndef  __SYNTHESIS__
                            	fprintf(stderr, "[HARD] last: %d\n", out_count);
#endif
                            	y.last=1;
                            }
                            output.write(y);
                            counter++;
                        	out = 0;
                        }
                    }
                    data <<= 1;
                    mask >>= 1;
                }
            }
        }
        if (++rule_id == 5) {
#ifndef  __SYNTHESIS__
        	fprintf(stderr, "reset rules\n");
#endif
        	rule_id = 0;
        }
    } while (!val.last && !y.last);

    while (bit_count) {
//    	fprintf(stderr, "[SOFT] adding bits...\n");
        out <<= 1;
        if (++bit_count == 8) {
            bit_count = 0;
            //++out_count;
            y.data = out;
            y.last=1;
            output.write(y);
            counter++;
        }
    }

#if 0
    if(counter!=288) {
    	//fprintf(stderr, "counter!=288: %d\n", (int)counter);
    	ret=2;
    }

    if(bit_count) {
    	//fprintf(stderr, "counter!=288: %d\n", (int)counter);
    	ret|=1;
    }

    return ret;


#if 1
    while (!val.last) {
#pragma HLS loop_tripcount min=288 max=384 avg=288
		val = input.read();
	};
#endif
#endif
}


/*

#=== Resource usage ===
SLICE:          143
LUT:            467
FF:             434
DSP:              0
BRAM:             1
SRL:              0

*/
#if 0
void puncturing_dbg(hls::stream<u8stream > &input, hls::stream<u8stream > &output, ap_uint<2> *debug)
{


//#pragma HLS ARRAY_PARTITION variable=sizes_data complete dim=1
//#pragma HLS ARRAY_PARTITION variable=eep_rules_data complete dim=1

//#pragma HLS ARRAY_PARTITION variable=rules_data complete dim=1
//#pragma HLS ARRAY_PARTITION variable=sizes_data_arr complete dim=1
//#pragma HLS ARRAY_PARTITION variable=rules_data_arr complete dim=1

//#pragma HLS ARRAY_PARTITION variable=eep_rules_data block factor=1 dim=1
//#pragma HLS ARRAY_PARTITION variable=rules_data block factor=1 dim=2
//#pragma HLS ARRAY_PARTITION variable=sizes_data block factor=1 dim=2

	//#pragma HLS ARRAY_MAP variable=sizes_data instance=packed1 vertical
	//#pragma HLS ARRAY_MAP variable=rules_data instance=packed1 vertical
	//#pragma HLS ARRAY_MAP variable=rules_data_eep instance=packed1 vertical
	//#pragma HLS ARRAY_MAP variable=sizes_data_arr instance=packed1 vertical
	//#pragma HLS ARRAY_MAP variable=rules_data_arr instance=packed1 vertical

#pragma HLS INTERFACE ap_none port=debug
#pragma HLS INTERFACE ap_fifo port=input
#pragma HLS INTERFACE ap_fifo port=output
#pragma HLS RESOURCE variable=input  core=AXIS metadata="-bus_bundle S_AXIS"
#pragma HLS RESOURCE variable=output core=AXIS metadata="-bus_bundle M_AXIS"
#pragma HLS INTERFACE ap_ctrl_none port=return

	u8stream val = input.read();
	ap_uint<8> block_type = val.data;
	bool is_subchannel=true;

	//switch(block_type) {
	switch(block_type) {
	case 0xF1:

#if 0
		ap_uint<32> buff=0;
		ap_uint<3> i = 0;
		do{
			u8stream val = input.read();
			buff = buff << 8 | val.data;
			i++;
		} while(i<4);
		FC.FCT = buff.range(31,24);
		FC.FICF = buff.bit(23);
		FC.NST = buff.range(22,16);
		FC.FP = buff.range(15,13);
		FC.MID = buff.range(12,11);
		FC.FL = buff.range(10,0);

    	if(!FC.FICF || FC.MID != 1)
    		*debug=2;

        u8stream y;
        y.last=0;
        y.data = block_type;
        output.write(y);
        //y.data = FC.FCT % 4;
        y.data = FC.FP.range(1,0);
		output.write(y);
#else
#if 0
		u8stream y;
        y.last=0;
        y.data = block_type;
        output.write(y);
#endif
        //y.data = FC.FCT % 4;
        //bytes2fc(input, &FC);
        is_subchannel=false;

#endif

#ifndef  __SYNTHESIS__
//        	fprintf(stderr, "[HARD] FCT=%d, FICF=%d, fl_addr=%d, FP=%d, MID=%d, NST=%d\n",
//        			(int) FC.FCT, (int) FC.FICF, (int) FC.FL, (int) FC.FP, (int) FC.MID, (int) FC.NST);
#endif
		// write frame id 0..3
//        if(FC.FICF && FC.MID == 1) {

//    	*debug = puncture_stream(input, output, false);

        //} //else {
    	//	while(!val.last)
    	//		val = input.read();
        //}
//		break;

	case 0xC1: {

//        if(FC.FICF && FC.MID == 1) {
            u8stream y;
            y.last=0;
            y.data = block_type;
            output.write(y);

            /* send STC/FC */
        	for(ap_uint<3> i = 0; i<4; i++) {
        		val = input.read();
    #ifndef  __SYNTHESIS__
    	fprintf(stderr, "[HARD] sending STC/FC: %02x\n", (uint8_t)val.data);
    #endif
        		y.data=val.data;
        		output.write(y);
        		if(is_subchannel && i==2) {
        			STC_TPL=val.data.range(7,2);
        			STC_STL=val.data.range(1,0);
        		}
        		if(is_subchannel && i==3) {
        			STC_STL <<= 8;
        			STC_STL |= val.data;
        		}
        	}

		puncture_stream(input, output, is_subchannel);
		*debug = 0;







//    		if(!error)
//    		else
//    			*debug=2;
//        } else {
//#ifndef  __SYNTHESIS__
//        	fprintf(stderr, "[HARD] not ok! FC.FICF=%d, FC.MID=%d\n", (int)FC.FICF, (int)FC.MID);
//#endif
//    		while(!val.last)
//    			val = input.read();
//        }


		break;
	}
	/* temp hack to passthru unpunctured data */
	default:
//	case 0xF2:
//	case 0xC2:
	{
        u8stream y;
        y.last=0;
        //y.data = block_type-1;
        y.data = block_type;
        output.write(y);

		do {
#pragma HLS loop_tripcount min=289 max=6913 avg=6913
			val = input.read();
			y.data = val.data;
			y.last = val.last;
			output.write(y);
		} while (!val.last);
		break;
	}
//	default:
//		*debug=2;
//		while(!val.last)
//			val = input.read();
//		break;
	}
}
#endif


void puncturing(hls::stream<u8stream > &input, hls::stream<u8stream > &output, const ap_uint<8> packed_data_ext[(256)+(280)+(280+18)+(14)])
{


//#pragma HLS ARRAY_PARTITION variable=sizes_data complete dim=1
//#pragma HLS ARRAY_PARTITION variable=eep_rules_data complete dim=1

//#pragma HLS ARRAY_PARTITION variable=rules_data complete dim=1
//#pragma HLS ARRAY_PARTITION variable=sizes_data_arr complete dim=1
//#pragma HLS ARRAY_PARTITION variable=rules_data_arr complete dim=1

//#pragma HLS ARRAY_PARTITION variable=eep_rules_data block factor=1 dim=1
//#pragma HLS ARRAY_PARTITION variable=rules_data block factor=1 dim=2
//#pragma HLS ARRAY_PARTITION variable=sizes_data block factor=1 dim=2

	//#pragma HLS ARRAY_MAP variable=sizes_data instance=packed1 vertical
	//#pragma HLS ARRAY_MAP variable=rules_data instance=packed1 vertical
	//#pragma HLS ARRAY_MAP variable=rules_data_eep instance=packed1 vertical
	//#pragma HLS ARRAY_MAP variable=sizes_data_arr instance=packed1 vertical
	//#pragma HLS ARRAY_MAP variable=rules_data_arr instance=packed1 vertical

#pragma HLS INTERFACE ap_memory port=packed_data_ext
#pragma HLS RESOURCE variable=packed_data_ext core=ROM_1P_BRAM

#pragma HLS INTERFACE ap_fifo port=input
#pragma HLS INTERFACE ap_fifo port=output
#pragma HLS RESOURCE variable=input  core=AXIS metadata="-bus_bundle S_AXIS"
#pragma HLS RESOURCE variable=output core=AXIS metadata="-bus_bundle M_AXIS"
#pragma HLS INTERFACE ap_ctrl_none port=return

	u8stream val = input.read();
	ap_uint<8> block_type = val.data;
	bool is_subchannel=true;

	//switch(block_type) {
	switch(block_type) {
	case 0xF1:

#if 0
		ap_uint<32> buff=0;
		ap_uint<3> i = 0;
		do{
			u8stream val = input.read();
			buff = buff << 8 | val.data;
			i++;
		} while(i<4);
		FC.FCT = buff.range(31,24);
		FC.FICF = buff.bit(23);
		FC.NST = buff.range(22,16);
		FC.FP = buff.range(15,13);
		FC.MID = buff.range(12,11);
		FC.FL = buff.range(10,0);

    	if(!FC.FICF || FC.MID != 1)
    		*debug=2;

        u8stream y;
        y.last=0;
        y.data = block_type;
        output.write(y);
        //y.data = FC.FCT % 4;
        y.data = FC.FP.range(1,0);
		output.write(y);
#else
#if 0
		u8stream y;
        y.last=0;
        y.data = block_type;
        output.write(y);
#endif
        //y.data = FC.FCT % 4;
        //bytes2fc(input, &FC);
        is_subchannel=false;

#endif

#ifndef  __SYNTHESIS__
//        	fprintf(stderr, "[HARD] FCT=%d, FICF=%d, fl_addr=%d, FP=%d, MID=%d, NST=%d\n",
//        			(int) FC.FCT, (int) FC.FICF, (int) FC.FL, (int) FC.FP, (int) FC.MID, (int) FC.NST);
#endif
		// write frame id 0..3
//        if(FC.FICF && FC.MID == 1) {

//    	*debug = puncture_stream(input, output, false);

        //} //else {
    	//	while(!val.last)
    	//		val = input.read();
        //}
//		break;

	case 0xC1: {

//        if(FC.FICF && FC.MID == 1) {
            u8stream y;
            y.last=0;
            y.data = block_type;
            output.write(y);

            /* send STC/FC */
        	for(ap_uint<3> i = 0; i<4; i++) {
        		val = input.read();
    #ifndef  __SYNTHESIS__
    	fprintf(stderr, "[HARD] sending STC/FC: %02x\n", (uint8_t)val.data);
    #endif
        		y.data=val.data;
        		output.write(y);
        		if(is_subchannel && i==2) {
        			STC_TPL=val.data.range(7,2);
        			STC_STL=val.data.range(1,0);
        		}
        		if(is_subchannel && i==3) {
        			STC_STL <<= 8;
        			STC_STL |= val.data;
        		}
        	}

		puncture_stream(input, output, is_subchannel, packed_data_ext);







//    		if(!error)
//    		else
//    			*debug=2;
//        } else {
//#ifndef  __SYNTHESIS__
//        	fprintf(stderr, "[HARD] not ok! FC.FICF=%d, FC.MID=%d\n", (int)FC.FICF, (int)FC.MID);
//#endif
//    		while(!val.last)
//    			val = input.read();
//        }


		break;
	}
	/* temp hack to passthru unpunctured data */
	default:
//	case 0xF2:
//	case 0xC2:
	{
        u8stream y;
        y.last=0;
        //y.data = block_type-1;
        y.data = block_type;
        output.write(y);

		do {
#pragma HLS loop_tripcount min=289 max=6913 avg=6913
			val = input.read();
			y.data = val.data;
			y.last = val.last;
			output.write(y);
		} while (!val.last);
		break;
	}
//	default:
//		*debug=2;
//		while(!val.last)
//			val = input.read();
//		break;
	}
}
