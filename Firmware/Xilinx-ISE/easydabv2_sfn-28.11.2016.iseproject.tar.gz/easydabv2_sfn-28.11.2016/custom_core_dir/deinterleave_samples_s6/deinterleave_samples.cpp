
#include <ap_int.h>
#include <ap_utils.h>
#include <hls_stream.h>

#define DISABLE_GAIN
//#undef DISABLE_GAIN

//#define GAIN_CONTROL_MORE_RAM
//#define GAIN_CONTROL_PACKED
//#define BIT_CNT_18


#ifdef BIT_CNT_18
void deinterleave_samples(hls::stream<ap_uint<48> > &input,
		hls::stream<ap_uint<18> >   &output
		)
{
#pragma HLS INTERFACE ap_fifo port=input
#pragma HLS INTERFACE ap_fifo port=output
#pragma HLS RESOURCE variable=input  core=AXIS metadata="-bus_bundle S_AXIS"
#pragma HLS RESOURCE variable=output core=AXIS metadata="-bus_bundle M_AXIS"
#pragma HLS INTERFACE ap_ctrl_none port=return

	ap_uint<48> x;

	while(1) {
		x=input.read();
		output.write(x.range(17,0));
		output.write(x.range(41,24));
	};
}
#else
void deinterleave_samples(hls::stream<ap_uint<32> > &input,
		hls::stream<ap_uint<16> >   &output
		)
{
#pragma HLS INTERFACE ap_fifo port=input
#pragma HLS INTERFACE ap_fifo port=output
#pragma HLS RESOURCE variable=input  core=AXIS metadata="-bus_bundle S_AXIS"
#pragma HLS RESOURCE variable=output core=AXIS metadata="-bus_bundle M_AXIS"
#pragma HLS INTERFACE ap_ctrl_none port=return

	ap_uint<32> x;

	while(1) {
		x=input.read();
		output.write(x.range(15,0));
		output.write(x.range(31,16));
//		output.write(x.range(15,0));
//		output.write(x.range(31,16));
	};
}
#endif
