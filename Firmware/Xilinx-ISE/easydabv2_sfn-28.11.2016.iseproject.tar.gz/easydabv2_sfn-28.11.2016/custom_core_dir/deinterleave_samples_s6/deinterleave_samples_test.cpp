

#include <ap_int.h>
#include <hls_stream.h>

typedef struct {
	ap_int<16> real;
	ap_int<16> imag;
} cint16;

typedef struct {
	cint16	   data;
	ap_uint<1> last;
} cplxi16stream;

void deinterleave_samples(hls::stream<cplxi16stream> &input, hls::stream<cplxi16stream> &output);

int complexDiff(cint16 a, cint16 b)
{
	int diff = a.real - b.real;
	if(diff < 0) diff=-diff;
	int diff1 = a.imag - b.imag;
	if(diff1 < 0) diff1=-diff1;
	return (diff > diff1) ? diff : diff1;
}

int read_data(hls::stream<cplxi16stream> &data_out,int *o_idx, FILE *out_fp, FILE *out_fp_my)
{
	int i=0;
	int not_ok=0;
	int read_size = data_out.size();
	//fprintf(stderr, "read[%d]=%d\n", *o_idx, read_size);
	if(read_size == 0) {
		fprintf(stderr, "read[%d]=%d nothing to read!\n", *o_idx, read_size);
		return 1;
	}

	int to_read = read_size;
	if(read_size != 2656 && read_size != 2552){
		fprintf(stderr, "bad read size: %d", read_size);
		not_ok++;
		return not_ok;
	}

	do {
		cplxi16stream var = data_out.read();
		fprintf(out_fp_my,"%d %d %d %d\n",(*o_idx),i,(int)var.data.real, (int)var.data.imag);

		int idx0=0;
		int idx1=0;
		int out_re=0;
		int out_im=0;
		cint16 data;
		if(fscanf(out_fp,"%d %d %d %d",&idx0,&idx1,&out_re,&out_im) !=4){
			fprintf(stderr, "output scan failed on: %d %d\n", (*o_idx), i);
			return 1;
		}

		if(i != idx1 || (*o_idx) != idx0) {
			fprintf(stderr, "output index mismatch: %d %d != %d %d\n", (*o_idx), i, idx0, idx1);
			return 1;
		}

		data.real = out_re;
		data.imag = out_im;
		if(complexDiff(var.data, data) > 2) {
			fprintf(stderr, "%d %d err: %d %d != %d %d\n", (*o_idx), i, (int)var.data.real, (int) var.data.imag, out_re, out_im);
			//fprintf(stderr, "x");
			//if((not_ok+1) % 128 == 0) fprintf(stderr, "\n");
			not_ok++;
		} else {
			//fprintf(stderr, ".");
			//if((i+1) % 256 == 0) fprintf(stderr, "\n");
		}

		i++;
	} while (i < read_size);
	//fprintf(stderr, "\n");
	(*o_idx)++;

	return not_ok;
}


int main()
{
    int not_ok = 0;

    hls::stream<cplxi16stream> data_in;
    hls::stream<cplxi16stream> data_out;

    int in_ptr = 0;
    int out_ptr = 0;

    int i_idx = 0;
    int o_idx = 0;
    FILE *in_fp = fopen("output_guard_var_gain.dat","rb");
    if(!in_fp) {
    	fprintf(stderr, "can't open input\n");
    }

    FILE *out_fp = fopen("output_guard.dat","rb");
    if(!out_fp) {
    	fprintf(stderr, "can't open output\n");
    }
    FILE *out_fp_my = fopen("output.dat","wb");
    if(!out_fp) {
    	fprintf(stderr, "can't open output2\n");
    }


  do {
	// Fill HW buffers
    int i=0;
	do {
		cplxi16stream var;
		int idx0=0;
		int idx1=0;
		int in_re=0;
		int in_im=0;
		if(fscanf(in_fp,"%d %d %d %d",&idx0,&idx1,&in_re,&in_im) !=4){
			fprintf(stderr, "input scan failed on: %d %d\n", i_idx, i);
			return 1;
		}

		if(i != idx1 || i_idx != idx0) {
			fprintf(stderr, "input index mismatch: %d %d != %d %d\n", i_idx, i, idx0, idx1);
			return 1;
		}

		if(i_idx==0) {
			var.last = (i==2655) ? 1 :0;
		} else {
			var.last = (i==2551) ? 1 :0;
		}

		var.data.real = in_re;
		var.data.imag = in_im;
		data_in.write(var);
		i++;
	} while ((i_idx==0 && i < 2656) || (i_idx!=0 && i < 2552));
	i_idx++;

	deinterleave_samples(data_in, data_out);

	not_ok += read_data(data_out, &o_idx, out_fp, out_fp_my);
} while (i_idx < 77);
//} while (i_idx < 2);

    fclose(in_fp);
    fclose(out_fp);
    fclose(out_fp_my);

    fprintf(stderr, "after check: %d\n", not_ok);

    // Compare the results file with the golden results
    int retval = system("diff --brief -w output.dat output_guard.dat");
    if (retval != 0) {
    	printf("Test failed  !!!\n");
    	not_ok++;
    } else {
    	printf("Test passed !\n");
    }

    return not_ok;


}
