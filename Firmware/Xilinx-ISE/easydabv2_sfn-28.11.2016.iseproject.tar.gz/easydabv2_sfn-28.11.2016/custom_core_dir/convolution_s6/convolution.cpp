
#include <ap_int.h>
#include <ap_utils.h>
#include <hls_stream.h>

typedef struct {
	ap_uint<8> data;
	ap_uint<1> last;
} u8stream;


//const ap_uint<1> PARITY[256] = {
const ap_uint<1> PARITY[128] = {
    0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0, //0..15
    1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1, //16..31
    1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1, //32..47
    0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0, //48..63
//same but inverted
    1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1, //64..79
    0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0, //80..95
    0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0, //96..111
    1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1  //112..127 [MAX 121]
//   ,1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1,
//    0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0,
//    0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0,
//    1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1,
//    0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0,
//    1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1,
//    1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1,
//    0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0
};

#if 0
ap_uint<2> convolute_stream(hls::stream<u8stream > &input, hls::stream<u8stream > &output)
{
#pragma HLS inline

    u8stream val, y;
    ap_uint<16> memory = 0;
    // While there is enought input and ouput items
    y.last=0;
    do {
        val = input.read();
            for (ap_uint<4> out_count = 0; out_count < 4; ++out_count) {
                y.data=0;
                // For each 4-bit output word
                for (ap_uint<2> j = 0; j < 2; ++j) {
                    memory >>= 1;
                    memory |= (val.data >> 7) << 6;
                    val.data <<= 1;
                    //PDEBUG("Memory: 0x%x\n", memory);
                    unsigned char poly[4] = {
                        (unsigned char)(memory & 0x5b),
                        (unsigned char)(memory & 0x79),
                        (unsigned char)(memory & 0x65),
                        (unsigned char)(memory & 0x5b)
                    };
                    //PDEBUG("Polys: 0x%x, 0x%x, 0x%x, 0x%x\n", poly[0], poly[1], poly[2], poly[3]);
                    // For each poly
                    for (ap_uint<3> k = 0; k < 4; ++k) {
                        y.data <<= 1;
                        y.data |= PARITY[poly[k]];
                        //PDEBUG("Out bit: %i\n", out[no] >> 7);
                    }
                }
                output.write(y);
            }
    } while(!val.last);

    for (ap_uint<3> pad_count = 0; pad_count < 3; ++pad_count) {
            y.data=0;
            // For each 4-bit output word
            for (ap_uint<2> j = 0; j < 2; ++j) {
                memory >>= 1;
                //PDEBUG("Memory: 0x%x\n", memory);
                unsigned char poly[4] = {
                    (unsigned char)(memory & 0x5b),
                    (unsigned char)(memory & 0x79),
                    (unsigned char)(memory & 0x65),
                    (unsigned char)(memory & 0x5b)
                };
                //PDEBUG("Polys: 0x%x, 0x%x, 0x%x, 0x%x\n", poly[0], poly[1], poly[2], poly[3]);
                // For each poly
                for (ap_uint<3>  k = 0; k < 4; ++k) {
                    y.data <<= 1;
                    y.data |= PARITY[poly[k]];
                    //PDEBUG("Out bit: %i\n", out[no] >> 7);
                }
            }
            //PDEBUG("Out: 0x%x\n", out[no]);
            if(pad_count==2)
                y.last=1;
            output.write(y);
            ++out_offset;
        }
    }
}
#endif

ap_uint<1> get_parity(ap_uint<7> idx)
{
#pragma HLS ARRAY_PARTITION variable=PARITY complete dim=1
	return PARITY[idx];
}

void convolute_stream(hls::stream<u8stream > &input, hls::stream<u8stream > &output)
{
#pragma HLS inline

    u8stream val, y;
    ap_uint<16> memory = 0;
    bool last_flag=false;
    ap_uint<4> out_count;

    // While there is enought input and ouput items
    y.last=0;
    val.last=0;
    do {
        if(!val.last) {
            val = input.read();
            out_count=4;
        } else {
            val.data=0;
            out_count=3;
            last_flag=true;
        }

        do {
            y.data=0;
            // For each 4-bit output word
            for (ap_uint<2> j = 0; j < 2; ++j) {
                memory >>= 1;
                memory |= (val.data >> 7) << 6;
                val.data <<= 1;
                //PDEBUG("Memory: 0x%x\n", memory);
#if 0
                ap_uint<8> poly[4] = {
                    (ap_uint<8>)(memory & 0x5b),
                    (ap_uint<8>)(memory & 0x79),
                    (ap_uint<8>)(memory & 0x65),
                    (ap_uint<8>)(memory & 0x5b)
                };

                // For each poly
                for (ap_uint<3> k = 0; k < 4; ++k) {
                    y.data <<= 1;
                    y.data |= PARITY[poly[k]];
                    //PDEBUG("Out bit: %i\n", out[no] >> 7);
                }
#else
#if 0
                //0 0 91 149
                y.data <<= 1;
                y.data |= PARITY[memory & 0x5b]; //0b0101 1011 => max 91

                y.data <<= 1;
                y.data |= PARITY[memory & 0x79]; //0b0111 1001 => max 121

                y.data <<= 1;
                y.data |= PARITY[memory & 0x65]; //0b0110 0101 => max 101

                y.data <<= 1;
                y.data |= PARITY[memory & 0x5b]; //0b0101 1011 => max 91
#else
                //0 0 91 149
                y.data <<= 4;
                ap_uint<1> bit = get_parity(memory & 0x5b);
                y.data.set_bit(3, bit);
                y.data.set_bit(0, bit);
                y.data.set_bit(1, get_parity(memory & 0x65));
                y.data.set_bit(2, get_parity(memory & 0x79));
#endif
#endif
            }
            out_count--;
            if(last_flag && out_count == 0)
                y.last=1;
            output.write(y);
        } while(out_count > 0);
    } while(!y.last);
}

/*

#=== Resource usage ===
SLICE:           32
LUT:            101
FF:              59
DSP:              0
BRAM:             0
SRL:              0

 * */

void convolution_dbg(hls::stream<u8stream > &input, hls::stream<u8stream > &output, ap_uint<2> *debug)
{
#pragma HLS INTERFACE ap_none port=debug
#pragma HLS INTERFACE ap_fifo port=input
#pragma HLS INTERFACE ap_fifo port=output
#pragma HLS RESOURCE variable=input  core=AXIS metadata="-bus_bundle S_AXIS"
#pragma HLS RESOURCE variable=output core=AXIS metadata="-bus_bundle M_AXIS"
#pragma HLS INTERFACE ap_ctrl_none port=return

	u8stream val = input.read();
	ap_uint<8> block_type = val.data;
	/* send block type */
#if 1
	//0 0 91 149
  switch(block_type) {
	case 0xF1:
	case 0xC1: {
	    u8stream y;
	    y.last=0;
	    y.data = block_type;
	    output.write(y);

        /* send STC/FC */
    	for(ap_uint<3> i = 0; i<4; i++) {
    		val = input.read();
#ifndef  __SYNTHESIS__
	fprintf(stderr, "[HARD] sending STC/FC: %02x\n", (uint8_t)val.data);
#endif
    		y.data=val.data;
    		output.write(y);
    	}

		convolute_stream(input, output);
		*debug=0;
		break;
	}
	/* temp hack to passthru unpunctured data */
	default:
//	case 0xF2:
//	case 0xFA;
//	case 0xC2:
	{
	    u8stream y;
	    y.last=0;
	    y.data = block_type;
	    output.write(y);

	    do {
#pragma HLS loop_tripcount min=289 max=6913 avg=6913
			val = input.read();
			y.data = val.data;
			y.last = val.last;
			output.write(y);
		} while (!val.last);
	    *debug=1;
		break;
	}
  }
#else
  //0 0 99 167
  bool do_convolute = false;
  ap_uint<3> counter = 4;
  switch(block_type) {
	case 0xF1:
	case 0xC1:
		do_convolute=true;
	default:
//	case 0xF2:
//	case 0xC2:
	{
		do {
#pragma HLS loop_tripcount min=4 max=6913 avg=6913
			val = input.read();
			y.data = val.data;
			y.last = val.last;
			output.write(y);
			counter--;
		} while (!val.last && (!do_convolute || (do_convolute && counter > 0)));
		if(do_convolute)
			convolute_stream(input, output);
		break;
	}
  }
#endif
}





void convolution(hls::stream<u8stream > &input, hls::stream<u8stream > &output)
{
#pragma HLS INTERFACE ap_fifo port=input
#pragma HLS INTERFACE ap_fifo port=output
#pragma HLS RESOURCE variable=input  core=AXIS metadata="-bus_bundle S_AXIS"
#pragma HLS RESOURCE variable=output core=AXIS metadata="-bus_bundle M_AXIS"
#pragma HLS INTERFACE ap_ctrl_none port=return

	u8stream val = input.read();
	ap_uint<8> block_type = val.data;
	/* send block type */
	//0 0 91 149
  switch(block_type) {
	case 0xF1:
	case 0xC1: {
	    u8stream y;
	    y.last=0;
	    y.data = block_type;
	    output.write(y);

        /* send STC/FC */
    	for(ap_uint<3> i = 0; i<4; i++) {
    		val = input.read();
#ifndef  __SYNTHESIS__
	fprintf(stderr, "[HARD] sending STC/FC: %02x\n", (uint8_t)val.data);
#endif
    		y.data=val.data;
    		output.write(y);
    	}

		convolute_stream(input, output);
		break;
	}
	/* temp hack to passthru unpunctured data */
	default:
//	case 0xF2:
//	case 0xFA;
//	case 0xC2:
	{
	    u8stream y;
	    y.last=0;
	    y.data = block_type;
	    output.write(y);

	    do {
#pragma HLS loop_tripcount min=289 max=6913 avg=6913
			val = input.read();
			y.data = val.data;
			y.last = val.last;
			output.write(y);
		} while (!val.last);
		break;
	}
  }
}


void convolution0(hls::stream<u8stream > &input, hls::stream<u8stream > &output)
{
#pragma HLS INTERFACE ap_fifo port=input
#pragma HLS INTERFACE ap_fifo port=output
#pragma HLS RESOURCE variable=input  core=AXIS metadata="-bus_bundle S_AXIS"
#pragma HLS RESOURCE variable=output core=AXIS metadata="-bus_bundle M_AXIS"
#pragma HLS INTERFACE ap_ctrl_none port=return

	u8stream val;
	bool is_phase = false;

	/* send STC/FC */
    for(ap_uint<3> i = 0; i<5; i++) {
    	val = input.read();
    	if(i==0 && val.data == 0xFA) is_phase = true;
    	output.write(val);
   	}

    if(is_phase) {
		convolute_stream(input, output);
    } else {
    	while (!val.last) {
#pragma HLS loop_tripcount min=289 max=6913 avg=6913
			val = input.read();
			output.write(val);
		};
	}
}
