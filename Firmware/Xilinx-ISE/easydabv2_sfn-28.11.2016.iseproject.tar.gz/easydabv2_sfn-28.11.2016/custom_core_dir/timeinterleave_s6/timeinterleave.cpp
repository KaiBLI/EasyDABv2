
#include <ap_int.h>
#include <ap_utils.h>
#include <hls_stream.h>

typedef struct {
	ap_uint<8> data;
	ap_uint<1> last;
} u8stream;


//3*1024*18/(6912*8)

// 4x [FILL FRAME: 4xCIF] => 384ms
#define HW_SRAM_BLOCKSIZE 8192
//#define HW_SRAM_BLOCKSIZE 6912

//static ap_uint<8> hw_sram_mem[16*HW_SRAM_BLOCKSIZE]; //128KB.
const ap_uint<8> hw_produce_mask[8] = {0x80, 0x08, 0x20, 0x02, 0x40, 0x04, 0x10, 0x01};

ap_uint<8> hw_sram_write_0_read(ap_uint<17> offset, ap_uint<8> data,
		volatile ap_uint<17> *sram_addr,
		volatile ap_uint<8> *sram_databus,
		volatile bool *sram_databus_t,
		volatile bool *sram_noe,
		volatile bool *sram_nwe,
		ap_uint<4> hw_sram_bank_id_start)
{
#pragma HLS inline
#pragma HLS ARRAY_PARTITION variable=hw_produce_mask complete dim=1
	/* 9 clocks!!! (7=addr + 2 byte) 20MHz => */
	*sram_addr = (ap_uint<17>)HW_SRAM_BLOCKSIZE*hw_sram_bank_id_start + offset;
	*sram_databus = data;
	*sram_nwe=false;
	ap_wait();
	*sram_nwe=true;

	/* read cycle */
	ap_wait();
	*sram_databus_t=true;
	*sram_noe=false;

	data = 0;
	ap_uint<1> addition=offset.bit(0);

	for(ap_uint<4> block_id=0;block_id < 8; block_id++) {
		ap_uint<5> bank_id = block_id*2 + addition;

		bank_id += hw_sram_bank_id_start;
		if(bank_id > 15) bank_id -=16;

		*sram_addr = HW_SRAM_BLOCKSIZE*bank_id + offset;
		ap_wait();
		data |= ((ap_uint<8>) *sram_databus) & hw_produce_mask[block_id];
	}
	ap_wait();
	*sram_noe=true;
	*sram_databus_t=false;
	return data;
}



void timeinterleave_stream(hls::stream<u8stream > &input, hls::stream<u8stream > &output, ap_uint<13> hw_start_addr,
		volatile ap_uint<17> *sram_addr,
		volatile ap_uint<8> *sram_databus,
		volatile bool *sram_databus_t,
		volatile bool *sram_noe,
		volatile bool *sram_nwe,
		ap_uint<4> hw_sram_bank_id_start
		)
{
#pragma HLS inline
// bank[N] became bank[0]
// bank[1 .. N-1] became bank[2 .. N]
// shift rotate: bank >> 1

	u8stream val;
   	do {
   		val=input.read();
   		if(hw_start_addr < 6912) {
   			u8stream y;
   			y.data=hw_sram_write_0_read(hw_start_addr, val.data, sram_addr, sram_databus, sram_databus_t, sram_noe, sram_nwe, hw_sram_bank_id_start);
   			y.last=val.last || (hw_start_addr == 6911);
   			output.write(y);
   			hw_start_addr++;
   		}
   	} while(!val.last);

}





//static bool reset_done = false;


void timeinterleave(hls::stream<u8stream > &input, hls::stream<u8stream > &output,
		volatile ap_uint<17> *sram_addr,
		volatile ap_uint<8> *sram_databus,
		volatile bool *sram_databus_t,
		volatile bool *sram_noe,
		volatile bool *sram_nwe
		)
{
#pragma HLS DATA_PACK variable=output

#pragma HLS DATA_PACK variable=input


#pragma HLS INTERFACE ap_none port=sram_addr bundle=SRAM
#pragma HLS INTERFACE ap_none port=sram_databus bundle=SRAM
#pragma HLS INTERFACE ap_none port=sram_databus_t bundle=SRAM
#pragma HLS INTERFACE ap_none port=sram_noe bundle=SRAM
#pragma HLS INTERFACE ap_none port=sram_nwe bundle=SRAM



#pragma HLS INTERFACE ap_fifo port=input
#pragma HLS INTERFACE ap_fifo port=output
//#pragma HLS RESOURCE variable=input  core=AXIS metadata="-bus_bundle S_AXIS"
//#pragma HLS RESOURCE variable=output core=AXIS metadata="-bus_bundle M_AXIS"
#pragma HLS RESOURCE variable=input core=FIFO_SRL  metadata="-bus_bundle S_FIFO"
#pragma HLS RESOURCE variable=output core=FIFO_SRL  metadata="-bus_bundle M_FIFO"
#pragma HLS INTERFACE ap_ctrl_none port=return

	ap_uint<4> bank_id_start=0;

//	if(!reset_done) {
		*sram_addr=0x00;
		*sram_databus=0x00;
		*sram_databus_t=false;
		*sram_noe=true;
		*sram_nwe=false;

		for(ap_uint<18> addr = 0x00; addr < HW_SRAM_BLOCKSIZE*16; addr++) {
			*sram_addr=addr;
			ap_wait();
		}

		*sram_nwe=true;
//		bank_id_start=0;
//		reset_done=true;
//	}

#if 0
	u8stream val = input.read();
	//80-239-154
	const ap_uint<8> block_type = val.data;

	//0 0 91 149
  switch(block_type) {
	case 0xC1:
	{
		u8stream y;
		y.last=0;
		y.data=block_type;
		//write header
		output.write(y);
		//read and passthru STC
		ap_uint<3> i = 0;
		ap_uint<10> SAD=0;
		do {
			y = input.read();
			if(i==0) {
				SAD.set(9, y.data.bit(1));
				SAD.set(8, y.data.bit(0));
			} else if(i==1) {
				SAD |= y.data;
			}
			output.write(y);
			i++;
		} while (i<4);

		//interleave here
		timeinterleave_stream(input, output, SAD * 8, sram_addr, sram_databus, sram_databus_t, sram_noe, sram_nwe);
		break;
	}

	case 0xFA:
		if(hw_sram_bank_id_start) {
			hw_sram_bank_id_start--;
		} else {
			hw_sram_bank_id_start = 15;
		}

	default: {
		/******************************************************************************************
		 * FIC Staff
		 * Sending FIC as-is, just pass fic phase as part of block type: F0/F1/F2/F3
		 ******************************************************************************************/
		u8stream y;
		y.last=0;
		y.data=block_type;
		//write header
		output.write(y);
		do {
			y = input.read();
			output.write(y);
		} while (!y.last);
		break;
	}
  }
#else

  while(1) {
	u8stream val = input.read();

  //59-184-136
	output.write(val);

	//0 0 91 149
  if(val.data == 0xC1) {
//		u8stream y;
//		y.last=0;
//		y.data=block_type;
//		//write header
//		output.write(y);
		//read and passthru STC
		ap_uint<3> i = 0;
		ap_uint<10> SAD=0;
		do {
			u8stream y = input.read();
			if(i==0) {
				SAD.set(9, y.data.bit(1));
				SAD.set(8, y.data.bit(0));
			} else if(i==1) {
				SAD |= y.data;
			}
			output.write(y);
			i++;
		} while (i<4);

		//interleave here
		timeinterleave_stream(input, output, SAD * 8, sram_addr, sram_databus, sram_databus_t, sram_noe, sram_nwe, bank_id_start);
	} else {
		if(val.data == 0xFA)
			bank_id_start--;
		/******************************************************************************************
		 * FIC Staff
		 * Sending FIC as-is, just pass fic phase as part of block type: F0/F1/F2/F3
		 ******************************************************************************************/
		u8stream y;
//		y.last=0;
//		y.data=block_type;
//		//write header
//		output.write(y);
		do {
			y = input.read();
			output.write(y);
		} while (!y.last);
	}
  }
#endif
}
