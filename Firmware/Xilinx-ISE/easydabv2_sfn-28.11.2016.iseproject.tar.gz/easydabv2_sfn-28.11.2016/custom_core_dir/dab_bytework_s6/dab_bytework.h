

#include <ap_int.h>
#include <ap_utils.h>
#include <hls_stream.h>


enum {
	P1=0,
	P2,
	P3,
	P4,
	P5,
	P6,
	P7,
	P8,
	P9,
	P10,
	P11,
	P12,
	P13,
	P14,
	P15,
	P16,
	P17,
	P18,
	P19,
	P20,
	P21,
	P22,
	P23,
	P24
} rulen_num;


typedef struct {
	ap_uint<8> data;
	ap_uint<1> last;
} u8stream;

void eti_parser(hls::stream<ap_uint<8> > &input, hls::stream<u8stream > &output, volatile bool *out_aresetn,
		hls::stream<ap_uint<8> > &tist,	ap_uint<8> stc_buff[256]);

void prbs(hls::stream<u8stream > &input, hls::stream<u8stream > &output);
void convolution(hls::stream<u8stream > &input, hls::stream<u8stream > &output);

void puncturing(hls::stream<u8stream > &input, hls::stream<u8stream > &output,
		const ap_uint<8> packed_data_ext[(256)+(280)+(280+18)+(14)]);

void date2time(hls::stream<ap_uint<8> > &stream_in, hls::stream<ap_uint<8> > &stream_out);
