

#include <ap_int.h>
#include <ap_utils.h>
#include <hls_stream.h>


#include "dab_bytework.h"


#define USE_EXTERNAL_RAM






/*

 * */

enum {
	STATE_SYNC=0,
	STATE_FC,
	STATE_STC,
	STATE_EOH,
	STATE_FIC,
	STATE_SUBCHANNEL,
	STATE_EOF,
	STATE_TIST
};


#ifdef USE_EXTERNAL_RAM

ap_uint<32> mul_add(ap_uint<32> x, ap_uint<32> y, ap_uint<32> z)
{
#pragma HLS INLINE off

	return x*y + z;
}

#if 0

unsigned short crc16v2(const unsigned char* data_p, unsigned char length){
    unsigned char x;
    unsigned short crc = 0xFFFF;

    while (length--){
        x = crc >> 8 ^ *data_p++;
        x ^= x>>4;
        crc = (crc << 8) ^ ((unsigned short)(x << 12)) ^ ((unsigned short)(x <<5)) ^ ((unsigned short)x);
    }
    return ~crc;
}

<------><------>uint8_t *crc_ptr = &p_ni_search_block[4 + (1 + fc.nst)*4 + 2];
<------><------>
<------><------>uint16_t crc_val2 = crc16v2(&p_ni_search_block[4], (fc.nst + 1)*4 + 2);
<------><------>uint16_t crc_val4 = ((uint16_t)crc_ptr[0]) << 8 | crc_ptr[1];
<------><------>assert(crc_val2 == crc_val4);
<------><------>DEBUG("crc: 0x%02x%02x == 0x%04x", crc_ptr[0], crc_ptr[1], crc_val2);

//CRC with self must be always e2f0 (1d0f if non-inverted at the end)
#endif



//static const ap_uint<5> calendar[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

//static ap_uint<32> stc_buff[64];
//static ap_uint<32> stc_buff[64];
/*
#=== Resource usage ===
SLICE:           94
LUT:            268
FF:             198
DSP:              0
BRAM:             0
SRL:              1
 * */
void eti_parser(hls::stream<ap_uint<8> > &input, hls::stream<u8stream > &output, volatile bool *out_aresetn,
		hls::stream<ap_uint<8> > &tist,	ap_uint<8> stc_buff[256])
{
//#pragma HLS ARRAY_PARTITION variable=stc_buff complete dim=1
//#pragma HLS ARRAY_PARTITION variable=calendar complete dim=1


#pragma HLS INTERFACE ap_fifo port=input
#pragma HLS INTERFACE ap_fifo port=output
#pragma HLS INTERFACE ap_none port=out_aresetn
//#pragma HLS INTERFACE ap_none port=tist
#pragma HLS INTERFACE ap_fifo port=tist

#pragma HLS INTERFACE ap_memory port=stc_buff
#pragma HLS RESOURCE variable=stc_buff core=RAM_1P_BRAM
//#pragma HLS RESOURCE variable=input  core=AXIS metadata="-bus_bundle S_AXIS"
//#pragma HLS RESOURCE variable=output core=AXIS metadata="-bus_bundle M_AXIS"
//#pragma HLS RESOURCE variable=tist core=AXIS metadata="-bus_bundle M_TIST_AXIS"


//#pragma HLS reset variable=initialized

#pragma HLS INTERFACE ap_ctrl_none port=return

	bool initialized = false;
	bool subchannel_header_sent=false;
	bool send_ts = false;
	bool tist_is_sent = false;
	ap_uint<32> collect_buff = 0x00;
//	ap_uint<32> timestamp = 0x00;
	ap_uint<4> state_machine = STATE_SYNC;
	ap_uint<13> bytes_readed = 0;
	ap_uint<13> bytes_readed_save = 0;
	ap_uint<7>  subchannel_id = 0;
	ap_uint<7>  FC_NST = 0;
	ap_uint<2>  FC_FP01 = 0b11;
	ap_uint<10> content_len = 0;
	ap_uint<16> crc = 0;
	//*tist = 0xFFFFFF;

  while(initialized || state_machine == STATE_SYNC) {
   if(!initialized) {
#ifndef  __SYNTHESIS__
	fprintf(stderr, "INIT...\n");
#endif
		*out_aresetn = initialized;
		initialized = true;
		tist_is_sent = false;
		state_machine=STATE_SYNC;
		collect_buff = 0x00;
		ap_wait();
		*out_aresetn = initialized;
		ap_wait();
   } else {

	ap_uint<8> val = input.read();
	ap_uint<8> x = (crc >> 8) ^ val;
    x ^= x>>4;
    //crc = (crc << 8) ^ ((ap_uint<16>)(x << 12)) ^ ((ap_uint<16>)(x <<5)) ^ ((ap_uint<16>)x);
	//ap_uint<8> x = crc.range(15,8) ^ val;
    ////x ^= x>>4;
	//x = x ^ x.range(7,4);
	//crc.shl(8);
    crc = (crc << 8) ^ (((ap_uint<16>)x) << 12) ^ (((ap_uint<16>)x) << 5) ^ ((ap_uint<16>)x);

	collect_buff = collect_buff << 8 | val;
	bytes_readed++;

	switch(state_machine) {
	case STATE_SYNC: {
#ifndef  __SYNTHESIS__
//	fprintf(stderr, "HEADER: %08x\n", (uint32_t)collect_buff);
#endif

		if(collect_buff == 0xFF073AB6 || collect_buff == 0xFFF8C549) {
			state_machine=STATE_FC;
			bytes_readed=4;
			crc = 0xFFFF;
			u8stream y;
			y.last=0;
			y.data=0xF1;
			output.write(y);
		}
		break;
	}
	case STATE_FC: {
		u8stream y;
		y.last=0;
		y.data=val;
		output.write(y);
		if(bytes_readed==8) {
			FC_NST=collect_buff.range(22,16);

#ifndef  __SYNTHESIS__
	fprintf(stderr, "HEADER: FC_NST=%d FC_FP01=0x%02x (prev: %02x)\n", (uint8_t)FC_NST, (uint8_t)collect_buff.range(14,13), (uint8_t)FC_FP01);
#endif

			FC_FP01++;
			if(FC_FP01!=collect_buff.range(14,13)) {
				initialized = false;
				state_machine = STATE_SYNC;
				//
#ifndef  __SYNTHESIS__
	fprintf(stderr, "bad state, searching for FP=0...\n");
#endif
				FC_FP01 = 0b11; // FP=0 needed at the beginning
			} else {
				state_machine=STATE_STC;
				subchannel_id=0;
			}
		}
		break;
	}
	case STATE_STC: {
		stc_buff[bytes_readed - 9] = val;
		if(bytes_readed % 4 == 0) {
#ifndef  __SYNTHESIS__
	fprintf(stderr, "HEADER: stc_buff[%d]: 0x%08x | 0x%02x%02x%02x%02x\n", (int)subchannel_id, (uint32_t)collect_buff,
			(uint8_t)stc_buff[subchannel_id*4], (uint8_t)stc_buff[subchannel_id*4+1], (uint8_t)stc_buff[subchannel_id*4+2], (uint8_t)stc_buff[subchannel_id*4+3]);
#endif
//			stc_buff[subchannel_id*4] = collect_buff;
			subchannel_id++;
			if(subchannel_id == FC_NST/* || subchannel_id >= 64*/) {
				state_machine=STATE_EOH;
			}
		}
		break;
	}
	case STATE_EOH: {
		if(bytes_readed % 4 == 0) {
/*== Resource usage ===
SLICE:           91
LUT:            270
FF:             168
DSP:              0
BRAM:             0
SRL:              0 */
#if 1
			/*
			 * #=== Resource usage ===
SLICE:          138
LUT:            441
FF:             211
DSP:              0
BRAM:             0
SRL:              0
			 */

			if(crc != 0x1d0f) {
				initialized = false;
				state_machine = STATE_SYNC;
				break;
			} else {
				crc=0xFFFF;
			}

			//TODO: CHECK CRC and reset if needed!!!!!

			if(FC_FP01 != 0b00 && tist_is_sent == true) {
				if(FC_FP01==0b01) collect_buff.clear(23);
				if(FC_FP01==0b11) tist_is_sent = false;
				tist.write(((ap_uint<8>)collect_buff.range(30, 28)) * 10 + collect_buff.range(27, 24));//seconds | hours | months | LSB
				tist.write(((ap_uint<8>)collect_buff.range(23, 20)) * 10 + collect_buff.range(19, 16));//minutes | days  | years  | MSB
			}
#if 0
			switch(FC_FP01) {
//			case 0:
				//AT THIS STAGE WE SENDING TIST VALUE!!!!
//				send_ts = ((collect_buff.range(31, 24) & 0xCF) == 0) ? true : false;
//				break;
			case 1:
				collect_buff &= 0x3F3FFFFF;
			case 2:
			case 3: {
#if 0
				ap_uint<8> converted0 = 0;
				ap_uint<8> converted1 = 0;
				if(send_ts) {
					converted0 = collect_buff.range(31, 28) * 10 + collect_buff.range(27, 24);
					converted1 = collect_buff.range(23, 20) * 10 + collect_buff.range(19, 16);
				}
				tist.write(converted0);
				tist.write(converted1);
#else
				tist.write(collect_buff.range(31, 28) * 10 + collect_buff.range(27, 24));//seconds | hours | months | LSB
				tist.write(collect_buff.range(23, 20) * 10 + collect_buff.range(19, 16));//minutes | days  | years  | MSB
//				tist.write(collect_buff.range(31, 24)); //seconds | hours | months | LSB
//				tist.write(collect_buff.range(23, 16)); //minutes | days  | years  | MSB
#endif
				break;
			}
			default:
				break;
			}
#endif
#endif


#if 0
			if(FC_FP01 == 0b01) collect_buff &= 0x3F3FFFFF;
			ap_uint<8> byte0 = collect_buff.range(31, 28) * 10 + collect_buff.range(27, 24);
			ap_uint<8> byte1 = collect_buff.range(23, 20) * 10 + collect_buff.range(19, 16);
			//ap_uint<8> byte0 = mul_add(collect_buff.range(31, 28), 10, collect_buff.range(27, 24));
			//ap_wait_n(2);
			//ap_uint<8> byte1 = mul_add(collect_buff.range(23, 20), 10, collect_buff.range(19, 16));
			//ap_wait_n(2);

			switch(FC_FP01) {
			case 0:
				send_ts = (collect_buff.range(31, 24) & 0xCF) == 0;
				timestamp = 946684800;
				break;
			case 1:
				//timestamp += byte0 + byte1*60;
				timestamp += byte0;
				timestamp = mul_add(byte1, 60, timestamp);
				break;
			case 2:
				timestamp = mul_add(byte0, 3600, timestamp);
				timestamp = mul_add((byte1-1), 86400, timestamp);
				break;
			case 3:
			    if ((!(byte1%4)) && (byte0>2)) timestamp+=86400; // if the current year is a leap one -> add one day (86400 sec)
			    byte0--; // dec the current month (find how many months have passed from the current year)
			    while (byte0) // sum the days from January to the current month
			    {
			    	byte0--; // dec the month
			    	timestamp=mul_add((calendar[byte0]), 86400, timestamp); // add the number of days from a month * 86400 sec
			    }

			    timestamp =mul_add(((byte1)/4), 86400, timestamp); //add leap year's days
			    timestamp =mul_add((byte1), 365*86400, timestamp);
			    tist.write(timestamp.range(31,24));
			    tist.write(timestamp.range(23,16));
			    tist.write(timestamp.range(15,8));
			    tist.write(timestamp.range(7,0));
				break;
			default:
				break;
			}
#endif
			state_machine=STATE_FIC;
			bytes_readed_save = bytes_readed;
		}
		break;
	}
	case STATE_FIC: {
		u8stream y;
		if(bytes_readed - bytes_readed_save == 96) {
#ifndef  __SYNTHESIS__
	fprintf(stderr, "HEADER: FIC sent...\n");
#endif
			state_machine=STATE_SUBCHANNEL;
			subchannel_id=0;
			subchannel_header_sent=false;
			y.last=1;
		} else {
			y.last=0;
		}
		y.data=val;
		output.write(y);
		break;
	}
	case STATE_SUBCHANNEL: {
		if(!subchannel_header_sent){
#ifndef  __SYNTHESIS__
			fprintf(stderr, "HEADER: Subchannel %d header...\n", (int)subchannel_id);
#endif
			//y.data=stc_buff[subchannel_id].range(31,24);
#if 0
			y.data=0xC1;
			output.write(y);
			y.data=stc_buff[subchannel_id].range(31,24);
			output.write(y);
			y.data=stc_buff[subchannel_id].range(23,16);
			output.write(y);
			y.data=stc_buff[subchannel_id].range(15,8);
			output.write(y);
			y.data=stc_buff[subchannel_id].range(7,0);
			output.write(y);
#else
			u8stream y;
			y.last=0;
			y.data=0xC1;
			output.write(y);
			for(ap_uint<3> i=0; i<4; i++) {
				y.data=stc_buff[subchannel_id*4+i];
				output.write(y);
			}
#endif
			content_len = (ap_uint<10>) stc_buff[subchannel_id*4+2].range(2,0) << 8 | stc_buff[subchannel_id*4+3];
			subchannel_header_sent=true;
			bytes_readed_save = bytes_readed-1;
		}

		u8stream y;
		if(bytes_readed - bytes_readed_save == content_len*8) {
			subchannel_header_sent=false;
#ifndef  __SYNTHESIS__
	fprintf(stderr, "HEADER: Subchannel %d sent %d/%d bytes... stc: 0x%02x%02x%02x%02x\n",
			(int)subchannel_id, (int)(bytes_readed - bytes_readed_save), (int) content_len*8,
			(uint8_t)stc_buff[subchannel_id*4], (uint8_t)stc_buff[subchannel_id*4+1], (uint8_t)stc_buff[subchannel_id*4+2], (uint8_t)stc_buff[subchannel_id*4+3]);
#endif
			subchannel_id++;
			if(subchannel_id == FC_NST) {
				state_machine=STATE_EOF;
			}
			y.last=1;
		} else {
			y.last=0;
		}
		y.data=val;
		output.write(y);
		break;
	}
	case STATE_EOF: {
		if(bytes_readed % 4 == 0) {
			state_machine=STATE_TIST;
//			if(FC_FP01==0)
//				output.write((u8stream){0xD1, 0});
		} else if(bytes_readed % 2 == 0) {
			//check CRC
			if(crc != 0x1d0f) {
				initialized = false;
				state_machine = STATE_SYNC;
			}
		}
		break;
	}
	case STATE_TIST: {
//		u8stream y;
//		y.last=0;
		if(bytes_readed % 4 == 0) {
			state_machine=STATE_SYNC;
			if(FC_FP01==0 && tist_is_sent==false) {
				if(collect_buff.range(31,24) != 0xFF) collect_buff |= 0x00FFC000;
				tist.write(collect_buff.range(21,14)); //usec LSB
				tist.write(collect_buff.range(23,22)); //usec MSB
#if 0
				tist.write(0);
				tist.write(0);
				tist.write(0);
				tist.write(0);
				tist.write(0);
				tist.write(0);
#endif
				tist_is_sent = true;
			}
//			y.last=1;
		}
//		y.data=val;
//		if(FC_FP01==0)
//			output.write(y);
		break;
	}
	default:
		break;
	}
   }
  }
}


#else //use external ram

static ap_uint<32> collect_buff = 0x00;
static ap_uint<4> state_machine = STATE_SYNC;
static ap_uint<13> bytes_readed = 0;
static ap_uint<13> bytes_readed_save = 0;
static ap_uint<7>  subchannel_id = 0;
static ap_uint<7>  FC_NST = 0;
static ap_uint<2>  FC_FP01 = 0b11;
//static ap_uint<32> stc_buff[64];
static ap_uint<32> stc_buff[64];
static bool subchannel_header_sent=false;
/*
#=== Resource usage ===
SLICE:           82
LUT:            225
FF:             180
DSP:              0
BRAM:             1
SRL:              0
 * */
bool initialized = false;
void eti_parser(hls::stream<ap_uint<8> > &input, hls::stream<u8stream > &output, bool *out_aresetn)
{
//#pragma HLS ARRAY_PARTITION variable=stc_buff complete dim=1

#pragma HLS INTERFACE ap_fifo port=input
#pragma HLS INTERFACE ap_fifo port=output
#pragma HLS INTERFACE ap_none port=out_aresetn
#pragma HLS RESOURCE variable=input  core=AXIS metadata="-bus_bundle S_AXIS"
#pragma HLS RESOURCE variable=output core=AXIS metadata="-bus_bundle M_AXIS"
#pragma HLS INTERFACE ap_ctrl_none port=return

	ap_uint<8> val = input.read();
	collect_buff = collect_buff << 8 | val;
	bytes_readed++;

	if(!initialized) {
#ifndef  __SYNTHESIS__
	fprintf(stderr, "INIT...\n");
#endif
		initialized = true;
		*out_aresetn = false;
		ap_wait();
		ap_wait();
		ap_wait();
		*out_aresetn = true;
		ap_wait();
		ap_wait();
		ap_wait();
	}

	switch(state_machine) {
	case STATE_SYNC: {
#ifndef  __SYNTHESIS__
//	fprintf(stderr, "HEADER: %08x\n", (uint32_t)collect_buff);
#endif

		if(collect_buff == 0xFF073AB6 || collect_buff == 0xFFF8C549) {
			state_machine=STATE_FC;
			bytes_readed=4;
			u8stream y;
			y.last=0;
			y.data=0xF1;
			output.write(y);
		}
		break;
	}
	case STATE_FC: {
		u8stream y;
		y.last=0;
		y.data=val;
		output.write(y);
		if(bytes_readed==8) {
			FC_NST=collect_buff.range(22,16);

			#ifndef  __SYNTHESIS__
	fprintf(stderr, "HEADER: FC_NST=%d FC_FP01=0x%02x (prev: %02x)\n", (uint8_t)FC_NST, (uint8_t)collect_buff.range(14,13), (uint8_t)FC_FP01);
#endif

			FC_FP01++;
			if(FC_FP01!=collect_buff.range(14,13)) {
				initialized = false;
				state_machine=STATE_SYNC;
#ifndef  __SYNTHESIS__
	fprintf(stderr, "bad state, searching for FP=0...\n");
#endif
				FC_FP01 = 0b11; // FP=0 needed at the beginning
			} else {
				state_machine=STATE_STC;
				subchannel_id=0;
			}
		}
		break;
	}
	case STATE_STC: {
		if(bytes_readed % 4 == 0) {
#ifndef  __SYNTHESIS__
	fprintf(stderr, "HEADER: stc_buff[%d]: 0x%08x\n", (int)subchannel_id, (uint32_t)collect_buff);
#endif
			stc_buff[subchannel_id] = collect_buff;
			subchannel_id++;
			if(subchannel_id == FC_NST/* || subchannel_id >= 64*/) {
				state_machine=STATE_EOH;
			}
		}
		break;
	}
	case STATE_EOH: {
		if(bytes_readed % 4 == 0) {
			state_machine=STATE_FIC;
			bytes_readed_save = bytes_readed;
		}
		break;
	}
	case STATE_FIC: {
		u8stream y;
		if(bytes_readed - bytes_readed_save == 96) {
#ifndef  __SYNTHESIS__
	fprintf(stderr, "HEADER: FIC sent...\n");
#endif
			state_machine=STATE_SUBCHANNEL;
			subchannel_id=0;
			subchannel_header_sent=false;
			y.last=1;
		} else {
			y.last=0;
		}
		y.data=val;
		output.write(y);
		break;
	}
	case STATE_SUBCHANNEL: {
		if(!subchannel_header_sent){
#ifndef  __SYNTHESIS__
	fprintf(stderr, "HEADER: Subchannel %d header...\n", (int)subchannel_id);
#endif
			//y.data=stc_buff[subchannel_id].range(31,24);
#if 0
			y.data=0xC1;
			output.write(y);
			y.data=stc_buff[subchannel_id].range(31,24);
			output.write(y);
			y.data=stc_buff[subchannel_id].range(23,16);
			output.write(y);
			y.data=stc_buff[subchannel_id].range(15,8);
			output.write(y);
			y.data=stc_buff[subchannel_id].range(7,0);
			output.write(y);
#else
			for(ap_uint<3> i=0; i<5; i++) {
				u8stream y;
				switch(i) {
				case 0:
					y.data=0xC1;
					break;
				case 1:
					y.data=stc_buff[subchannel_id].range(31,24);
					break;
				case 2:
					y.data=stc_buff[subchannel_id].range(23,16);
					break;
				case 3:
					y.data=stc_buff[subchannel_id].range(15,8);
					break;
				default:
					y.data=stc_buff[subchannel_id].range(7,0);
					break;
				}
				y.last=0;
				output.write(y);
			}
#endif
			subchannel_header_sent=true;
			bytes_readed_save = bytes_readed-1;
		}


		u8stream y;
		if(bytes_readed - bytes_readed_save == stc_buff[subchannel_id].range(9,0)*8) {
			subchannel_header_sent=false;
#ifndef  __SYNTHESIS__
	fprintf(stderr, "HEADER: Subchannel %d sent %d/%d bytes...\n",
			(int)subchannel_id, (int)(bytes_readed - bytes_readed_save), (int)stc_buff[subchannel_id].range(9,0)*8);
#endif

			subchannel_id++;
			if(subchannel_id == FC_NST) {
				state_machine=STATE_EOF;
			}
			y.last=1;
		} else {
			y.last=0;
		}
		y.data=val;
		output.write(y);
		break;
	}
	case STATE_EOF: {
		if(bytes_readed % 4 == 0) {
			state_machine=STATE_TIST;
		}
		break;
	}
	case STATE_TIST: {
		if(bytes_readed % 4 == 0) {
			state_machine=STATE_SYNC;
		}
		break;
	}

	}
}


#endif

