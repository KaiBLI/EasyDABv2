
#include <ap_int.h>
#include <ap_utils.h>

#include "dab_bytework.h"
/*

*/

static ap_uint<8> shared_bram[(256)+(280)+(280+18)+(14)] = {
	//eti buffer[256]:
	0,0,0,0,        0,0,0,0,        0,0,0,0,        0,0,0,0,
	0,0,0,0,        0,0,0,0,        0,0,0,0,        0,0,0,0,
	0,0,0,0,        0,0,0,0,        0,0,0,0,        0,0,0,0,
	0,0,0,0,        0,0,0,0,        0,0,0,0,        0,0,0,0,
	0,0,0,0,        0,0,0,0,        0,0,0,0,        0,0,0,0,
	0,0,0,0,        0,0,0,0,        0,0,0,0,        0,0,0,0,
	0,0,0,0,        0,0,0,0,        0,0,0,0,        0,0,0,0,
	0,0,0,0,        0,0,0,0,        0,0,0,0,        0,0,0,0,
	0,0,0,0,        0,0,0,0,        0,0,0,0,        0,0,0,0,
	0,0,0,0,        0,0,0,0,        0,0,0,0,        0,0,0,0,
	0,0,0,0,        0,0,0,0,        0,0,0,0,        0,0,0,0,
	0,0,0,0,        0,0,0,0,        0,0,0,0,        0,0,0,0,
	0,0,0,0,        0,0,0,0,        0,0,0,0,        0,0,0,0,
	0,0,0,0,        0,0,0,0,        0,0,0,0,        0,0,0,0,
	0,0,0,0,        0,0,0,0,        0,0,0,0,        0,0,0,0,
	0,0,0,0,        0,0,0,0,        0,0,0,0,        0,0,0,0,
	//sizes_data[280] :
	3,5,13,3,		3,4,14,3,		3,4,14,3,		3,3,18,0,		3,4,17,0,
	3,5,25,3,		3,4,26,3,		3,4,26,3,		3,4,26,3,		4,3,26,3,/*3,4,26,3,*/
	0,0,0,0,		6,10,23,3,		6,12,21,3,		6,10,23,3,		6,10,23,3,
	6,11,28,3,		6,10,29,3,		6,12,27,3,		6,9,33,0,		6,9,31,2,
	6,10,41,3,		6,10,41,3,		6,11,40,3,		6,10,41,3,		6,10,41,3,
	6,13,50,3,		6,10,53,3,		6,12,51,3,		7,10,52,3,		7,9,53,3,
	0,0,0,0,		11,21,49,3,		11,23,47,3,		11,21,49,3,		14,17,50,3,
	11,20,62,3, 	11,21,61,3,		11,22,60,3,		11,21,61,3,		12,19,62,3,
	11,22,84,3, 	11,21,85,3,		11,24,82,3,		11,23,83,3,		11,19,87,3,
	11,21,109,3,	11,20,110,3,	11,24,106,3,	11,22,108,3,	11,20,110,3,
	11,24,130,3,	11,22,132,3,	11,20,134,3,	12,26,127,3,	12,22,131,3,
	11,26,152,3,	11,22,156,3,	11,27,151,3,	11,24,154,3,	11,24,154,3,
	0,0,0,0,		11,26,200,3,	0,0,0,0,		11,25,201,3,	11,26,200,3,
	12,28,245,3,	0,0,0,0,		11,24,250,3,	0,0,0,0,		11,27,247,3,
	//rules_data[280+18]
	P24,P17,P12,P17,	P22,P13,P8,P13,		P15,P9,P6,P8,	P11,P6,P5,0,	P5,P3,P2,0,
	P24,P18,P13,P18,	P24,P14,P8,P15,		P15,P10,P6,P9,	P9,P6,P4,P6,	P5,P4,P2,P3,
	0,0,0,0, 			P23,P13,P8,P13,		P16,P7,P6,P9,	P9,P6,P4,P5,	P5,P4,P2,P3,
	P24,P18,P12,P18,	P23,P13,P8,P13,		P16,P8,P6,P9,	P11,P6,P5,0,	P5,P3,P2,P3,
	P24,P17,P12,P18,	P23,P13,P8,P13,		P16,P8,P6,P7,	P11,P6,P5,P6,	P6,P3,P2,P3,
	P24,P18,P13,P19,	P22,P12,P9,P12,		P16,P9,P6,P10,	P9,P6,P4,P6,	P5,P4,P2,P4,
	0,0,0,0,			P23,P12,P9,P14,		P16,P8,P6,P9,	P9,P6,P4,P8,	P5,P4,P2,P5,
	P24,P17,P13,P19,	P22,P12,P9,P14,		P16,P9,P6,P10,	P11,P6,P5,P7,	P5,P3,P2,P4,
	P24,P18,P12,P19,	P22,P11,P9,P13,		P16,P8,P6,P11,	P11,P6,P5,P9,	P5,P4,P2,P4,
	P24,P20,P13,P24,	P22,P13,P9,P13,		P16,P10,P6,P11,	P10,P6,P4,P9,	P6,P4,P2,P5,
	P24,P20,P12,P20,	P24,P16,P10,P15,	P16,P10,P7,P9,	P12,P8,P4,P11,	P8,P6,P2,P6,
	P24,P19,P14,P18,	P24,P14,P10,P13,	P16,P10,P7,P10,	P12,P9,P5,P10,	P6,P5,P2,P5,
	0,0,0,0,			P24,P17,P9,P17,		0,0,0,0,		P13,P9,P5,P10,	P8,P5,P2,P6,
	P24,P20,P14,P23,	0,0,0,0,			P16,P9,P7,P10,	0,0,0,0,		P8,P6,P2,P7,
	/* 18 x EEP rules: */
	P24,P23,	P14,P13,	P8,P7,	P3,P2,
	P10,P9,		P6,P5,		P4,P3,	P2,P1,
	P13,P12, /* <== (bitrate_in_cu = 1 && protectionLevel == 1 && protectionOption == 0) */
	//bitrates_in_cu_data[14]
	4,6,7,8,10,12,14,16,20,24,28,32,40,48
};



static hls::stream<ap_uint<8> > eti2tist;
static hls::stream<u8stream > eti2prbs;
static hls::stream<u8stream > prbs2conv;
static hls::stream<u8stream > conv2punct;

/*
#=== Resource usage ===
SLICE:          501
LUT:           1410
FF:            1002
DSP:              2
BRAM:             0
SRL:             28
#=== Final timing ===
CP required:    10.000
CP achieved:    8.239
*/

void dab_bytework(hls::stream<ap_uint<8> > &input, hls::stream<u8stream > &output, hls::stream<ap_uint<8> > &tist,
		volatile bool *out_aresetn, ap_uint<8> bram0[256], const ap_uint<8> bram1[(256)+(280)+(280+18)+(14)])
{
#pragma HLS DATAFLOW

//#pragma HLS STREAM variable=dqpsk2pifft depth=15
//#pragma HLS STREAM variable=mi2dqpsk depth=15
//#pragma HLS STREAM variable=fm2mi depth=15

//#pragma HLS RESOURCE variable=dqpsk2pifft core=FIFO_SRL
//#pragma HLS RESOURCE variable=fm2mi core=FIFO_SRL
//#pragma HLS RESOURCE variable=mi2dqpsk core=FIFO_SRL


//#pragma HLS INTERFACE ap_memory depth=1 port=shared_bram

//#pragma HLS RESOURCE variable=packed_data_ext core=ROM_1P_BRAM
//#pragma HLS RESOURCE variable=bram0 core=RAM_1P_BRAM
//#pragma HLS RESOURCE variable=bram1 core=RAM_1P_BRAM
#pragma HLS INTERFACE ap_memory port=bram0
#pragma HLS INTERFACE ap_memory port=bram1

#pragma HLS INTERFACE ap_fifo port=input
#pragma HLS INTERFACE ap_fifo port=output
#pragma HLS INTERFACE ap_fifo port=tist

//#pragma HLS DATA_PACK variable=input
#pragma HLS DATA_PACK variable=output
#pragma HLS DATA_PACK variable=eti2prbs
#pragma HLS DATA_PACK variable=eti2tist
#pragma HLS DATA_PACK variable=prbs2conv
#pragma HLS DATA_PACK variable=conv2punct

#pragma HLS STREAM variable=eti2prbs depth=15
#pragma HLS STREAM variable=eti2tist depth=15
#pragma HLS STREAM variable=prbs2conv depth=15
#pragma HLS STREAM variable=conv2punct depth=15
//#pragma HLS STREAM variable=eti2prbs depth=31
//#pragma HLS STREAM variable=prbs2conv depth=31
//#pragma HLS STREAM variable=conv2punct depth=31

#pragma HLS RESOURCE variable=eti2tist core=FIFO_SRL
#pragma HLS RESOURCE variable=eti2prbs core=FIFO_SRL
#pragma HLS RESOURCE variable=prbs2conv core=FIFO_SRL
#pragma HLS RESOURCE variable=conv2punct core=FIFO_SRL

//#pragma HLS RESOURCE variable=input  core=AXIS metadata="-bus_bundle S_AXIS"
//#pragma HLS RESOURCE variable=output core=AXIS metadata="-bus_bundle M_AXIS"
//#pragma HLS RESOURCE variable=tist core=AXIS metadata="-bus_bundle M_TIST_AXIS"
#pragma HLS RESOURCE variable=input  core=FIFO_SRL metadata="-bus_bundle S_FIFO"
#pragma HLS RESOURCE variable=output core=FIFO_SRL metadata="-bus_bundle M_FIFO"
#pragma HLS RESOURCE variable=tist core=FIFO_SRL metadata="-bus_bundle M_TIST_FIFO"
//#pragma HLS RESOURCE variable=tist core=FIFO_SRL

#pragma HLS INTERFACE ap_none port=out_aresetn

#pragma HLS INTERFACE ap_ctrl_none port=return


	eti_parser(input, eti2prbs, out_aresetn, eti2tist, bram0);

	prbs(eti2prbs, prbs2conv);
	convolution(prbs2conv, conv2punct);

	puncturing(conv2punct, output, bram1);

	date2time(eti2tist, tist);
}

