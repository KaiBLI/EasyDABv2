
#include <ap_int.h>
#include <ap_utils.h>
#include <hls_stream.h>

#include "dab_bytework.h"



#include <ap_int.h>
#include <ap_utils.h>
#include <hls_stream.h>

#if 0
typedef enum {
	P1=0,
	P2,
	P3,
	P4,
	P5,
	P6,
	P7,
	P8,
	P9,
	P10,
	P11,
	P12,
	P13,
	P14,
	P15,
	P16,
	P17,
	P18,
	P19,
	P20,
	P21,
	P22,
	P23,
	P24
} rulen_num;


typedef struct {
	ap_uint<8> data;
	ap_uint<1> last;
} u8stream;
#endif

ap_uint<32> ruleVal(ap_uint<5> ruleId)
{
#pragma HLS inline
	ap_uint<32> result = 0;
	ap_uint<4> passed = 0;
	ap_uint<5> bitSet = 30;
	do {
		result.set(bitSet,true);
		passed++;
		bitSet -= 16;
		if(passed==2||passed==6)
			bitSet -= 8;
		if(passed==4)
			bitSet += 4;
	} while(passed <= ruleId.range(2,0));

	for(passed=ruleId.range(4,3);passed>0;passed--)
		result = (result >> 1) | 0x44444444;

	return (result | 0x88888888);
}


static ap_uint<6> STC_TPL;
static ap_uint<10> STC_STL;

static ap_uint<8> sizes_data_arr[4] = {0,0,0,0};
static ap_uint<5> rules_data_arr[4] = {0,0,0,0};

bool search_subchannel_rules(const ap_uint<8> packed_data_ext[(256)+(280)+(280+18)+(14)])
{
#pragma HLS inline
//#pragma HLS ARRAY_PARTITION variable=eep_rules_data complete dim=1
//#pragma HLS ARRAY_PARTITION variable=bitrates_in_cu_data complete dim=1

//#pragma HLS ARRAY_PARTITION variable=sizes_data complete dim=1
//#pragma HLS ARRAY_PARTITION variable=rules_data complete dim=1
//#pragma HLS ARRAY_MAP variable=bitrates_in_cu_data instance=packed1 horizontal
//#pragma HLS ARRAY_PARTITION variable=sizes_data complete dim=1
//#pragma HLS ARRAY_PARTITION variable=rules_data complete dim=1

//	rules_data[rules_num].size = 96, 0xeeeeeeee};
//	rules_data[rules_num].size = 176, 0xcccccccc};
//	rules_data[rules_num].size = 640, 0xccc8ccc8};
//	rules_data[rules_num].size = 48, 0xccccccc8};
	//rules_data[rules_num].size = };
//	 fprintf(stderr, "Division by 3 (STC.STL=%d): %d == %d ?\n", (int)STC.STL, (int)bitrate_in_cu, (int)STC.STL/3);

    ap_uint<10> rule_data_id = 0;
    bool error = false;

//	const ap_uint<8> *sizes_ptr;
//	const ap_uint<32> *rules_ptr;
	ap_uint<3> protectionLevel = STC_TPL.range(2,0);
	ap_uint<10> bitrate_in_cu0 = STC_STL;// / 3;
	ap_uint<9> bitrate_in_cu=0;
	//division by 3 without DSP48A1
	while(bitrate_in_cu0 >= 3) {
		bitrate_in_cu0-=3;
		bitrate_in_cu++;
	}
#ifndef  __SYNTHESIS__
        	fprintf(stderr, "[HARD] bitrate_in_cu=%d\n", (int)bitrate_in_cu);
#endif
	if (STC_TPL.bit(5)) { //is EEP
		protectionLevel &= 3;
		bitrate_in_cu <<= 1;

        	ap_uint<3> protectionOption = STC_TPL.range(4,2);
        	rule_data_id = (protectionOption * 4 + protectionLevel)*2;

#ifndef  __SYNTHESIS__
        	fprintf(stderr, "[HARD] is EEP bitrate_in_cu2=%d, protectionOption=%d, protectionLevel=%d rule_data_id=%d\n", (int)bitrate_in_cu,
        			(int)protectionOption, (int)protectionLevel, (int)rule_data_id);
#endif


            if (protectionOption == 1 || protectionLevel==0 || protectionLevel==2) {
            	//EEP-B or 1-A or 3-A
            	sizes_data_arr[0] = ((3 * bitrate_in_cu) - 3);
            	sizes_data_arr[1] = 3;
#ifndef  __SYNTHESIS__
            	fprintf(stderr, "[HARD] sizes_data_arr[0]=%u, sizes_data_arr[1]=%u, rule_data_id=%u\n",
            			(uint8_t)sizes_data_arr[0], (uint8_t)sizes_data_arr[1], (uint16_t)rule_data_id);
#endif
            } else if(protectionLevel == 1) {
            	if(bitrate_in_cu == 2) {
            		sizes_data_arr[0] = 5;
            		sizes_data_arr[1] = 1;
            		rule_data_id = 4*2 * 2;
            	} else {
                	sizes_data_arr[0] = ((bitrate_in_cu) - 3);
                	sizes_data_arr[1] = ((2 * bitrate_in_cu) + 3);
            	}
            } else if(protectionLevel == 3) {
            	sizes_data_arr[0] = ((2 * bitrate_in_cu) - 3);
            	sizes_data_arr[1] = ((bitrate_in_cu) + 3);
            } else {
                error = true; //produce error
            }
            rule_data_id += 280;
            //rules_data_arr[0] = rules_data[rule_data_id];
            //rules_data_arr[1] = rules_data[rule_data_id+1];
            rules_data_arr[0] = packed_data_ext[(256)+(280)+rule_data_id];
            rules_data_arr[1] = packed_data_ext[(256)+(280)+rule_data_id+1];
#ifndef  __SYNTHESIS__
            	fprintf(stderr, "[HARD] rules_data_arr[0]=%08x (%d), rules_data_arr[1]=%08x (%d), rule_data_id=%u\n",
            			(uint32_t)ruleVal(rules_data_arr[0]), (int)rules_data_arr[0],
            			(uint32_t)ruleVal(rules_data_arr[1]), (int)rules_data_arr[1],
            			(uint16_t)((256)+(280)+rule_data_id));
#endif
    } else {
        ap_uint<4> cnt=0;

        do {
        	//if (bitrate_in_cu == bitrates_in_cu_data[cnt])
        	if (bitrate_in_cu == packed_data_ext[(256)+(280)+(280+18)+cnt])
        		break;
        	cnt++;
        } while (cnt < 14);

        if(cnt==14)
        	return true;

        rule_data_id = cnt*5*4 + protectionLevel*4;

#ifndef  __SYNTHESIS__
        fprintf(stderr, "[HARD] cnt=%d, protectionLevel=%d, rule_data_id=%d\n", (int)cnt, (int)protectionLevel, (int)rule_data_id);
#endif
/*
#=== Resource usage ===
SLICE:          177
LUT:            459
FF:             434
DSP:              0
BRAM:             1
SRL:              0
        for(ap_uint<3> cnt2=0;cnt2<4;cnt2++) {
        	sizes_data_arr[cnt2] = sizes_data[rule_data_id+cnt2];
            rules_data_arr[cnt2] = rules_data[rule_data_id+cnt2];
        };
        */
/*
#=== Resource usage ===
SLICE:          143
LUT:            467
FF:             434
DSP:              0
BRAM:             1
SRL:              0*/
        for(cnt=0;cnt<4;cnt++) {
        	//sizes_data_arr[cnt] = sizes_data[rule_data_id+cnt];
        	sizes_data_arr[cnt] = packed_data_ext[(256)+rule_data_id+cnt];
            //rules_data_arr[cnt] = rules_data[rule_data_id+cnt];
        	rules_data_arr[cnt] = packed_data_ext[(256)+(280)+rule_data_id+cnt];
#ifndef  __SYNTHESIS__
        fprintf(stderr, "[HARD] sizes_data_arr[%d]=%d, rules_data_arr[%d]=%d\n",
        		(int)sizes_data_arr[cnt], (int)cnt, (int)rules_data_arr[cnt], (int)cnt);
//    	fprintf(stderr, "[HARD] rule[%d] length=%d, pattern=%08x\n",
//    			cnt, ((int)sizes_data_arr[cnt])*16, (uint32_t)ruleVal(rules_data_arr[cnt]));

#endif
        };
    }

	return error;
}

void puncture_stream(hls::stream<u8stream > &input, hls::stream<u8stream > &output, bool is_subchannel, const ap_uint<8> packed_data_ext[(256)+(280)+(280+18)+(14)])
{
#pragma HLS inline
//#pragma HLS ARRAY_MAP variable=sizes_data instance=packed1 vertical
//#pragma HLS ARRAY_MAP variable=rules_data instance=packed1 vertical

//#pragma HLS ARRAY_MAP variable=eep_rules_data instance=packed1 horizontal
//#pragma HLS ARRAY_MAP variable=rules_data_val_hi instance=packed1 horizontal
//#pragma HLS ARRAY_MAP variable=rules_data_val_lo instance=packed1 horizontal

//#pragma HLS ARRAY_MAP variable=sizes_data instance=packed1 horizontal
//#pragma HLS ARRAY_MAP variable=rules_data instance=packed1 horizontal
//#pragma HLS ARRAY_MAP variable=bitrates_in_cu_data instance=packed1 horizontal

//#pragma HLS ARRAY_MAP variable=bitrates_in_cu_data instance=packed1 vertical

//#pragma HLS ARRAY_PARTITION variable=bitrates_in_cu_data complete dim=1

	u8stream val;
    u8stream y;
    ap_uint<9> counter = 0;
    ap_uint<4> rule_id = 0;
    #ifndef  __SYNTHESIS__
        int out_count=0;
    #endif
        ap_uint<4> bit_count=0;
        ap_uint<8> out = 0;

   	sizes_data_arr[0] = 21;
   	sizes_data_arr[1] = 3;
   	sizes_data_arr[2] = 0;
   	sizes_data_arr[3] = 0;
	rules_data_arr[0] = P16;
	rules_data_arr[1] = P15;

//   	rules_data_arr[0] = 0;
//   	rules_data_arr[1] = 0;
//   	rules_data_arr[2] = 0;
//   	rules_data_arr[3] = 0;

    if(is_subchannel)
    	if(search_subchannel_rules(packed_data_ext))
    		return;

    val.last=0;
    y.last=0;

#ifndef  __SYNTHESIS__
    int i;
    for(i=0;i<4;i++)
    	fprintf(stderr, "[HARD] rule[%d] length=%d, pattern=%08x\n", i, ((int)sizes_data_arr[i])*16, (uint32_t)ruleVal(rules_data_arr[i]));
    fprintf(stderr, "[HARD] rule[%d] length=%d, pattern=%08x\n", i, 3, 0x00cccccc);
#endif


    do {

    	ap_uint<12> length = 3;
    	ap_uint<32> pattern = 0x00cccccc;
    	ap_uint<3> length2check=3;
    	if(rule_id != 4) {
    		length = sizes_data_arr[rule_id]*16;
    		pattern = ruleVal(rules_data_arr[rule_id]);
    		length2check=4;
    	}
#ifndef  __SYNTHESIS__
    	ap_int<12> length2 = length;
#endif
    	for (;  length != 0; length -= length2check) {
#ifndef  __SYNTHESIS__
        	fprintf(stderr, "[HARD] length=%d/%d, pattern=%08x\n", (int)length, (int)length2, (uint32_t)pattern);
#endif
        	ap_uint<32> mask = 0x80000000;
        	if(rule_id == 4)
        		mask >>= 8;


        	for (ap_uint<3> i = 0; i < length2check; ++i) {
            	//uint8_t data = in[in_count++];
            	val = input.read();
            	ap_uint<8> data = val.data;
                //for (ap_uint<4> j = 0; j < 8; ++j) {
            	for (ap_uint<4> j = 0; j < 8; ++j) {
                    if (pattern & mask) {
                        out <<= 1;
                        out |= data >> 7;

                        //out |= data.bit(7-j);
                        /*write resulted data after doing 8 bit logic operations */
                        if (++bit_count == 8) {
                            bit_count = 0;
#ifndef  __SYNTHESIS__
                            ++out_count;
#endif
                            y.data = out;
                            if(rule_id == 4 && i == length2check-1) {
#ifndef  __SYNTHESIS__
                            	fprintf(stderr, "[HARD] last: %d\n", out_count);
#endif
                            	y.last=1;
                            }
                            output.write(y);
                            counter++;
                        	out = 0;
                        }
                    }
                    data <<= 1;
                    mask >>= 1;
                }
            }
        }
        if (++rule_id == 5) {
#ifndef  __SYNTHESIS__
        	fprintf(stderr, "reset rules\n");
#endif
        	rule_id = 0;
        }
    } while (!val.last && !y.last);

    while (bit_count) {
#ifndef  __SYNTHESIS__
    	fprintf(stderr, "[SOFT] adding bits...\n");
#endif
        out <<= 1;
        if (++bit_count == 8) {
            bit_count = 0;
            //++out_count;
            y.data = out;
            y.last=1;
            output.write(y);
            counter++;
        }
    }
}


void puncturing(hls::stream<u8stream > &input, hls::stream<u8stream > &output,
		const ap_uint<8> packed_data_ext[(256)+(280)+(280+18)+(14)])
{


//#pragma HLS ARRAY_PARTITION variable=sizes_data complete dim=1
//#pragma HLS ARRAY_PARTITION variable=eep_rules_data complete dim=1

//#pragma HLS ARRAY_PARTITION variable=rules_data complete dim=1
//#pragma HLS ARRAY_PARTITION variable=sizes_data_arr complete dim=1
//#pragma HLS ARRAY_PARTITION variable=rules_data_arr complete dim=1

//#pragma HLS ARRAY_PARTITION variable=eep_rules_data block factor=1 dim=1
//#pragma HLS ARRAY_PARTITION variable=rules_data block factor=1 dim=2
//#pragma HLS ARRAY_PARTITION variable=sizes_data block factor=1 dim=2

	//#pragma HLS ARRAY_MAP variable=sizes_data instance=packed1 vertical
	//#pragma HLS ARRAY_MAP variable=rules_data instance=packed1 vertical
	//#pragma HLS ARRAY_MAP variable=rules_data_eep instance=packed1 vertical
	//#pragma HLS ARRAY_MAP variable=sizes_data_arr instance=packed1 vertical
	//#pragma HLS ARRAY_MAP variable=rules_data_arr instance=packed1 vertical

//#pragma HLS INTERFACE ap_memory port=packed_data_ext
//#pragma HLS RESOURCE variable=packed_data_ext core=ROM_1P_BRAM

#pragma HLS INTERFACE ap_memory port=packed_data_ext
#pragma HLS RESOURCE variable=packed_data_ext core=RAM_1P_BRAM

#pragma HLS INTERFACE ap_fifo port=input
#pragma HLS INTERFACE ap_fifo port=output
//#pragma HLS RESOURCE variable=input  core=AXIS metadata="-bus_bundle S_AXIS"
//#pragma HLS RESOURCE variable=output core=AXIS metadata="-bus_bundle M_AXIS"
#pragma HLS INTERFACE ap_ctrl_none port=return

	u8stream val = input.read();
	ap_uint<8> block_type = val.data;
	bool is_subchannel=true;

	//switch(block_type) {
	switch(block_type) {
	case 0xF1:

        //y.data = FC.FCT % 4;
        //bytes2fc(input, &FC);
        is_subchannel=false;

#ifndef  __SYNTHESIS__
//        	fprintf(stderr, "[HARD] FCT=%d, FICF=%d, fl_addr=%d, FP=%d, MID=%d, NST=%d\n",
//        			(int) FC.FCT, (int) FC.FICF, (int) FC.FL, (int) FC.FP, (int) FC.MID, (int) FC.NST);
#endif
		// write frame id 0..3
//        if(FC.FICF && FC.MID == 1) {

//    	*debug = puncture_stream(input, output, false);

        //} //else {
    	//	while(!val.last)
    	//		val = input.read();
        //}
//		break;

	case 0xC1: {

//        if(FC.FICF && FC.MID == 1) {
            u8stream y;
            y.last=0;
            y.data = block_type;
            output.write(y);

            /* send STC/FC */
        	for(ap_uint<3> i = 0; i<4; i++) {
        		val = input.read();
    #ifndef  __SYNTHESIS__
    	fprintf(stderr, "[HARD] sending STC/FC: %02x\n", (uint8_t)val.data);
    #endif
        		y.data=val.data;
        		output.write(y);
        		if(is_subchannel && i==2) {
        			STC_TPL=val.data.range(7,2);
        			STC_STL=val.data.range(1,0);
        		}
        		if(is_subchannel && i==3) {
        			STC_STL <<= 8;
        			STC_STL |= val.data;
        		}
        	}

		puncture_stream(input, output, is_subchannel, packed_data_ext);







//    		if(!error)
//    		else
//    			*debug=2;
//        } else {
//#ifndef  __SYNTHESIS__
//        	fprintf(stderr, "[HARD] not ok! FC.FICF=%d, FC.MID=%d\n", (int)FC.FICF, (int)FC.MID);
//#endif
//    		while(!val.last)
//    			val = input.read();
//        }


		break;
	}
	/* temp hack to passthru unpunctured data */
	default:
//	case 0xF2:
//	case 0xC2:
	{
        u8stream y;
        y.last=0;
        //y.data = block_type-1;
        y.data = block_type;
        output.write(y);

		do {
#pragma HLS loop_tripcount min=289 max=6913 avg=6913
			val = input.read();
			y.data = val.data;
			y.last = val.last;
			output.write(y);
		} while (!val.last);
		break;
	}
//	default:
//		*debug=2;
//		while(!val.last)
//			val = input.read();
//		break;
	}
}
