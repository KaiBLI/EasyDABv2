

#include <ap_int.h>
#include <ap_utils.h>
#include <hls_stream.h>




ap_uint<32> mul_add(ap_uint<9> x, ap_uint<25> y, ap_uint<32> z)
{
#pragma HLS INLINE off

	return x*y + z;
}


//static const ap_uint<5> calendar[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
//static const ap_uint<9> calendar[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
static const ap_uint<9> calendar2[13] = {0, 0,
		31,
		(31+28),
		(31+28+31),
		(31+28+31+30),
		(31+28+31+30+31),
		(31+28+31+30+31+30),
		(31+28+31+30+31+30+31),
		(31+28+31+30+31+30+31+31),
	    (31+28+31+30+31+30+31+31+30),
	    (31+28+31+30+31+30+31+31+30+31),
	    (31+28+31+30+31+30+31+31+30+31+30)};


enum {
	STATE_INIT = 0,
	STATE_USEC_LSB,
	STATE_USEC_MSB,
	STATE_SEC,
	STATE_MIN,
	STATE_HOUR,
	STATE_DAY,
	STATE_MON,
	STATE_YEAR0,
	STATE_YEAR1,
//	STATE_YEAR2,
	STATE_SEND0,
	STATE_SEND1,
	STATE_SEND2,
	STATE_SEND3
};

#if 0
if(bytes_readed % 4 == 1) {
	switch(FC_FP01) {
	case 1://sec
		//timestamp = 946684800 - 315964800 + byte00;
		timestamp = mul_add(byte00, 1, 946684800 - 315964800);
		break;
	case 2://hour
		timestamp = mul_add(byte00, 60*60, timestamp);
//				LOOP21:while(byte00) {
//#pragma HLS PIPELINE II=1
//#pragma HLS loop_tripcount min=0 max=24 avg=12
//					timestamp += 60*60;
//					byte00--;
//				}
		break;
	case 3://mon
#if 0
	    switch(byte00) {
	    default: 0; break;
	    case 2:  timestamp+=60*60*24*31; break;
	    case 3:  timestamp+=60*60*24*(31+28); break;
	    case 4:  timestamp+=60*60*24*(31+28+31); break;
	    case 5:  timestamp+=60*60*24*(31+28+31+30); break;
	    case 6:  timestamp+=60*60*24*(31+28+31+30+31); break;
	    case 7:  timestamp+=60*60*24*(31+28+31+30+31+30); break;
	    case 8:  timestamp+=60*60*24*(31+28+31+30+31+30+31); break;
	    case 9:  timestamp+=60*60*24*(31+28+31+30+31+30+31+31); break;
	    case 10: timestamp+=60*60*24*(31+28+31+30+31+30+31+31+30); break;
	    case 11: timestamp+=60*60*24*(31+28+31+30+31+30+31+31+30+31); break;
	    case 12: timestamp+=60*60*24*(31+28+31+30+31+30+31+31+30+31+30); break;
	    }
#endif
	    timestamp = mul_add(calendar2[byte00], 60*60*24, timestamp);
		break;
	default:
		break;
	}

} else
if(bytes_readed % 4 == 2) {
	switch(FC_FP01) {
	case 1://min
//				LOOP11:while(byte00) {
//#pragma HLS PIPELINE II=1
//#pragma HLS loop_tripcount min=0 max=59 avg=30
//					timestamp += 60;
//					byte00--;
//				}
		timestamp = mul_add(byte00, 60, timestamp);
		break;
	case 2://day
//				LOOP22:while(byte00 != 1) {
//#pragma HLS PIPELINE II=1
//#pragma HLS loop_tripcount min=0 max=31 avg=15
//					timestamp += 86400;
//					byte00--;
//				}
		timestamp = mul_add(byte00-1, 86400, timestamp);
		break;
	case 3://year
//				LOOP32:while(byte00) {
//#pragma HLS PIPELINE II=1
//#pragma HLS loop_tripcount min=0 max=99 avg=50
//					timestamp += 365*86400;
//					if (!(byte00%4)) timestamp+=86400;
//					byte00--;
//				}
		timestamp = mul_add(byte00, 365*86400, timestamp);
		timestamp = mul_add(byte00/4, 86400, timestamp);
		break;
	default:
		break;
	}

#endif
	/*
#=== Resource usage ===
SLICE:           70
LUT:            197
FF:             147
DSP:              2
BRAM:             0
SRL:              9
#=== Final timing ===
	 */
void date2time(hls::stream<ap_uint<8> > &stream_in, hls::stream<ap_uint<8> > &stream_out)
{
#pragma HLS ARRAY_PARTITION variable=calendar2 complete dim=1

#pragma HLS INTERFACE ap_fifo port=stream_in
//#pragma HLS RESOURCE variable=stream_in  core=AXIS metadata="-bus_bundle S_AXIS"

#pragma HLS INTERFACE ap_fifo port=stream_out
//#pragma HLS RESOURCE variable=stream_out  core=AXIS metadata="-bus_bundle M_AXIS"

#pragma HLS INTERFACE ap_ctrl_none port=return

	ap_uint<9> val;
	ap_uint<4> mon_saved;
	ap_uint<8> year_saved;
	ap_uint<32> timestamp;
	ap_uint<32> multiplier;

	ap_uint<4> state = STATE_USEC_LSB;

	//71-183-181-2-0-9
	//54-114-186-2-0-9
	LOOP00:do {
#pragma HLS loop_tripcount min=16 max=16 avg=16
		if (state < STATE_YEAR1)
			val = stream_in.read();

		switch(state) {
		case STATE_USEC_LSB:
		case STATE_USEC_MSB:
			stream_out.write(val);
			timestamp = 946684800 - 315964800; //2000 year - 1980
			multiplier=0;
			break;
		case STATE_SEC:
#ifndef  __SYNTHESIS__
			if(val > 59)
			fprintf(stderr, "TIME: bad sec: %d", (int)val);
#endif
			multiplier=1;
			break;
		case STATE_MIN:
#ifndef  __SYNTHESIS__
			if(val > 59)
			fprintf(stderr, "TIME: bad minute: %d", (int)val);
#endif
			multiplier=60;
			break;
		case STATE_HOUR:
#ifndef  __SYNTHESIS__
			if(val > 23)
			fprintf(stderr, "TIME: bad hour: %d", (int)val);
#endif
			multiplier=60*60;
			break;
		case STATE_DAY:
#ifndef  __SYNTHESIS__
			if(val > 31 || val < 1)
			fprintf(stderr, "TIME: bad day: %d", (int)val);
#endif
			multiplier=60*60*24;
			val = val - 1;
			break;
		case STATE_MON:
#ifndef  __SYNTHESIS__
			if(val > 12 || val < 1)
			fprintf(stderr, "TIME: bad month: %d", (int)val);
#endif
			multiplier=60*60*24;
			mon_saved=val;
			val = calendar2[val];
			break;
		case STATE_YEAR0:
//			year_saved=val;
#ifndef  __SYNTHESIS__
			if(val > 99)
			fprintf(stderr, "TIME: bad year: %d", (int)val);
#endif
			multiplier=365*60*60*24;
			break;
		//variant1
#if 0
		case STATE_YEAR1:
			multiplier=60*60*24;
//			//add leap day for this year
			if(year_saved%4==0 && mon_saved > 2)
				val=1;
			else
				val=0;
			break;
		case STATE_YEAR2:
			//add leap days for all periods
			val = year_saved/4;
			break;
#else
		case STATE_YEAR1:
			multiplier=60*60*24;
//			//add leap day for this year
			if(mon_saved <= 2 && val.range(1,0)==0) {
				val=(val>>2); // add leap year's days
			} else {
				val=(val>>2)+1; // add leap year's days + this year's leap day.
			}
			break;
#endif
		case STATE_SEND0:
			multiplier=0;
			stream_out.write(timestamp.range(7,0));
			break;
		case STATE_SEND1:
			stream_out.write(timestamp.range(15,8));
			break;
		case STATE_SEND2:
			stream_out.write(timestamp.range(23,16));
			break;
		case STATE_SEND3:
			stream_out.write(timestamp.range(31,24));
			state = STATE_INIT;
			break;
		}

		timestamp += multiplier*val;
		state++;
	} while(state!=STATE_USEC_LSB);
//	} while(1);

#ifndef  __SYNTHESIS__
//				fprintf(stderr, "TIME: %d:%d:%d\n", (int) time_out_reg.range(16,12), (int) time_out_reg.range(11,6), (int) time_out_reg.range(5,0));
#endif

}

