


#include <ap_int.h>
#include <ap_utils.h>
#include <hls_stream.h>

//#define PRBS_TABLE_IN_BRAM

#include "dab_bytework.h"


#ifndef PRBS_TABLE_IN_BRAM
const ap_uint<8> prbs_table[256] = {
	0x00, 0x08, 0x11, 0x19, 0x23, 0x2b, 0x32, 0x3a, 0x46, 0x4e, 0x57, 0x5f, 0x65, 0x6d, 0x74, 0x7c,
	0x8c, 0x84, 0x9d, 0x95, 0xaf, 0xa7, 0xbe, 0xb6, 0xca, 0xc2, 0xdb, 0xd3, 0xe9, 0xe1, 0xf8, 0xf0,
	0x10, 0x18, 0x01, 0x09, 0x33, 0x3b, 0x22, 0x2a, 0x56, 0x5e, 0x47, 0x4f, 0x75, 0x7d, 0x64, 0x6c,
	0x9c, 0x94, 0x8d, 0x85, 0xbf, 0xb7, 0xae, 0xa6, 0xda, 0xd2, 0xcb, 0xc3, 0xf9, 0xf1, 0xe8, 0xe0,
	0x21, 0x29, 0x30, 0x38, 0x02, 0x0a, 0x13, 0x1b, 0x67, 0x6f, 0x76, 0x7e, 0x44, 0x4c, 0x55, 0x5d,
	0xad, 0xa5, 0xbc, 0xb4, 0x8e, 0x86, 0x9f, 0x97, 0xeb, 0xe3, 0xfa, 0xf2, 0xc8, 0xc0, 0xd9, 0xd1,
	0x31, 0x39, 0x20, 0x28, 0x12, 0x1a, 0x03, 0x0b, 0x77, 0x7f, 0x66, 0x6e, 0x54, 0x5c, 0x45, 0x4d,
	0xbd, 0xb5, 0xac, 0xa4, 0x9e, 0x96, 0x8f, 0x87, 0xfb, 0xf3, 0xea, 0xe2, 0xd8, 0xd0, 0xc9, 0xc1,
	0x42, 0x4a, 0x53, 0x5b, 0x61, 0x69, 0x70, 0x78, 0x04, 0x0c, 0x15, 0x1d, 0x27, 0x2f, 0x36, 0x3e,
	0xce, 0xc6, 0xdf, 0xd7, 0xed, 0xe5, 0xfc, 0xf4, 0x88, 0x80, 0x99, 0x91, 0xab, 0xa3, 0xba, 0xb2,
	0x52, 0x5a, 0x43, 0x4b, 0x71, 0x79, 0x60, 0x68, 0x14, 0x1c, 0x05, 0x0d, 0x37, 0x3f, 0x26, 0x2e,
	0xde, 0xd6, 0xcf, 0xc7, 0xfd, 0xf5, 0xec, 0xe4, 0x98, 0x90, 0x89, 0x81, 0xbb, 0xb3, 0xaa, 0xa2,
	0x63, 0x6b, 0x72, 0x7a, 0x40, 0x48, 0x51, 0x59, 0x25, 0x2d, 0x34, 0x3c, 0x06, 0x0e, 0x17, 0x1f,
	0xef, 0xe7, 0xfe, 0xf6, 0xcc, 0xc4, 0xdd, 0xd5, 0xa9, 0xa1, 0xb8, 0xb0, 0x8a, 0x82, 0x9b, 0x93,
	0x73, 0x7b, 0x62, 0x6a, 0x50, 0x58, 0x41, 0x49, 0x35, 0x3d, 0x24, 0x2c, 0x16, 0x1e, 0x07, 0x0f,
	0xff, 0xf7, 0xee, 0xe6, 0xdc, 0xd4, 0xcd, 0xc5, 0xb9, 0xb1, 0xa8, 0xa0, 0x9a, 0x92, 0x8b, 0x83
};
#endif


#if 0

ap_uint<32> update_prbs(ap_uint<32> d_accum)
{
	ap_uint<8> acc_lsb = prbs_table[(d_accum) & 0xff];
	if(d_accum & 0x100)
		acc_lsb ^= 0x84;//132;
    return (d_accum << 8) ^ (ap_uint<32> acc_lsb);
}
#endif

#ifdef PRBS_TABLE_IN_BRAM
void prbs_stream(hls::stream<u8stream > &input, hls::stream<u8stream > &output, bool gen_cif_prbs, const ap_uint<8> prbs_table[256])
#else

#ifndef PRBS_TABLE_IN_BRAM
ap_uint<8> get_prbs(ap_uint<8> data_idx)
{
#pragma HLS ARRAY_PARTITION variable=prbs_table complete dim=1
	return prbs_table[data_idx];
}
#endif

void prbs_stream(hls::stream<u8stream > &input, hls::stream<u8stream > &output, bool gen_cif_prbs)
#endif
{
#pragma HLS inline

#ifndef PRBS_TABLE_IN_BRAM
//#pragma HLS ARRAY_PARTITION variable=prbs_table complete dim=1
#endif

    u8stream val;
    ap_uint<16> d_accum = 0x1ff;
    //ap_uint<8> acc_lsb;
    // While there is enought input and ouput items
    //y.last=0;
    do {
        val = input.read();
//        if(in)

        ap_uint<8> acc_lsb = get_prbs((d_accum) & 0xff);
        //if(d_accum & 0x100) acc_lsb ^= 0x84;//132;
        if(d_accum.bit(8)) acc_lsb ^= 0x84;//132;
        d_accum <<= 8;
        d_accum ^= acc_lsb;

        val.data = (ap_uint<8>)(d_accum & 0xff) ^ val.data;
        output.write(val);
    } while(!val.last);

    if(gen_cif_prbs) {
    	u8stream y;
    	y.last=0;
    	y.data = 0xFA;
    	output.write(y);

    	/*
    	 *
#=== Resource usage ===
SLICE:           93
LUT:            246
FF:              50
DSP:              0
BRAM:             0
SRL:              0
       	val.data = 0x00;
   		output.write(val);
   		output.write(val);
   		output.write(val);
   		output.write(val);
*/

/*
#=== Resource usage ===
SLICE:           66
LUT:            210
FF:              51
DSP:              0
BRAM:             0
SRL:              0*/
    	ap_uint<3> i = 0;
    	y.data = 0x00;
    	do {
    		output.write(y);
    		i++;
    	} while(i<4);

/*
#=== Resource usage ===
SLICE:           75
LUT:            220
FF:              52
DSP:              0
BRAM:             0
SRL:              0
    	for(ap_uint<3> i = 0;i<4;i++) {
    		val.data = 0x00;
    		output.write(val);
    	}
*/
    	d_accum = 0x1ff;
    	for(ap_uint<13> i=0;i<6912;i++) {
    		ap_uint<8> acc_lsb = get_prbs((d_accum) & 0xff);
    		//if(d_accum & 0x100) acc_lsb ^= 0x84;//132;
    		if(d_accum.bit(8)) acc_lsb ^= 0x84;//132;
    		d_accum <<= 8;
    		d_accum ^= acc_lsb;

    		y.data = (ap_uint<8>)(d_accum & 0xff);
    		y.last = (i==6911) ? 1 : 0;
    		output.write(y);
    	}

    }

}

/*
#=== Resource usage ===
SLICE:           29
LUT:             85
FF:              23
DSP:              0
BRAM:             0
SRL:              0

With CIF PRBS generator:
#=== Resource usage ===
SLICE:           65
LUT:            210
FF:              51
DSP:              0
BRAM:             0
SRL:              0
 * */
#if 0
void prbs_dbg(hls::stream<u8stream > &input, hls::stream<u8stream > &output, ap_uint<2> *debug)
{
#pragma HLS INTERFACE ap_none port=debug
#pragma HLS INTERFACE ap_fifo port=input
#pragma HLS INTERFACE ap_fifo port=output
#pragma HLS RESOURCE variable=input  core=AXIS metadata="-bus_bundle S_AXIS"
#pragma HLS RESOURCE variable=output core=AXIS metadata="-bus_bundle M_AXIS"
#pragma HLS INTERFACE ap_ctrl_none port=return

	u8stream val = input.read();
	ap_uint<8> block_type = val.data;
	bool gen_cif_prbs=false;
	/* send block type */
#if 1
	//0 0 91 149
  switch(block_type) {
	case 0xF1:
		gen_cif_prbs=true;
	case 0xC1: {
	    u8stream y;
	    y.last=0;
	    y.data = block_type;
	    output.write(y);

        /* send STC/FC */
    	for(ap_uint<3> i = 0; i<4; i++) {
    		val = input.read();
#ifndef  __SYNTHESIS__
	fprintf(stderr, "[HARD] sending STC/FC: %02x\n", (uint8_t)val.data);
#endif
    		y.data=val.data;
    		output.write(y);
    	}

		prbs_stream(input, output, gen_cif_prbs);
		*debug=0;
		break;
	}
	/* temp hack to passthru unpunctured data */
	default:
//	case 0xF2:
//	case 0xC2:
	{
	    u8stream y;
	    y.last=0;
	    y.data = block_type;
	    output.write(y);

	    do {
#pragma HLS loop_tripcount min=289 max=6913 avg=6913
			val = input.read();
			y.data = val.data;
			y.last = val.last;
			output.write(y);
		} while (!val.last);
	    *debug=1;
		break;
	}
  }
#else
  //0 0 99 167
  bool do_prbs = false;
  ap_uint<3> counter = 4;
  switch(block_type) {
	case 0xF1:
	case 0xC1:
		do_prbs=true;
	default:
//	case 0xF2:
//	case 0xC2:
	{
		do {
#pragma HLS loop_tripcount min=4 max=6913 avg=6913
			val = input.read();
			y.data = val.data;
			y.last = val.last;
			output.write(y);
			counter--;
		} while (!val.last && (!do_prbs || (do_prbs && counter > 0)));
		if(do_prbs)
			prbs_stream(input, output);
		break;
	}
  }
#endif
}
#endif



#if 0


#ifdef PRBS_TABLE_IN_BRAM
void prbs(hls::stream<u8stream > &input, hls::stream<u8stream > &output, const ap_uint<8> prbs_table[256])
#else
void prbs(hls::stream<u8stream > &input, hls::stream<u8stream > &output)
#endif
{
#ifdef PRBS_TABLE_IN_BRAM
#pragma HLS INTERFACE ap_memory port=prbs_table
#pragma HLS RESOURCE variable=prbs_table core=ROM_1P_BRAM
#endif
#pragma HLS INTERFACE ap_fifo port=input
#pragma HLS INTERFACE ap_fifo port=output
#pragma HLS RESOURCE variable=input  core=AXIS metadata="-bus_bundle S_AXIS"
#pragma HLS RESOURCE variable=output core=AXIS metadata="-bus_bundle M_AXIS"
#pragma HLS INTERFACE ap_ctrl_none port=return

	u8stream val = input.read();
	ap_uint<8> block_type = val.data;
	bool gen_cif_prbs=false;
	/* send block type */

	//0 0 91 149
  switch(block_type) {
	case 0xF1:
		gen_cif_prbs=true;
	case 0xC1: {
	    u8stream y;
	    y.last=0;
	    y.data = block_type;
	    output.write(y);

        /* send STC/FC */
    	for(ap_uint<3> i = 0; i<4; i++) {
    		val = input.read();
#ifndef  __SYNTHESIS__
	fprintf(stderr, "[HARD] sending STC/FC: %02x\n", (uint8_t)val.data);
#endif
    		y.data=val.data;
    		output.write(y);
    	}
#ifdef PRBS_TABLE_IN_BRAM
		prbs_stream(input, output, gen_cif_prbs, prbs_table);
#else
		prbs_stream(input, output, gen_cif_prbs);
#endif
		break;
	}
	/* temp hack to passthru unpunctured data */
	default:
//	case 0xF2:
//	case 0xC2:
	{
	    u8stream y;
	    y.last=0;
	    y.data = block_type;
	    output.write(y);

	    do {
#pragma HLS loop_tripcount min=289 max=6913 avg=6913
			val = input.read();
			y.data = val.data;
			y.last = val.last;
			output.write(y);
		} while (!val.last);
		break;
	}
  }
}

#endif




void prbs(hls::stream<u8stream > &input, hls::stream<u8stream > &output)
{
#pragma HLS INTERFACE ap_fifo port=input
#pragma HLS INTERFACE ap_fifo port=output
//#pragma HLS RESOURCE variable=input  core=AXIS metadata="-bus_bundle S_AXIS"
//#pragma HLS RESOURCE variable=output core=AXIS metadata="-bus_bundle M_AXIS"
#pragma HLS INTERFACE ap_ctrl_none port=return

	u8stream val;
	bool gen_cif_prbs=false;
	/* send block type */

    /* header & send STC/FC */
    for(ap_uint<3> i = 0; i<5; i++) {
    	val = input.read();
    	if(i==0 && val.data == 0xF1) gen_cif_prbs=true;
    	output.write(val);
   	}
	prbs_stream(input, output, gen_cif_prbs);
}

