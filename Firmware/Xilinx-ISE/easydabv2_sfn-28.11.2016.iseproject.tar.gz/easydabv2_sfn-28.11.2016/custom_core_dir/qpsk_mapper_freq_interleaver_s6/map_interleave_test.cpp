
#include <ap_int.h>
#include <hls_stream.h>
#include <byteswap.h>

enum {
	UI1_MINUS07071=0,
	UI1_PLUS07071
};



typedef struct {
	ap_uint<1> real;
	ap_uint<1> imag;
} cuint1;

typedef struct {
	cuint1 data;
	ap_uint<1> dest;
	ap_uint<1> last;
} cplxui1stream;

typedef struct {
	ap_uint<8> data;
	ap_uint<1> dest;
	ap_uint<1> last;
} binaryStream8;

#ifdef MONITOR_FILLNESS
void map_interleave(hls::stream<binaryStream> &input, hls::stream<cplxui1stream> &output, volatile ap_uint<32> *b_fillness);
#else

typedef struct {
	ap_uint<2> data;
	ap_uint<1> dest;
	ap_uint<1> last;
} cplxui1stream2;

void map_interleave(hls::stream<binaryStream8> &input, hls::stream<cplxui1stream2> &output);
#endif


#define DEBUG1





int read_data(hls::stream<cplxui1stream2> &data_out, int o_idx, FILE *in_golden, FILE *out_fp, int check_in)
//int read_data(cplxui1stream *data_out, int o_idx, FILE *in_golden, FILE *out_fp, int check_in)
{
	int i=0;
	int not_ok=0;

	//int read_size = 1536;//data_out.size();
	int read_size = data_out.size();
	fprintf(stderr, "read[%d]=%d\n", o_idx, read_size);
	if(read_size == 0) {
		fprintf(stderr, "read[%d]=%d, error?\n", o_idx, read_size);
		return 0;
	}

	int to_read = read_size;
	if(read_size != 1536) {
		fprintf(stderr, "read[%d]=%d, error?\n", o_idx, read_size);
	}

	do {
		cplxui1stream2 var;
		var=data_out.read();
		//var=data_out[i];
		if(var.dest!=0) {
			fprintf(stderr, "not this destination\n");
			read_size--;
			continue;
		}

		ap_uint<1> real = var.data.bit(0);
		ap_uint<1> imag = var.data.bit(1);

		fprintf(out_fp, "%d %d %d %d\n", o_idx, i, (int)real, (int)imag);

		/*********************************************************************
		 * Check with file contents
		 *********************************************************************/
		int idx0=0;
		int idx1=0;
		int in_re=0;
		int in_im=0;
		if(fscanf(in_golden,"%d %d %d %d",&idx0,&idx1,&in_re,&in_im) !=4){
			fprintf(stderr, "output scan failed on: %d %d\n", o_idx, i);
			return 1;
		}

		if(idx0!=o_idx || idx1 != i) {
			fprintf(stderr, "output order failure: %d %d != %d %d\n", o_idx, i, idx0, idx1);
			return 1;
		}


		if((int)real != in_re || (int)imag != in_im) {
			fprintf(stderr, "out[%d][%d]: res:{%d,%d} != gold:{%d,%d}\n", o_idx, i, (int)real, (int)imag, in_re, in_im);
			not_ok++;
		}

		if(not_ok > 20)
			return (not_ok);
		i++;
	} while (i < read_size);
	return not_ok;
}




int main()
{

	int not_ok = 0;
	/**************************************************************************************
	 * HW Implementation
	 **************************************************************************************/
    hls::stream<binaryStream8> data_in;
#ifdef MONITOR_FILLNESS
    hls::stream<cplxui1stream> data_out;
#else
    hls::stream<cplxui1stream2> data_out;
#endif
	//binaryStream data_in[384];
	//cplxui1stream data_out[1536];

    FILE *in_fp = fopen("input_qpsk.dat", "rb");
    FILE *in_golden = fopen("input_diffmod.dat", "rb");
    FILE *out_fp = fopen("output.dat", "wb");

    if(!in_fp){
    	fprintf(stderr, "can't open input golden file\n");
    	return 1;
    }
    if(!in_golden) {
    	fprintf(stderr, "can't open input file\n");
    	return 1;
    }
    if(!out_fp) {
    	fprintf(stderr, "can't open output file\n");
    	return 1;
    }

    int i_idx = 0;
    for(int o_idx = 0; o_idx < 75; o_idx++) {

#if 1
    	if(i_idx==0) {
    		binaryStream8 var;
			var.dest = 1; //start
			var.last = 1;
			var.data = 0xFF; //pass to next block
			data_in.write(var);
			ap_uint<32> b_fillness=4096-2656-10;
#ifdef MONITOR_FILLNESS
			map_interleave(data_in, data_out, &b_fillness);
#else
			map_interleave(data_in, data_out);
#endif

#ifdef DEBUG1
		fprintf(stderr, "out[%d] size=%d 1\n", o_idx, data_out.size());
#endif
			not_ok += read_data(data_out, o_idx, in_golden, out_fp, 0);

			var.data = 0; //send phase references
			data_in.write(var);
			b_fillness=4096-2552-10;

#ifdef MONITOR_FILLNESS
			map_interleave(data_in, data_out, &b_fillness);
#else
			map_interleave(data_in, data_out);
#endif

#ifdef DEBUG1
		fprintf(stderr, "out[%d] size=%d 2\n", o_idx, data_out.size());
#endif
			not_ok += read_data(data_out, o_idx, in_golden, out_fp, 0);
    	}
#endif


		// Fill HW buffers
		for (int i=0; i < 384; i++) {
			binaryStream8 var;
			var.dest = 0; //start
			var.last = (i==(384-1)) ? 1 : 0;
			uint8_t data = 0;

				int in=0;
				int idx0=0;
				int idx1=0;
				if(fscanf(in_fp,"%d %d %02X",&idx0,&idx1,&in) !=3){
					fprintf(stderr, "input scan failed on: %d %d\n", i_idx, i);
					return 1;
				}

				if(idx0!=i_idx || idx1 != i) {
					fprintf(stderr, "input order failure: %d %d != %d %d\n", i_idx, i, idx0, idx1);
					return 1;
				}
				data = in;

#ifdef DATA_IS_LITTLE_ENDIAN
			var.data = data;
#else
			var.data = data;
#endif
			data_in.write(var);
		}
    	i_idx++;

		// Now run hardware
    	ap_uint<32> b_fillness=4096-2656-10;
#ifdef MONITOR_FILLNESS
    	map_interleave(data_in, data_out, &b_fillness);
#else
    	map_interleave(data_in, data_out);
#endif
#ifdef DEBUG1
		fprintf(stderr, "out[%d] size=%d (before read)\n", o_idx, data_out.size());
#endif
		//check hw/sw results:
		//read once more if it's first sending
		not_ok += read_data(data_out, o_idx, in_golden, out_fp, 1);
		if(not_ok)
			break;
    }

    fclose(in_fp);
    fclose(in_golden);
    fclose(out_fp);


    // Compare the results file with the golden results
    int retval = system("diff --brief -w output.dat input_diffmod.dat");
    if (retval != 0) {
    	printf("Test failed  !!!\n");
    	not_ok++;
    } else {
    	printf("Test passed !\n");
    }


	return not_ok;
}
