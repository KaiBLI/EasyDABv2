

#include <ap_int.h>
#include <ap_utils.h>
#include <hls_stream.h>


#include <iostream>       // std::cout
#include <pthread.h>
#include <time.h>


static bool pps_in = false;
static bool time_is_setted = false;
static bool not_exit = true;
static bool set_time = false;
static hls::stream<ap_uint<8> > data_in;
static ap_uint<33> time_out = 0;

void date2time(hls::stream<ap_uint<8> > &stream_in, hls::stream<ap_uint<8> > &stream_out);



char Ary[]  = "\n";

int main()
{
	int ret=0;

	/**************************************************************************************
	 * HW Implementation
	 **************************************************************************************/
	hls::stream<ap_uint<8> > s_in;
	hls::stream<ap_uint<8> > s_out;
    int loops=0;

    srand(time(NULL));

    while(loops < 16386) {
    	//time_t utm = time(NULL);
    	time_t utm = 946684800 + (((uint32_t)rand()) % 0x3FFFFFFF);
//    	fprintf(stderr, "curtime: %lu\n", utm);

    	struct tm *gmt = gmtime(&utm);

    	s_in.write(utm & 0x0FF);
    	s_in.write((utm >> 8) & 0x0FF);
    	s_in.write(gmt->tm_sec);
    	s_in.write(gmt->tm_min);
    	s_in.write(gmt->tm_hour);
    	s_in.write(gmt->tm_mday);
    	s_in.write(gmt->tm_mon+1);
    	s_in.write(gmt->tm_year-100);

    	date2time(s_in, s_out);


    	ap_uint<8> usec_hi = s_out.read();
    	ap_uint<8> usec_lo = s_out.read();

    	ap_uint<8> gps_ts0 = s_out.read();
    	ap_uint<8> gps_ts1 = s_out.read();
    	ap_uint<8> gps_ts2 = s_out.read();
    	ap_uint<8> gps_ts3 = s_out.read();
    	ap_uint<32>  gps_ts = (gps_ts3, gps_ts2, gps_ts1, gps_ts0);
//    	fprintf(stderr, "gps_ts:  %lu\n", (unsigned long) gps_ts + 315964800);

    	if(gps_ts + 315964800 != utm) {
    	  fprintf(stderr, "BAD TIME: %02d.%02d.%02d_%02d:%02d:%02d\n",
    			  gmt->tm_year-100,
    			  gmt->tm_mon+1,
    			  gmt->tm_mday,
    			  gmt->tm_hour,
    			  gmt->tm_min,
    			  gmt->tm_sec);
    	fprintf(stderr, "TIME != GPS: %lu != %lu, diff=%d\n", utm, (unsigned long) gps_ts + 315964800, utm - ((unsigned long) gps_ts + 315964800));
    	  return 1;
    	} else {
      	  fprintf(stderr, "GOOD TIME: %02d.%02d.%02d_%02d:%02d:%02d\n",
      			  gmt->tm_year-100,
      			  gmt->tm_mon+1,
      			  gmt->tm_mday,
      			  gmt->tm_hour,
      			  gmt->tm_min,
      			  gmt->tm_sec);
    	}

//    	nmea2num(data_in, &pps_in, &time_out);
//    	if(data_in.empty())
//    		break;
    	loops++;
//    	usleep(1000000);
    }


	return ret;
}

