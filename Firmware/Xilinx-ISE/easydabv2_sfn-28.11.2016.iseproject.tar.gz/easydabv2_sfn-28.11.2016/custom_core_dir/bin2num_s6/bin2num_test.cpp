

#include <ap_int.h>
#include <ap_utils.h>
#include <hls_stream.h>


#include <iostream>       // std::cout
#include <pthread.h>





void bin2num(hls::stream<ap_uint<8> > &uart_in, /*volatile bool *pps_in,*/	volatile ap_uint<32> *time_out, volatile bool *time_out_vld,
		volatile bool *nmea_disable, volatile bool *osc_is_ok);



char Ary[]  = "$GPRMC,173711.000,A,5024.9593,N,03037.2008,E,0.22,116.40,260716,,,A*62\r\n"
			  "$GPRMC,173712.000,A,5024.9592,N,03037.2008,E,0.60,110.97,260716,,,A*6A\n"
		  	  "$GPAMC,173713.000,A,5024.9591,N,03037.2010,E,0.57,110.97,260716,,,A*65\n"
		      "$GPRMC,144331.080,V,,,,,0.13,36.12,290716,,,N*7A\n"
			  "$GPRMC,144332.080,V,,,,,0.27,36.12,290716,,,N*7E\r\n"
		  	  "$GPRMC,173714.000,B,5024.9591,N,03037.2007,E,0.49,110.97,260716,,,A*6B\r\n"
			  "$GPBMC,173715.000,A,5024.9589,N,03037.2011,E,0.29,110.97,260716,,,A*62\r\n"
	  	  	  "$GPRMC,173716.000,A,5024.9590,N,03037.2004,E,0.44,110.97,260716,,,A*66\n"
		      "$GNRMC,091816.00,A,5024.97497,N,03037.17594,E,0.032,,130916,,,A*6A"
		      "$GNRMC,191715.00,A,5024.97497,N,03037.17594,E,0.032,,,,,A*6A"
	  	  	  "$GPCCC,260716,,,A*63\n";

int main()
{
	int ret=0;

	/**************************************************************************************
	 * HW Implementation
	 **************************************************************************************/
	bool time_is_setted = false;
	bool nmea_disable = false;
	bool osc_is_ok = false;
	hls::stream<ap_uint<8> > data_in;
	ap_uint<32> time_out = 0;



//    while(1) {

    	int num;
    	for(num=0;num<strlen(Ary);num++) {
    		data_in.write(Ary[num]);
    	}

    	bin2num(data_in, &time_out, &time_is_setted, &nmea_disable, &osc_is_ok);
//    }

	return ret;
}

