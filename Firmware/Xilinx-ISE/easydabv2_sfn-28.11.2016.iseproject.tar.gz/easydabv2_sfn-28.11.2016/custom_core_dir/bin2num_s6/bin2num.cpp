#include <ap_int.h>
#include <ap_utils.h>
#include <hls_stream.h>

#define SYNC_VER2 1

enum {
	STATE_SYNC0=0,
	STATE_SYNC1,
	STATE_SYNC2,
	STATE_TIME0 = 27,
	STATE_TIME1,
	STATE_TIME2,
	STATE_TIME3,
	STATE_TIME_LEAP = 32,
	STATE_F0,
	STATE_F1,
	STATE_F2,
	STATE_F3,
	STATE_END = 43,
	STATE_SYNC_INIT = 63
};


/*
 *
C5 00 80 00 00 00 00 28 1C 52 00 00 20 60 C1 91 00 00 00 00 00 00 00 00 00 00 00 44 DB 1D 7A 00 11 62 04 85 40 00 00 00 00 31 7B CA
C5 00 80 00 00 00 00 28 1C 52 00 00 20 60 C1 91 00 00 00 00 00 00 00 00 00 00 00 44 DB 1D 7C 00 11 62 04 85 40 00 00 00 00 3A 1C CA


 * */

/*
#=== Resource usage ===
SLICE:           36
LUT:            120
FF:              73
DSP:              0
BRAM:             0
SRL:              0
 *
 * */
void bin2num(hls::stream<ap_uint<8> > &uart_in, /*volatile bool *pps_in,*/	volatile ap_uint<32> *time_out, volatile bool *time_out_vld,
		volatile bool *osc_is_ok)
{
//#pragma HLS ARRAY_PARTITION variable=GPRMC_SING complete dim=1
//#pragma HLS ARRAY_PARTITION variable=calendar complete dim=1

#pragma HLS INTERFACE ap_fifo port=uart_in
//#pragma HLS INTERFACE ap_none port=time_is_setted
//#pragma HLS INTERFACE ap_none port=set_time
//#pragma HLS INTERFACE ap_hs port=time_out
#pragma HLS INTERFACE ap_none port=time_out
#pragma HLS INTERFACE ap_none port=time_out_vld
//#pragma HLS INTERFACE ap_none port=pps_in

#pragma HLS INTERFACE ap_none port=osc_is_ok

//#pragma HLS INTERFACE ap_none port=tist
#pragma HLS RESOURCE variable=uart_in  core=AXIS metadata="-bus_bundle S_AXIS"

#pragma HLS INTERFACE ap_ctrl_none port=return

	ap_uint<8> val;
	ap_uint<6> state_pos = STATE_SYNC0;
	ap_uint<32> time_out_reg = 0;
	ap_uint<32> multiplier = 0;
	ap_uint<4> mon_saved;
	//ap_uint<12> seconds_readed=0;
//	ap_uint<4> seconds_readed=0;
	ap_uint<3> read_pos;
	ap_uint<9> val_save;
	*time_out_vld = false;
	*osc_is_ok = false;
	bool state_val;
	bool state_val2;


	while(1) {
#ifndef  __SYNTHESIS__
		if(uart_in.empty())
			break;
#endif
		val = uart_in.read();
		switch(state_pos) {
		case STATE_SYNC0:
			if(val != 0xC5) state_pos = STATE_SYNC_INIT;
			break;
		case STATE_SYNC1:
			if(val != 0x00) state_pos = STATE_SYNC_INIT;
			break;
		case STATE_SYNC2:
			time_out_reg=0;
			state_val=true;
			state_val2=true;
			if(val != 0x80) state_pos = STATE_SYNC_INIT;
			break;
		case STATE_TIME0:
		case STATE_TIME1:
		case STATE_TIME2:
		case STATE_TIME3:
			time_out_reg=(time_out_reg << 8) | val;
			break;
		case STATE_TIME_LEAP:
			if(val == 0) {
				state_val=false;
				//state_val2 = false;
			}
			time_out_reg = time_out_reg - val;
			break;
#if 0
		case STATE_F0:
			//bit6 - always 1
			//bit5 - GPS locked
			//bit1 - got leap secon
			//bit0 - no initial lock to satellites
			if(!val.get_bit(5) || !val.get_bit(1) || val.get_bit(0))
				state_val=false;
			break;
		case STATE_F1:
			//bit3 - setted to 1 on trimble when initialized and no sats seen.
			//bit2 - have GPS time
			//bit1 - have too small input voltage
			if(val.get_bit(3) || !val.get_bit(2) || val.get_bit(1))
				state_val=false;
			break;
		case STATE_F2:
			//bit7 - 1 on symmetricom
			//bit3 - always 1
			//bit2 - no OCXO sync to GPS satellites
			//bit1 - no OCXO sync to GPS satellites
			//bit0 - always 1
			//THIS CAN BE DISABLED!
			if(!val.get_bit(2) || !val.get_bit(1))
				state_val=false;
			break;
		case STATE_F3:
			//bit7 - 1 on trimble
			//bit6 - 1 on symmetricom
			//bit5 - no antenna connected
			//bit4 - no GPS signal
			if(val.get_bit(5) || val.get_bit(4))
				state_val=false;
			break;
#else
		case STATE_F0:
			//bit6 - always 1
			//bit5 - GPS locked
			//bit1 - got leap secon
			//bit0 - no initial lock to satellites
			if(val.get_bit(0) == 1 || val.get_bit(5) == 0)
				state_val2 = false;
			break;
		case STATE_F1:
			//bit3 - setted to 1 on trimble when initialized and no sats seen.
			//bit2 - have GPS time
			//bit1 - have too small input voltage
			if(!val.get_bit(2))
				state_val=false;
			break;
		case STATE_F2:
			//bit7 - 1 on symmetricom
			//bit3 - no OCXO sync to GPS satellites
			//bit2 - always 1
			//bit1 - no OCXO sync to GPS satellites
			//bit0 - always 1
			//THIS CAN BE DISABLED!
			if(val.get_bit(3) || val.get_bit(1))
				state_val2=false;
			break;
		case STATE_F3:
			//bit7 - 1 on trimble
			//bit6 - 1 on symmetricom
			//bit5 - no antenna connected
			//bit4 - no GPS signal
			if(val.get_bit(4))
				state_val2=false;
			break;

#endif
		case STATE_END:
			if(val != 0xCA)
				state_val = false;
			*time_out = time_out_reg;
			*time_out_vld = state_val;
			*osc_is_ok = state_val2;
			state_pos = STATE_SYNC_INIT;
			break;
		default:
			break;
		}

		state_pos++;
	}
}

