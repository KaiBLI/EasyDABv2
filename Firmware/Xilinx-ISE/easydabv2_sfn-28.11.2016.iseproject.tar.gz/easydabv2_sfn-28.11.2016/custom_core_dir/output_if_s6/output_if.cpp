

#include <ap_int.h>
#include <ap_utils.h>
#include <hls_stream.h>

void axi_fifo_spi(
		//HLS stream
		hls::stream<ap_uint<20> > &input,
		//QDUC
		volatile ap_uint<18> *out,
		volatile bool *out_enable,
		volatile bool *out_clk
)
{

#pragma HLS INTERFACE ap_none port=out bundle=QDUC
#pragma HLS INTERFACE ap_none port=out_enable bundle=QDUC
#pragma HLS INTERFACE ap_none port=out_clk bundle=QDUC

#pragma HLS INTERFACE ap_fifo port=input
#pragma HLS RESOURCE variable=input  core=AXIS metadata="-bus_bundle S_AXIS"
#pragma HLS INTERFACE ap_ctrl_none port=return

	bool clk_saved = false;
	*out_enable = false;

	ap_uint<21> samples_count = 0; // full dab cycles

	while(1) {
		if(clk_saved != ((bool)*out_clk)) {

			if(clk_saved==false) {

				if(samples_count < (757625)*2) {
					if(!input.empty()) {
						*out = input.read();
						*out_enable = true;
					} else {
						*out_enable = false;
					}
				} else {
					*out_enable = false;
				}

				samples_count++;
				if(samples_count == 768000) samples_count=0;
			}

			clk_saved = *out_clk;
		}

		ap_wait();
	}


}
