

#include <ap_int.h>
#include <ap_utils.h>
#include <hls_stream.h>


#if 0

void spi_send_rwptr(const ap_uint<2> cmd, const ap_uint<8> rw_ptr, volatile bool *tx_start, volatile bool *tx_done, volatile ap_uint<2> *spi_ce_n, volatile ap_uint<8> *spi_do)
{
#pragma HLS INLINE

	ap_wait();
//	*spi_ce_n = rw_ptr.get_bit(7) ? 0b01 : 0b10;
	*spi_ce_n = (ap_uint<2>)(((ap_uint<2>)rw_ptr.range(7,7)) + 1);
//	*spi_ce_n = 2-(ap_uint<2>)rw_ptr.range(7,7);
//	if(rw_ptr.get_bit(7))
//		*spi_ce_n = 0b01;
//	else
//		*spi_ce_n = 0b10;
	ap_wait_n(5);

//	ap_wait_until(((bool)*tx_done) == true);
	*spi_do = cmd;
	*tx_start=true;
	ap_wait_until(((bool)*tx_done) == false);
//	ap_wait();
	*tx_start=false;
	ap_wait_until(((bool)*tx_done) == true);

	//2^7 * 1024
	//2^7 << 10
	// 7bit << 2 | 00
	// 7bit << 2 | 00

	*spi_do = rw_ptr.range(6,6);
	*tx_start=true;
	ap_wait_until(((bool)*tx_done) == false);
//	ap_wait();
	*tx_start=false;
	ap_wait_until(((bool)*tx_done) == true);

	*spi_do = ((ap_uint<8>)rw_ptr.range(5,0)) << 2;
	*tx_start=true;
	ap_wait_until(((bool)*tx_done) == false);
//	ap_wait();
	*tx_start=false;
	ap_wait_until(((bool)*tx_done) == true);

	*spi_do = 0x00;
	*tx_start=true;
	ap_wait_until(((bool)*tx_done) == false);
//	ap_wait();
	*tx_start=false;
	ap_wait_until(((bool)*tx_done) == true);
	ap_wait();

}


void axi_fifo_spi(
		//HLS stream
		hls::stream<ap_uint<8> > &input,
		volatile bool *inbuff_empty,
		hls::stream<ap_uint<8> > &output,
		volatile bool *outbuff_full,
		//QSPI
		volatile ap_uint<2> *spi_ce_n,
		volatile ap_uint<8> *spi_di,
		volatile ap_uint<8> *spi_do,
		volatile bool *tx_start,
		volatile bool *tx_done,
		volatile bool *disable_spi,
		volatile bool *disable_sfn,
		volatile ap_uint<8> *fillness
		)
{

#pragma HLS DATA_PACK variable=output
#pragma HLS DATA_PACK variable=input

#pragma HLS INTERFACE ap_none port=tx_done bundle=QSPI
#pragma HLS INTERFACE ap_none port=tx_start bundle=QSPI
#pragma HLS INTERFACE ap_none port=spi_ce_n bundle=QSPI
#pragma HLS INTERFACE ap_none port=spi_di bundle=QSPI
#pragma HLS INTERFACE ap_none port=spi_do bundle=QSPI

#pragma HLS INTERFACE ap_none port=disable_spi
#pragma HLS INTERFACE ap_none port=disable_sfn

#pragma HLS INTERFACE ap_none port=fillness bundle=FIFO

#pragma HLS INTERFACE ap_none port=inbuff_empty
#pragma HLS INTERFACE ap_none port=outbuff_full
//#pragma HLS INTERFACE ap_fifo depth=32 port=input
//#pragma HLS INTERFACE ap_fifo depth=32 port=output
//#pragma HLS INTERFACE axis port=input
//#pragma HLS INTERFACE axis port=output
#pragma HLS INTERFACE ap_fifo port=input
#pragma HLS INTERFACE ap_fifo port=output
#pragma HLS RESOURCE variable=input  core=AXIS metadata="-bus_bundle S_AXIS"
#pragma HLS RESOURCE variable=output core=AXIS metadata="-bus_bundle M_AXIS"
#pragma HLS INTERFACE ap_ctrl_none port=return

//#pragma HLS reset variable=reset_done

	//ap_uint<8> o_val;
	//static bool reset_done;
	bool is_init=true;
	ap_uint<8> r_ptr = 0; // x1024x2
	ap_uint<8> w_ptr = 0; // x1024x2
	ap_uint<9> fifo_counter = 0;

	*spi_ce_n=0b11;
	*tx_start=false;
	*fillness=fifo_counter;
	ap_wait();
	ap_wait_until(((bool)*tx_done) == true);
	//go to QSPI mode:

#if 0
	while(1) {
		if (fifo_counter < 256 && ((bool) *inbuff_empty) == false) {
			spi_send_rwptr(2, w_ptr, tx_start, tx_done, spi_ce_n, spi_do);

			w_ptr++;
			fifo_counter++;

			ap_uint<11> cnt=0;

			LOOP1:do {
#pragma HLS loop_tripcount min=1024 max=1024 avg=1024
				*spi_do = input.read();
				*tx_start=true;
				ap_wait_until(((bool)*tx_done) == false);
				*tx_start=false;
				ap_wait_until(((bool)*tx_done) == true);
				cnt++;
			} while(cnt < 1024);


			if(cnt==1024) {
				ap_wait_n(5);
				*spi_ce_n=0b11;
				ap_wait();
			}

			if(is_init && fifo_counter == 256) is_init=false;
//			ap_wait();
		} else if (fifo_counter > 0 && !is_init) {
			if(((bool) *outbuff_full) == false) {
				spi_send_rwptr(3, r_ptr, tx_start, tx_done, spi_ce_n, spi_do);

				r_ptr++;
				fifo_counter--;


				ap_uint<11> cnt=0;
				LOOP2:do {
#pragma HLS loop_tripcount min=1024 max=1024 avg=1024
					//ap_wait();
					*tx_start=true;
					ap_wait_until(((bool)*tx_done) == false);
					*tx_start=false;
					ap_wait_until(((bool)*tx_done) == true);

					output.write(((ap_uint<8>) *spi_di));
					cnt++;
				} while (cnt < 1024);

				if(cnt==1024) {
					ap_wait_n(5);
					*spi_ce_n=0b11;
					ap_wait();
				}
			}
		} else if(!is_init) {
			is_init=true; //re-buffer
		}
		ap_wait();
	  }
#else
	while(1) {
		if(((bool) *disable_spi)) {
			output.write(input.read());
		} else if (fifo_counter > 0 && !is_init && ((bool) *outbuff_full) == false) {
			spi_send_rwptr(3, r_ptr, tx_start, tx_done, spi_ce_n, spi_do);

			r_ptr++;
			fifo_counter--;


			ap_uint<11> cnt=0;
			LOOP2:do {
#pragma HLS loop_tripcount min=1024 max=1024 avg=1024
//				ap_wait();
				*tx_start=true;
				ap_wait_until(((bool)*tx_done) == false);
//				ap_wait();
				*tx_start=false;
				ap_wait_until(((bool)*tx_done) == true);

				output.write(((ap_uint<8>) *spi_di));
				cnt++;
				if(cnt==1024) {
					ap_wait_n(5);
					*spi_ce_n=0b11;
					ap_wait();
				}
			} while (cnt < 1024);

		} else if (fifo_counter < 256 && ((bool) *inbuff_empty) == false) {
			spi_send_rwptr(2, w_ptr, tx_start, tx_done, spi_ce_n, spi_do);

			w_ptr++;
			fifo_counter++;

			ap_uint<11> cnt=0;

			LOOP1:do {
#pragma HLS loop_tripcount min=1024 max=1024 avg=1024
//				ap_wait();
				*spi_do = input.read();
				*tx_start=true;
				ap_wait_until(((bool)*tx_done) == false);
//				ap_wait();
				*tx_start=false;
				ap_wait_until(((bool)*tx_done) == true);
				cnt++;
				if(cnt==1024) {
					ap_wait_n(5);
					*spi_ce_n=0b11;
					ap_wait();
				}
			} while(cnt < 1024);



			if(is_init && (fifo_counter == 192 || (((bool) *disable_sfn) == false &&  fifo_counter == 16))) is_init=false;
			//if(is_init && (((((bool) *disable_sfn) == false) && fifo_counter >= 8) || fifo_counter >= 192))
			//	is_init=false;
			ap_wait();
		} else if(!is_init && fifo_counter==0 && ((bool) *disable_sfn) == true) {
			is_init=true; //re-buffer
		}
		ap_wait();
		if((fifo_counter < 256))
			*fillness=fifo_counter;
		else
			*fillness=0xFF;
	  }
#endif

}
#else


enum {
	STATE_INIT = 0,
	STATE_START,
	STATE_SPI_START,
	STATE_SPI_CMD,
	STATE_SPI_CMD0,
	STATE_SPI_CMD_0,
	STATE_SPI_CMD_SENT,
	STATE_SPI_ADDR1,
	STATE_SPI_ADDR1_SENT,
	STATE_SPI_ADDR2,
	STATE_SPI_ADDR2_SENT,
	STATE_SPI_ADDR3,
	STATE_SPI_ADDR3_SENT,
	STATE_SPI_DATA,
	STATE_SPI_DATA_SENT,
	STATE_SPI_DATA_SENT1,
	STATE_SPI_DATA_END,
	STATE_SPI_DATA_END1,
#if 0
	STATE_SPI_ADDR1_0,
	STATE_SPI_ADDR2_0,
	STATE_SPI_ADDR3_0,
	STATE_SPI_DATA_0,
#endif
};

void axi_fifo_spi(
		//HLS stream
		hls::stream<ap_uint<8> > &input,
		volatile bool *inbuff_empty,
		hls::stream<ap_uint<8> > &output,
		volatile bool *outbuff_full,
		//QSPI
		volatile ap_uint<2> *spi_ce_n,
		volatile ap_uint<8> *spi_di,
		volatile ap_uint<8> *spi_do,
		volatile bool *tx_start,
		volatile bool *tx_done,
		volatile bool *disable_spi,
		volatile bool *disable_sfn,
		volatile ap_uint<8> *fillness
		)
{

#pragma HLS INTERFACE ap_none port=tx_done bundle=QSPI
#pragma HLS INTERFACE ap_none port=tx_start bundle=QSPI
#pragma HLS INTERFACE ap_none port=spi_ce_n bundle=QSPI
#pragma HLS INTERFACE ap_none port=spi_di bundle=QSPI
#pragma HLS INTERFACE ap_none port=spi_do bundle=QSPI

#pragma HLS INTERFACE ap_none port=disable_spi
#pragma HLS INTERFACE ap_none port=disable_sfn

#pragma HLS INTERFACE ap_none port=fillness bundle=FIFO

#pragma HLS INTERFACE ap_none port=inbuff_empty
#pragma HLS INTERFACE ap_none port=outbuff_full
//#pragma HLS INTERFACE ap_fifo depth=32 port=input
//#pragma HLS INTERFACE ap_fifo depth=32 port=output
//#pragma HLS INTERFACE axis port=input
//#pragma HLS INTERFACE axis port=output
#pragma HLS INTERFACE ap_fifo port=input
#pragma HLS INTERFACE ap_fifo port=output
//#pragma HLS RESOURCE variable=input  core=AXIS metadata="-bus_bundle S_AXIS"
//#pragma HLS RESOURCE variable=output core=AXIS metadata="-bus_bundle M_AXIS"
#pragma HLS INTERFACE ap_ctrl_none port=return

//#pragma HLS reset variable=reset_done

	//ap_uint<8> o_val;
	//static bool reset_done;
	bool is_init, is_fill;
	ap_uint<9> r_ptr = 0; // x512
	ap_uint<9> w_ptr = 0; // x512
	ap_uint<10> fifo_counter = 0;
	//go to QSPI mode:
	ap_uint<5> state = STATE_INIT;
	ap_uint<10> cnt=0;

	*spi_ce_n=0b11;
	*tx_start=false;
	*fillness=0x00;


	while(1) {

		switch (state) {
		case STATE_INIT: {
			ap_wait_until(((bool)*tx_done) == true);
			is_init=true;
			state = STATE_START;
			break;
		}
		case STATE_START: {
			if(((bool) *disable_spi)) {
				output.write(input.read());
				fifo_counter=0;
				r_ptr=0;
				w_ptr=0;
				is_init=true;
			} else {
				if(is_init && (fifo_counter >= 384 || (((bool) *disable_sfn) == false &&  fifo_counter >= 32))) {
					is_init=false;
#if 1
				} if (fifo_counter > 0 && !is_init && ((bool) *outbuff_full) == false) {
					is_fill=false;
					state = STATE_SPI_START;
				} else if (fifo_counter < 512 && ((bool) *inbuff_empty) == false) {
					is_fill=true;
					state = STATE_SPI_START;
#else
				} else if (fifo_counter < 512 && ((bool) *inbuff_empty) == false) {
					is_fill=true;
					state = STATE_SPI_START;
				} if (fifo_counter > 0 && !is_init && ((bool) *outbuff_full) == false) {
					is_fill=false;
					state = STATE_SPI_START;
#endif
				} else if(!is_init && fifo_counter==0 && ((bool) *disable_sfn) == true) {
					is_init=true; //re-buffer
				}

				if(fifo_counter.bit(9))
					*fillness = 0xFF;
				else
					*fillness = fifo_counter.range(8,1);
			}
			*spi_ce_n=0b11;
			*tx_start=false;
			break;
		}
#if 0
		case STATE_SPI_START: {
			cnt=0;
			if(is_fill)
				*spi_ce_n = (ap_uint<2>)(((ap_uint<2>)w_ptr.range(7,7)) + 1);
			else
				*spi_ce_n = (ap_uint<2>)(((ap_uint<2>)r_ptr.range(7,7)) + 1);
			state = STATE_SPI_CMD0;
			break;
		}
		case STATE_SPI_CMD0: {
			ap_wait_n(4);
			state = STATE_SPI_CMD;
			break;
		}
		case STATE_SPI_CMD: {
			if(is_fill)
				*spi_do = 0x02;
			else
				*spi_do = 0x03;
			*tx_start=true;
			state = STATE_SPI_CMD_0;
			break;
		}
		case STATE_SPI_CMD_0: {
			ap_wait_until(((bool)*tx_done) == false);
			state = STATE_SPI_CMD_SENT;
			break;
		}
		case STATE_SPI_CMD_SENT: {
			*tx_start=false;
			ap_wait_until(((bool)*tx_done) == true);
			state = STATE_SPI_ADDR1;
			break;
		}
		case STATE_SPI_ADDR1: {
			if(is_fill)
				*spi_do = w_ptr.range(6,6);
			else
				*spi_do = r_ptr.range(6,6);
			*tx_start=true;
			state = STATE_SPI_ADDR1_0;
			break;
		}
		case STATE_SPI_ADDR1_0: {
			ap_wait_until(((bool)*tx_done) == false);
			state = STATE_SPI_ADDR1_SENT;
			break;
		}
		case STATE_SPI_ADDR1_SENT: {
			*tx_start=false;
			ap_wait_until(((bool)*tx_done) == true);
			state = STATE_SPI_ADDR2;
			break;
		}
		case STATE_SPI_ADDR2: {
			if(is_fill)
				*spi_do = ((ap_uint<8>)w_ptr.range(5,0)) << 2;
			else
				*spi_do = ((ap_uint<8>)r_ptr.range(5,0)) << 2;
			*tx_start=true;
			state = STATE_SPI_ADDR2_0;
			break;
		}
		case STATE_SPI_ADDR2_0: {
			ap_wait_until(((bool)*tx_done) == false);
			state = STATE_SPI_ADDR2_SENT;
			break;
		}
		case STATE_SPI_ADDR2_SENT: {
			*tx_start=false;
			ap_wait_until(((bool)*tx_done) == true);
			state = STATE_SPI_ADDR3;
			break;
		}
		case STATE_SPI_ADDR3: {
			*spi_do = 0x00;
			*tx_start=true;
			state = STATE_SPI_ADDR3_0;
			break;
		}
		case STATE_SPI_ADDR3_0: {
			ap_wait_until(((bool)*tx_done) == false);
			state = STATE_SPI_ADDR3_SENT;
			break;
		}
		case STATE_SPI_ADDR3_SENT: {
			*tx_start=false;
			ap_wait_until(((bool)*tx_done) == true);
			state = STATE_SPI_DATA;
			break;
		}
		case STATE_SPI_DATA: {
			if(is_fill)
				*spi_do = input.read();
			*tx_start=true;
			state = STATE_SPI_DATA_0;
			break;
		}
		case STATE_SPI_DATA_0: {
			ap_wait_until(((bool)*tx_done) == false);
			state = STATE_SPI_DATA_SENT;
			break;
		}
		case STATE_SPI_DATA_SENT: {
			*tx_start=false;
			ap_wait_until(((bool)*tx_done) == true);
			state = STATE_SPI_DATA_SENT1;
			break;
		}
		case STATE_SPI_DATA_SENT1: {
			if(!is_fill)
				output.write(((ap_uint<8>) *spi_di));
			cnt++;
			if(cnt<1024)
				state = STATE_SPI_DATA;
			else
				state = STATE_SPI_DATA_END;
			break;
		}
		case STATE_SPI_DATA_END: {
			ap_wait_n(4);
			if(is_fill) {
				w_ptr++;
				fifo_counter++;
			} else {
				r_ptr++;
				fifo_counter--;
			}
			state = STATE_SPI_DATA_END1;
			break;
		}
		case STATE_SPI_DATA_END1: {
			*spi_ce_n=0b11;
			state = STATE_START;
			break;
		}
#else
		case STATE_SPI_START: {
			cnt=0;
			if(is_fill)
				*spi_ce_n = (ap_uint<2>)(((ap_uint<2>)w_ptr.range(8,8)) + 1);
			else
				*spi_ce_n = (ap_uint<2>)(((ap_uint<2>)r_ptr.range(8,8)) + 1);
			ap_wait_n(4);
			state = STATE_SPI_CMD;
			break;
		}
		case STATE_SPI_CMD: {
			if(is_fill)
				*spi_do = 0x02;
			else
				*spi_do = 0x03;
			*tx_start=true;
			ap_wait_until(((bool)*tx_done) == false);
#if 1
			state = STATE_SPI_CMD_SENT;
			break;
		}
		case STATE_SPI_CMD_SENT: {
#endif
			*tx_start=false;
			ap_wait_until(((bool)*tx_done) == true);
#if 1
			state = STATE_SPI_ADDR1;
			break;
		}
		case STATE_SPI_ADDR1: {
#endif
			if(is_fill)
				*spi_do = w_ptr.range(7,7);
			else
				*spi_do = r_ptr.range(7,7);
			*tx_start=true;
			ap_wait_until(((bool)*tx_done) == false);
#if 1
			state = STATE_SPI_ADDR1_SENT;
			break;
		}
		case STATE_SPI_ADDR1_SENT: {
#endif
			*tx_start=false;
			ap_wait_until(((bool)*tx_done) == true);
			state = STATE_SPI_ADDR2;
			break;
		}
		case STATE_SPI_ADDR2: {
			if(is_fill)
				*spi_do = ((ap_uint<8>)w_ptr.range(6,0)) << 1;
			else
				*spi_do = ((ap_uint<8>)r_ptr.range(6,0)) << 1;
			*tx_start=true;
			ap_wait_until(((bool)*tx_done) == false);
#if 1
			state = STATE_SPI_ADDR2_SENT;
			break;
		}
		case STATE_SPI_ADDR2_SENT: {
#endif
			*tx_start=false;
			ap_wait_until(((bool)*tx_done) == true);
			state = STATE_SPI_ADDR3;
			break;
		}
		case STATE_SPI_ADDR3: {
			*spi_do = 0x00;
			*tx_start=true;
			ap_wait_until(((bool)*tx_done) == false);
#if 1
			state = STATE_SPI_ADDR3_SENT;
			break;
		}
		case STATE_SPI_ADDR3_SENT: {
#endif
			*tx_start=false;
			ap_wait_until(((bool)*tx_done) == true);
			state = STATE_SPI_DATA;
			break;
		}
		case STATE_SPI_DATA: {
			if(is_fill)
				*spi_do = input.read();
			*tx_start=true;
			ap_wait_until(((bool)*tx_done) == false);
#if 1
			state = STATE_SPI_DATA_SENT;
			break;
		}
		case STATE_SPI_DATA_SENT: {
#endif
			*tx_start=false;
			ap_wait_until(((bool)*tx_done) == true);
			state = STATE_SPI_DATA_SENT1;
			break;
		}
		case STATE_SPI_DATA_SENT1: {
			if(!is_fill)
				output.write(((ap_uint<8>) *spi_di));
			cnt++;
			state = (cnt<512) ? STATE_SPI_DATA : STATE_SPI_DATA_END;
			break;
		}
		case STATE_SPI_DATA_END: {
			ap_wait_n(4);
			if(is_fill) {
				w_ptr++;
				fifo_counter++;
			} else {
				r_ptr++;
				fifo_counter--;
			}
#if 1
			state = STATE_SPI_DATA_END1;
			break;
		}
		case STATE_SPI_DATA_END1: {
#endif
			*spi_ce_n=0b11;
			ap_wait_n(4);
			state = STATE_START;
			break;
		}
#endif
		default:
			break;
		}
//		ap_wait();
	}


}


#endif
