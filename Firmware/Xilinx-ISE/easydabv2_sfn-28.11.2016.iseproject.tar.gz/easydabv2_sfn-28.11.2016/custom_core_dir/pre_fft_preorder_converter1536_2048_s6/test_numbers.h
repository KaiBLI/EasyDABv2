
#include <ap_int.h>

enum {
	I3_ZERO=0,
	I3_ONE,
	I3_07071,
	I3_05,
};


typedef struct {
	ap_int<3> real;
	ap_int<3> imag;
} cint3;

typedef struct {
	ap_int<16> real;
	ap_int<16> imag;
} cint16;

#define IN_NUM 116736

extern const cint3 pre_fft_reord_in[IN_NUM];

#define OUT_NUM 157696

extern const cint16 pre_fft_reord_out[OUT_NUM];
