

#include <ap_int.h>
#include <ap_utils.h>
#include <hls_stream.h>

enum {
	I3_ZERO=0,
	I3_ONE,
	I3_07071,
	I3_05,
};

typedef struct {
	ap_int<3> real;
	ap_int<3> imag;
} cint3;

typedef struct {
//	cint3	   data;
	ap_uint<6> data;
	ap_uint<1> dest;
	ap_uint<1> last;
} cplxi3stream;



typedef struct {
	ap_int<16> real;
	ap_int<16> imag;
} cint16;

typedef struct {
//	cint16	   data;
	ap_uint<32> data;
	ap_uint<1>  last;
} cplxi16stream;

const ap_int<16> f_tab[4] = { 0, 32767, 23170, 0 };

const ap_int<16> remap_int(ap_int<3> x)
{
#pragma HLS inline
	if(x<0)
		return -(f_tab[-(x)]);
	else
		return f_tab[x];
}

const ap_uint<32> remap_int2(ap_uint<6> x)
{
#pragma HLS inline
	ap_int<3> re=x.range(2,0);
	ap_int<3> im=x.range(5,3);
	cint16 o;
	o.real = remap_int(re);
	o.imag = remap_int(im);
	ap_uint<32> *dO = (ap_uint<32> *) &o;

	return (*dO);
//reinterpret_cast<ap_uint<32>*>
//	return ((ap_uint<16>)remap_int((ap_int<3>)x.range(2,0)), (ap_uint<16>)remap_int((ap_int<3>)x.range(5,3)));
}

//21-74-45
//22-68-38
//22-71-38
void pre_ifft_reord(hls::stream<ap_uint<6> > &input, hls::stream<cplxi16stream> &output)
{
#pragma HLS INTERFACE ap_fifo port=input
#pragma HLS INTERFACE ap_fifo port=output
#pragma HLS RESOURCE variable=input  core=AXIS metadata="-bus_bundle S_AXIS"
#pragma HLS RESOURCE variable=output core=AXIS metadata="-bus_bundle M_AXIS"

#pragma HLS INTERFACE ap_ctrl_none port=return
#pragma HLS PIPELINE off

	ap_uint<6> x;
	cplxi16stream y;
	ap_uint<12> i;

	if(!input.empty()) {
		x = input.read(); //data=0 -> -0.7071, data=1 -> 0.7071
		LOOP11:for(i = 0; i < 2048; i++) {
	#pragma HLS loop_tripcount min=2048 max=2048 avg=2048
			if(i==0) {
				/* zero frequency */
				y.data = 0; //will be 0 or 1
				y.last = 0;
				output.write(y); i++;
				//output.write((cplxi16stream){0,0}); i++;
				//output.write({0,0}); i++;
			} else if (i < 769) {
				x = input.read();
			} else if(i < 1280){
				x = 0;
			} else {
				x = input.read();
			}
			y.data = remap_int2(x);
			y.last = (i==2047) ? 1 : 0;
			output.write(y);
		}
	}
}
