

#include <ap_int.h>
#include <hls_stream.h>

#include "test_numbers.h"


typedef struct {
	cint3	   data;
	ap_uint<1> dest;
	ap_uint<1> last;
} cplxi3stream;

typedef struct {
	cint16	   data;
	ap_uint<1> last;
} cplxi16stream;

typedef ap_uint<24> uint24;

void pre_ifft_reord(hls::stream<cplxi3stream> &input, hls::stream<cplxi16stream> &output, hls::stream<uint24> &out_conf);








int read_data(hls::stream<cplxi16stream> &data_out,int *o_idx, FILE *out_fp, FILE *out_fp_my)
{
	int i=0;
	int not_ok=0;
	int read_size = data_out.size();
	//fprintf(stderr, "read[%d]=%d\n", *o_idx, read_size);
	if(read_size == 0) {
		fprintf(stderr, "read[%d]=%d nothing to read!\n", *o_idx, read_size);
		return 1;
	}

	int to_read = read_size;
	if(read_size != 2048){
		fprintf(stderr, "bad read size: %d", read_size);
		not_ok++;
		return not_ok;
	}

	do {
		cplxi16stream var = data_out.read();
		fprintf(out_fp_my,"%d %d %d %d\n",(*o_idx),i,(int)var.data.real, (int)var.data.imag);

		int idx0=0;
		int idx1=0;
		int out_re=0;
		int out_im=0;
		if(fscanf(out_fp,"%d %d %d %d",&idx0,&idx1,&out_re,&out_im) !=4){
			fprintf(stderr, "output scan failed on: %d %d\n", (*o_idx), i);
			return 1;
		}

		if(i != idx1 || (*o_idx) != idx0) {
			fprintf(stderr, "output index mismatch: %d %d != %d %d\n", (*o_idx), i, idx0, idx1);
			return 1;
		}


		//if((int)var.data.real != out_re || (int)var.data.imag != out_im) {
		if((int)var.data.real != out_re || (int)var.data.imag != out_im) {
			//if((*o_idx) < 2)
			fprintf(stderr, "%d %d err: %d %d != %d %d\n", (*o_idx), i, (int)var.data.real, (int) var.data.imag, out_re, out_im);
			fprintf(stderr, "x");
			if((not_ok+1) % 128 == 0) fprintf(stderr, "\n");
			not_ok++;
		} else {
			//fprintf(stderr, ".");
			//if((i+1) % 256 == 0) fprintf(stderr, "\n");
		}

		i++;
	} while (i < read_size);
	//fprintf(stderr, "\n");
	(*o_idx)++;

	if(not_ok)
		exit(1);

	return not_ok;
}


ap_int<3> in_remap(float in)
{
	if(in>=0.99)
		return I3_ONE;
	if(in<=-0.99)
		return -I3_ONE;

	if(in>=0.7070)
		return I3_07071;
	if(in<=-0.7070)
		return -I3_07071;

	if(in==0.0)
		return I3_ZERO;

	fprintf(stderr, "bad number: %f\n", in);
	exit(1);
}

int main()
{

	int not_ok = 0;
	/**************************************************************************************
	 * HW Implementation
	 **************************************************************************************/
    hls::stream<cplxi3stream> data_in;
    hls::stream<cplxi16stream> data_out;
    hls::stream<uint24> data_conf;

    int in_ptr = 0;
    int out_ptr = 0;

    int i_idx = 0;
    int o_idx = 0;
    FILE *in_fp = fopen("input.dat","rb");
    if(!in_fp) {
    	fprintf(stderr, "can't open input\n");
    }

    FILE *out_fp = fopen("output.golden.dat","rb");
    if(!out_fp) {
    	fprintf(stderr, "can't open output\n");
    }
    FILE *out_fp_my = fopen("output.dat","wb");
    if(!out_fp) {
    	fprintf(stderr, "can't open output2\n");
    }

    for(int i_idx = 0; i_idx < IN_NUM/1536; i_idx++) {
    	// send null
		cplxi3stream var;

		// Fill HW buffers
		if (i_idx==0) {
			var.last = 1;
			var.dest = 1;
			var.data.real = 0;
			var.data.imag = 0;
			data_in.write(var);
			pre_ifft_reord(data_in, data_out, data_conf);
			if(data_conf.size()) {
				uint24 conf =  data_conf.read();
				fprintf(stderr, "conf[%d] = %d so=%d\n", o_idx, (int)conf, data_conf.size());
			}
			not_ok += read_data(data_out, &o_idx, out_fp, out_fp_my);
			while(data_conf.size()) {
				uint24 conf =  data_conf.read();
				fprintf(stderr, "conf[%d] = %d so=%d\n", o_idx, (int)conf, data_conf.size());
			}
		}

		// Fill HW buffers
		for (int i=0; i < 1536; i++) {
			var.last = (i==1535) ? 1 :0;
			var.dest = 0;
			int idx0=0;
			int idx1=0;
			float in_re=0;
			float in_im=0;
			if(fscanf(in_fp,"%d %d %f %f",&idx0,&idx1,&in_re,&in_im) !=4){
				fprintf(stderr, "input scan failed on: %d %d\n", i_idx, i);
				return 1;
			}

			if(i != idx1 || i_idx != idx0) {
				fprintf(stderr, "input index mismatch: %d %d != %d %d\n", i_idx, i, idx0, idx1);
				return 1;
			}

			var.data.real = in_remap(in_re);
			var.data.imag = in_remap(in_im);
			data_in.write(var);
		}

		pre_ifft_reord(data_in, data_out, data_conf);

		while(data_conf.size()) {
			uint24 conf =  data_conf.read();
			fprintf(stderr, "conf[%d] = %d so=%d ?????\n", o_idx, (int)conf, data_conf.size());
		}

		//check hw/sw results:
		not_ok += read_data(data_out, &o_idx, out_fp, out_fp_my);
    }

    fclose(in_fp);
    fclose(out_fp);
    fclose(out_fp_my);


    // Compare the results file with the golden results
    int retval = system("diff --brief -w output.dat output.golden.dat");
    if (retval != 0) {
    	printf("Test failed  !!!\n");
    	not_ok++;
    } else {
    	printf("Test passed !\n");
    }

    return not_ok;
}
