

#include <ap_int.h>
#include <ap_utils.h>
#include <hls_stream.h>


#include <iostream>       // std::cout
#include <pthread.h>

#if 0
static bool pps_in = false;
static bool time_is_setted = false;
static bool not_exit = true;
static bool set_time = false;
static hls::stream<ap_uint<8> > data_in;
static ap_uint<32> time_out = 0;


void *tick(void *arg)
{
 while(not_exit) {
  usleep(900000);
  fprintf(stderr, "tick!\n");
  pps_in = true;
  usleep(100000);

  fprintf(stderr, "time out: %08x\n", (uint64_t) time_out);


//  fprintf(stderr, "OUT TIME: %d:%d:%d\n", (int) time_out.range(16,12), (int) time_out.range(11,6), (int) time_out.range(5,0));
//  fprintf(stderr, "OUT DATE: %d.%d.%d\n", (int) time_out.range(21,17), (int) time_out.range(25,22), (int) time_out.range(32,26));
#if 0
  fprintf(stderr, "OUT TIME: %d.%d.%d_%d:%d:%d\n",
		  (int) time_out.range(31,26),
		  (int) time_out.range(25,22),
		  (int) time_out.range(21,17),
		  (int) time_out.range(16,12),
		  (int) time_out.range(11,6),
		  (int) time_out.range(5,0));
#endif
  pps_in = false;
 }
  // do stuff...
}
#endif

void nmea2num(hls::stream<ap_uint<8> > &uart_in, volatile ap_uint<32> *time_out, volatile bool *time_out_vld, volatile bool *osc_is_ok);



char Ary[]  = "$GPRMC,173711.000,A,5024.9593,N,03037.2008,E,0.22,116.40,260716,,,A*62\r\n"
			  "$GPRMC,173712.000,A,5024.9592,N,03037.2008,E,0.60,110.97,260716,,,A*6A\n"
		  	  "$GPAMC,173713.000,A,5024.9591,N,03037.2010,E,0.57,110.97,260716,,,A*65\n"
		      "$GPRMC,144331.080,V,,,,,0.13,36.12,290716,,,N*7A\n"
			  "$GPRMC,144332.080,V,,,,,0.27,36.12,290716,,,N*7E\r\n"
		  	  "$GPRMC,173714.000,B,5024.9591,N,03037.2007,E,0.49,110.97,260716,,,A*6B\r\n"
			  "$GPBMC,173715.000,A,5024.9589,N,03037.2011,E,0.29,110.97,260716,,,A*62\r\n"
	  	  	  "$GPRMC,173716.000,A,5024.9590,N,03037.2004,E,0.44,110.97,260716,,,A*66\n"
		      "$GNRMC,121459.00,A,5024.97029,N,03037.17657,E,0.026,,130916,,,A*6F\n"
		      "$GNRMC,121459.00,A,5024.97029,N,03037.17657,E,0.026,,,,,A*6F\n"
	      	  "$GNRMC,120718.00,V,,,,,,,130916,,,N*62\n"
	      	  "$GNVTG,,,,,,,,,N*2E\n"
	      	  "$GNGGA,120718.00,,,,,0,00,99.99,,,,,,*75\n"
	      	  "$GNGSA,A,1,,,,,,,,,,,,,99.99,99.99,99.99*2E\n"
	      	  "$GNGSA,A,1,,,,,,,,,,,,,99.99,99.99,99.99*2E\n"
	      	  "$GPGSV,2,1,07,10,,,47,16,,,37,18,,,46,21,,,47*77\n"
	      	  "$GPGSV,2,2,07,26,,,36,27,,,36,32,,,40*7A\n"
	      	  "$GLGSV,1,1,02,67,,,42,82,,,40*6E\n"
	      	  "$GNGLL,,,,,120718.00,V,N*59\n"
	      	  "$GNZDA,120718.00,13,09,2016,00,00*7B\n"
	          "$GNRMC,120719.00,A,5024.96768,N,03037.17712,E,0.041,,130916,,,A*6B\n"
	  	  	  "$GPCCC,260716,,,A*63\n";

int main()
{
	int ret=0;

	/**************************************************************************************
	 * HW Implementation
	 **************************************************************************************/

	hls::stream<ap_uint<8> > data_in;
    int pos = 0;
    bool time_out_vld=false;
    bool disable_nmea=false;
    bool osc_is_ok=false;
    ap_uint<32> time_out;

    //do_eti_parser(input, input_size, out2, output_size);
    while(pos < sizeof(Ary)) {
    	data_in.write(Ary[pos]);
    	pos++;
    }

//    std::thread first (tick);
    pthread_t thread1;
    int i1;
//    i1 = pthread_create( &thread1, NULL, tick, (void*) "thread 1");


    while(1) {
    	nmea2num(data_in, &time_out, &time_out_vld, &osc_is_ok);
    	if(data_in.empty())
    		break;
    }

//    not_exit = false;
//    first.join();
//    pthread_join(thread1,NULL);


	return ret;
}

