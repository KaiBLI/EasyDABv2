#include <ap_int.h>
#include <ap_utils.h>
#include <hls_stream.h>

#define SYNC_VER2 1

enum {
	STATE_SYNC=0,
	STATE_SYNC_DLR,
	STATE_SYNC_G,
	STATE_SYNC_P,
	STATE_SYNC_R,
	STATE_SYNC_M,
	STATE_SYNC_C,
	STATE_HMS,
	STATE_STATUS,
	STATE_COMMACNT,
	STATE_DMY,
	STATE_PROCESS0,
	STATE_PROCESS1
};

static const ap_uint<9> calendar2[13] = {0, 0,
		31,
		(31+28),
		(31+28+31),
		(31+28+31+30),
		(31+28+31+30+31),
		(31+28+31+30+31+30),
		(31+28+31+30+31+30+31),
		(31+28+31+30+31+30+31+31),
	    (31+28+31+30+31+30+31+31+30),
	    (31+28+31+30+31+30+31+31+30+31),
	    (31+28+31+30+31+30+31+31+30+31+30)};

/*
 *
$GPRMC,173711.000,A,5024.9593,N,03037.2008,E,0.22,116.40,260716,,,A*62
$GPRMC,173712.000,A,5024.9592,N,03037.2008,E,0.60,110.97,260716,,,A*6A
$GPRMC,173713.000,A,5024.9591,N,03037.2010,E,0.57,110.97,260716,,,A*65
$GPRMC,173714.000,A,5024.9591,N,03037.2007,E,0.49,110.97,260716,,,A*6B
$GPRMC,173715.000,A,5024.9589,N,03037.2011,E,0.29,110.97,260716,,,A*62
$GPRMC,173716.000,A,5024.9590,N,03037.2004,E,0.44,110.97,260716,,,A*66
$GPRMC,173717.000,A,5024.9590,N,03037.2003,E,0.21,110.97,260716,,,A*63

 * */

enum {
	STATE_TIM_SYNC0,
	STATE_TIM_SYNC1,
	STATE_TIM_SYNC2,
	STATE_TIM_SYNC3,
	STATE_TIM_SIZE0,
	STATE_TIM_SIZE1,
	STATE_TIM_PAYLOAD//,
//	STATE_TIM_CRC0,
//	STATE_TIM_CRC1
};


/*
NO TIM:
#=== Resource usage ===
SLICE:           92
LUT:            270
FF:             203
DSP:              2
BRAM:             0
SRL:              9
#=== Final timing ===
CP required:    10.000
CP achieved:    6.995

TIM_V1:

#=== Resource usage ===
SLICE:          106
LUT:            290
FF:             219
DSP:              2
BRAM:             0
SRL:              9
TIM_V2
#=== Resource usage ===
SLICE:           95
LUT:            292
FF:             218
DSP:              2
BRAM:             0
SRL:              9
 *
 * */

void nmea2num(hls::stream<ap_uint<8> > &uart_in,
		volatile ap_uint<32> *time_out, volatile bool *time_out_vld, volatile bool *osc_is_ok)
{
#pragma HLS ARRAY_PARTITION variable=calendar2 complete dim=1

#pragma HLS INTERFACE ap_fifo port=uart_in
//#pragma HLS INTERFACE axis port=uart_in
#pragma HLS INTERFACE ap_none port=time_out
#pragma HLS INTERFACE ap_none port=time_out_vld
#pragma HLS INTERFACE ap_none port=osc_is_ok

#pragma HLS RESOURCE variable=uart_in  core=AXIS metadata="-bus_bundle S_AXIS"

#pragma HLS INTERFACE ap_ctrl_none port=return

	ap_uint<8> val;
	ap_uint<9> val_save;
	ap_uint<4> state = STATE_SYNC;
	//ap_uint<4> state_tim = STATE_TIM_SYNC0;
	ap_uint<3> state_tim = STATE_TIM_SYNC0;
	ap_uint<3> read_pos;
	ap_uint<32> time_out_reg = 0;
	ap_uint<32> multiplier = 0;
	ap_uint<4> mon_saved;
	ap_uint<6> tim_pos = 0;
	ap_uint<6> tim_len = 0;
	//ap_uint<12> seconds_readed=0;
//	ap_uint<4> seconds_readed=0;
	bool state_val, state_val2=false;
	*time_out_vld = false;

	while(1) {
#ifndef  __SYNTHESIS__
    	if(uart_in.empty())
    		break;
#endif
    	multiplier = 0;
    	if(state < STATE_PROCESS0) {
    		val = uart_in.read();
    		if(val == '\n') state = STATE_SYNC;

			if(val >= 0x30 && val <= 0x39) {
				if(read_pos.bit(0) == 0) {
					val_save = (val - 0x30)*10;
				} else {
					val_save += (val - 0x30);
				}
			} else {
				val_save = 0;
			}
#if 1
			if(state < STATE_HMS) {
#if 0
				if((tim_pos == 0 && val == 0xb5)
				|| (tim_pos == 1 && val == 0x62)
				|| (tim_pos == 2 && val == 0x0d)
				|| (tim_pos == 3 && val == 0x12)
				) {
					tim_pos++;
					tim_len = 0;
				} else if (tim_pos == 4 && val < 120 && val > 4) {
					tim_len = val + 8;
					tim_pos++;
				} else if (tim_len && tim_pos == 5 && val == 0) {
					tim_pos++;
				} else if (tim_len && tim_pos < tim_len) {
					if(tim_pos==10 && (val & 0x18 == 0x18))
						state_val2=true;
					if(tim_pos==11 && state_val2==true && (val & 0x20 != 0x20))
						state_val2=false;
					tim_pos++;
				} else {
					tim_pos=0;
				}
#else
				switch(state_tim) {
					case STATE_TIM_SYNC0:
						state_tim = (val == 0xb5) ? STATE_TIM_SYNC1 : STATE_TIM_SYNC0;
						break;
					case STATE_TIM_SYNC1:
						state_tim = (val == 0x62) ? STATE_TIM_SYNC2 : STATE_TIM_SYNC0;
						break;
					case STATE_TIM_SYNC2:
						state_tim = (val == 0x0d) ? STATE_TIM_SYNC3 : STATE_TIM_SYNC0;
						break;
					case STATE_TIM_SYNC3:
						state_tim = (val == 0x12) ? STATE_TIM_SIZE0 : STATE_TIM_SYNC0;
						break;
					case STATE_TIM_SIZE0:
						state_tim = (val < 62 && val > 4) ? STATE_TIM_SIZE1 : STATE_TIM_SYNC0;
						tim_len = val+2;
						tim_pos=0;
						break;
					case STATE_TIM_SIZE1:
						state_tim = (val == 0) ? STATE_TIM_PAYLOAD : STATE_TIM_SYNC0;
						break;
					case STATE_TIM_PAYLOAD:

						if(tim_pos==4 && ((val & 0x18) == 0x18)) {
							state_val2=true;
						} else if(tim_pos==5 && state_val2==true && ((val & 0x20) != 0x20)) {
							state_val2=false;
						}

						tim_pos++;
						state_tim = (tim_pos == tim_len) ? STATE_TIM_SYNC0 : STATE_TIM_PAYLOAD;
						//state_tim = (tim_pos ==tim_len) ? STATE_TIM_CRC0 : STATE_TIM_PAYLOAD;
						break;
//					case STATE_TIM_CRC0:
//						state_tim = STATE_TIM_CRC1;
//						break;
//					case STATE_TIM_CRC1:
//						state_tim = STATE_TIM_SYNC0;
//						break;
				}
#endif
			}// else {
//				state_tim = STATE_TIM_SYNC0;
//			}
#endif

    	}
		switch(state) {
		case STATE_SYNC:
			state = (val == '$') ? STATE_SYNC_DLR : STATE_SYNC;
			break;
		case STATE_SYNC_DLR:
			state = (val == 'G') ? STATE_SYNC_G : STATE_SYNC;
			break;
		case STATE_SYNC_G:
			state = (val == 'P'||val == 'N') ? STATE_SYNC_P : STATE_SYNC;
			break;
		case STATE_SYNC_P:
			state = (val == 'R') ? STATE_SYNC_R : STATE_SYNC;
			break;
		case STATE_SYNC_R:
			state = (val == 'M') ? STATE_SYNC_M : STATE_SYNC;
			break;
		case STATE_SYNC_M:
			state = (val == 'C') ? STATE_SYNC_C : STATE_SYNC;
			break;
		case STATE_SYNC_C:
			if(val == ',') {
				state = STATE_HMS;
				//time_out_reg = 0;
				time_out_reg=946684800 - 315964800;
				read_pos=0;
			} else {
				state = STATE_SYNC;
			}
			break;

		case STATE_HMS:
			switch(read_pos) {
			case 0:
				if(val == ',') state=STATE_SYNC;
				break;
			case 1: //h
				multiplier=60*60;
				break;
			case 3: //m
				multiplier=60;
				break;
			case 5: //s
				multiplier=1;
#ifndef  __SYNTHESIS__
//				fprintf(stderr, "TIME: %d:%d:%d\n", (int) time_out_reg.range(16,12), (int) time_out_reg.range(11,6), (int) time_out_reg.range(5,0));
#endif
				break;
			default:
				break;
			}

			if(read_pos < 6) read_pos++;

			if(val == ',' && read_pos>0) state=STATE_STATUS;
			break;
		case STATE_STATUS:
			state_val = (val == 'A') ? true : false;
			read_pos=0;
			state=STATE_COMMACNT;
			break;
		case STATE_COMMACNT:
			if(val == ',') {
				if(read_pos==6) {
					state=STATE_DMY;
					read_pos=0;
				} else {
					read_pos++;
				}
			}
			break;
		case STATE_DMY: {
			/*  sec <= time_in[5:0];
				min <= time_in[11:6];
				hour <= time_in[16:12];
				day <= time_in[21:17];
				month <= time_in[25:22];
				year <=  time_in[32:26]; */
			switch(read_pos) {
			case 0:
				if(val == ',') { state=STATE_SYNC; state_val=false;}
				break;
			case 1: //d
				multiplier=60*60*24;
				val_save = val_save - 1;
				break;
			case 3: //M
				multiplier=60*60*24;
				mon_saved=val_save;
				val_save = calendar2[val_save];
				break;
			case 5: {//y
				multiplier=365*60*60*24;
				state=STATE_PROCESS0;
				break;
			}
			default:
				break;
			}

			read_pos++;
			}
			break;
		case STATE_PROCESS0:
			multiplier=60*60*24;
//			//add leap day for this year
			if(mon_saved <= 2 && val_save.range(1,0)==0) {
				val_save=(val_save>>2); // add leap year's days
			} else {
				val_save=(val_save>>2)+1; // add leap year's days + this year's leap day.
			}
			state=STATE_PROCESS1;
			break;
		case STATE_PROCESS1: {
#ifndef  __SYNTHESIS__
				int ts = time_out_reg + 315964800;
				time_t rawtime = ts;
				struct tm * timeinfo = gmtime (&rawtime);
				char buffer [128];
				strftime (buffer,128,"%H:%M:%S %d.%m.%Y",timeinfo);
			fprintf(stderr, "DATE %s:%s\n", state_val ? "OK" : "BAD", buffer);
#endif
			*time_out = time_out_reg;
			*time_out_vld = state_val;
			//TODO: implement it.
			*osc_is_ok = state_val2;
			//*osc_is_ok = state_val;

			state=STATE_SYNC;
			break;
		}
		default:
			state=STATE_SYNC;
			break;
		}
		time_out_reg += multiplier*val_save;
	}
}

