

#include <ap_int.h>
#include <hls_stream.h>

#include "dqpsk_prbs_null_test_values.h"



enum {
	UI1_MINUS07071=0,
	UI1_PLUS07071
};

enum {
	I3_ZERO=0,
	I3_ONE,
	I3_07071,
	I3_05,
};

typedef struct {
	ap_uint<1> real;
	ap_uint<1> imag;
} cuint1;

typedef struct {
	cuint1 data;
	ap_uint<1> dest;
	ap_uint<1> last;
} cplxui1stream;


typedef struct {
	ap_int<3> real;
	ap_int<3> imag;
} cint3;

#ifdef DEBUG1
typedef struct {
	ap_int<3> real;
	ap_int<3> imag;
	ap_int<3> real_phase;
	ap_int<3> imag_phase;
	ap_int<3> real_in3;
	ap_int<3> imag_in3;
	ap_uint<1> real_in;
	ap_uint<1> imag_in;
} cint3out;

typedef struct {
	cint3out	   data;
	ap_uint<1> dest;
	ap_uint<1> last;
} cplxi3stream;

#else
typedef struct {
	cint3	   data;
	ap_uint<1> dest;
	ap_uint<1> last;
} cplxi3stream;
#endif



void dqpsk_modulator(hls::stream<cplxui1stream> &input, hls::stream<cplxi3stream> &output);




/*****************************************************************************************
 * Software implementation stuff
 *****************************************************************************************/
// Usable AlmostEqual function
bool AlmostEqual2sComplement(float A, float B, float maxDiff/*0.0001*/)
{
    float diff = B - A;
    if(A > B)
    	diff = -diff;

    if(diff <= maxDiff)
    	return true;

    //fprintf(stderr, "diff: %.6f\n", diff);
    return false;
}

int checkNum(float num)
{
	if(
	!AlmostEqual2sComplement(num, 0.707107, 0.0001) &&
	!AlmostEqual2sComplement(num, -0.707107, 0.0001) &&
	!AlmostEqual2sComplement(num, 1.0, 0.0001) &&
	!AlmostEqual2sComplement(num, -1.0, 0.0001) &&
	!AlmostEqual2sComplement(num, 0, 0.0001)
	&&
	!AlmostEqual2sComplement(num, 0.5, 0.0001) &&
	!AlmostEqual2sComplement(num, -0.5, 0.0001)

	) {
		fprintf(stderr, "UNKNOWN NUMBER: %.6f\n", num);
		exit(1);
		return 1;
	}
	return 0;
}

cplx_f calc_cplxmul(const cplx_f in1, const cplx_f in2)
{
	cplx_f ret;
	ret.re = (in1.re * in2.re - in1.im * in2.im);
	checkNum(in1.re);
	checkNum(in1.im);
	checkNum(in2.re);
	checkNum(in2.im);
	checkNum(in1.re * in2.re);
	checkNum(in1.im * in2.im);
	checkNum(in1.re * in2.im);
	checkNum(in1.im * in2.re);

	checkNum(ret.re);
	//fprintf(stderr, "%.3f * %.3f (%.3f) - %.3f * %.3f (%.3f)", in1.re, in2.re, in1.re * in2.re, in1.im, in2.im, in1.im * in2.im);
	//fprintf(stderr, "re: %.6f * %.6f (%.6f) - %.6f * %.6f (%.6f)\n", in1.re, in2.re, in1.re * in2.re, in1.im, in2.im, in1.im * in2.im);
	ret.im = (in1.re * in2.im + in1.im * in2.re);
	checkNum(ret.im);
	return ret;
}

void calc_result(const cplx_f *in, cplx_f *out)
{

//    memcpy(out, diff_mod_in_0, 1536 * sizeof(cplx_f));
    for (size_t i = 0; i < 1536; i ++){
    	out[i] =  diff_mod_in_0[i];
    }

    for (size_t i = 0; i < DIFF_MOD_IN_SIZE_1; i += 1536) {
    	//1536
        for (size_t j = 0; j < 1536; j ++) {
#ifdef DEBUG1
        	if((i==1536 || i==0) && j==0) {
        		fprintf(stderr, "mul out:(%.6f + %.6fi) * in:(%.6f + %.6fi) = ", out[j].re, out[j].im, in[j].re, in[j].im);
        	}
#endif
        	out[1536 + j] = calc_cplxmul(out[j],  in[j]);
#ifdef DEBUG1
        	if((i==1536  || i==0) && j==0) {
        		fprintf(stderr, "(%.6f + %.6fi)\n", out[1536 + j].re, out[1536 + j].im);
        	}
#endif
        }
        in += 1536; //+1536
        out += 1536;//+1536
    }
}





const float f_tab[4] = {
	0.0,
	1.0,
	0.70710678,
	0.0,
};

#ifdef DEBUG1
cint3 phase_references_saved[1536];
cuint1 inputs_saved[1536];
#endif


ap_int<3> sym1to3_test(ap_uint<1> in)
{
	if(in==UI1_MINUS07071)
		return -I3_07071;
	return I3_07071;
}


int read_data(hls::stream<cplxi3stream> &data_out, int o_idx, FILE *in_golden, FILE *out_fp, int check_in)
{
	int i=0;
	int not_ok=0;

	int read_size = data_out.size();
	fprintf(stderr, "read[%d]=%d\n", o_idx, read_size);
	if(read_size == 0) {
		fprintf(stderr, "read[%d]=%d, error?\n", o_idx, read_size);
		return 0;
	}
	int to_read = read_size;
	if(read_size != 1536) {
		fprintf(stderr, "read[%d]=%d, error?\n", o_idx, read_size);
	}

	do {
		cplxi3stream var;
		var=data_out.read();
		if(var.dest!=0) {
			fprintf(stderr, "not this destination\n");
			read_size--;
			continue;
		}
		//fprintf(stderr, "%.6f")
		cplx_f val_f;

		if(var.data.real >= 0)
			val_f.re = f_tab[var.data.real];
		else
			val_f.re = -f_tab[-var.data.real];

		if(var.data.imag >= 0)
			val_f.im = f_tab[var.data.imag];
		else
			val_f.im = -f_tab[-var.data.imag];

		fprintf(out_fp, "%d %d %f %f\n", o_idx, i, val_f.re, val_f.im);

		if(!AlmostEqual2sComplement(val_f.re, diff_mod_out_0[o_idx*1536+i].re, 0.0001)) {
			fprintf(stderr, "re[%d][%d]: %.6f != %.6f\n", o_idx, i, val_f.re, diff_mod_out_0[o_idx*1536+i].re);
			not_ok++;
		}
		if(!AlmostEqual2sComplement(val_f.im, diff_mod_out_0[o_idx*1536+i].im, 0.0001)) {
			fprintf(stderr, "im[%d][%d]: %.6f != %.6f\n", o_idx, i, val_f.im, diff_mod_out_0[o_idx*1536+i].im);
			not_ok++;
		}

		/*********************************************************************
		 * Check with file contents
		 *********************************************************************/
		int idx0=0;
		int idx1=0;
		float in_re=0;
		float in_im=0;
		if(fscanf(in_golden,"%d %d %f %f",&idx0,&idx1,&in_re,&in_im) !=4){
			fprintf(stderr, "output scan failed on: %d %d\n", o_idx, i);
			return 1;
		}

		if(idx0!=o_idx || idx1 != i) {
			fprintf(stderr, "output order failure: %d %d != %d %d\n", o_idx, i, idx0, idx1);
			return 1;
		}


		if(!AlmostEqual2sComplement(val_f.re, in_re, 0.0001)) {
			fprintf(stderr, "re[%d][%d]: %.6f != %.6f\n", o_idx, i, val_f.re, in_re);
			not_ok++;
		}
		if(!AlmostEqual2sComplement(val_f.im, in_im, 0.0001)) {
			fprintf(stderr, "im[%d][%d]: %.6f != %.6f\n", o_idx, i, val_f.im, in_im);
			not_ok++;
		}


#ifdef DEBUG1
		if(o_idx!=0){
			if(phase_references_saved[i].real != var.data.real_phase ||
			phase_references_saved[i].imag != var.data.imag_phase) {
				fprintf(stderr, "phase_reference[%d][%d]: mismatch: {%d,%d} != {%d,%d}\n", o_idx, i,
						(int)phase_references_saved[i].real, (int)phase_references_saved[i].imag,
						(int)var.data.real_phase, (int)var.data.imag_phase);
				not_ok++;
			}
		}
		phase_references_saved[i].real = var.data.real;
		phase_references_saved[i].imag = var.data.imag;
		if(check_in){
			if(inputs_saved[i].real != var.data.real_in ||
			   inputs_saved[i].imag != var.data.imag_in) {
				fprintf(stderr, "inputs_saved[%d][%d]: mismatch: {%d,%d} != {%d,%d}\n", o_idx, i,
						(int)inputs_saved[i].real, (int)inputs_saved[i].imag,
						(int)var.data.real_in, (int)var.data.imag_in);
				not_ok++;
			}

			if(sym1to3_test(inputs_saved[i].real) != var.data.real_in3 ||
					sym1to3_test(inputs_saved[i].imag) != var.data.imag_in3) {
				fprintf(stderr, "inputs_saved_3[%d][%d]: mismatch: {%d,%d} != {%d,%d}\n", o_idx, i,
						(int)sym1to3_test(inputs_saved[i].real), (int)sym1to3_test(inputs_saved[i].imag),
						(int)var.data.real_in, (int)var.data.imag_in);
				not_ok++;
			}

		}
#endif

		if(not_ok)
			return (not_ok);
		i++;
	} while (i < read_size);
	return not_ok;
}

int main()
{

	int not_ok = 0;
	cplx_f diff_mod_out_to_check[DIFF_MOD_OUT_SIZE];


	/**************************************************************************************
	 * SW Implementation
	 **************************************************************************************/
	calc_result(diff_mod_in_1, diff_mod_out_to_check);

	for(size_t i = 0; i<DIFF_MOD_OUT_SIZE;i++){
		if(!AlmostEqual2sComplement(diff_mod_out_to_check[i].re, diff_mod_out_0[i].re, 0.0001) ||
		   !AlmostEqual2sComplement(diff_mod_out_to_check[i].im, diff_mod_out_0[i].im, 0.0001)) {
			fprintf(stderr, "result on index %d is not ok: %.6f !=  %.6f or %.6f !=  %.6f\n", i,
					diff_mod_out_to_check[i].re, diff_mod_out_0[i].re, diff_mod_out_to_check[i].im, diff_mod_out_0[i].im);
			not_ok++;
		}
	}



	/**************************************************************************************
	 * HW Implementation
	 **************************************************************************************/
    hls::stream<cplxui1stream> data_in;
    hls::stream<cplxi3stream> data_out;


    FILE *in_fp = fopen("input_diffmod.dat", "rb");
    FILE *in_golden = fopen("output.golden.dat", "rb");
    FILE *out_fp = fopen("output.dat", "wb");

    if(!in_fp){
    	fprintf(stderr, "can't open input golden file\n");
    	return 1;
    }
    if(!in_golden) {
    	fprintf(stderr, "can't open input file\n");
    	return 1;
    }
    if(!out_fp) {
    	fprintf(stderr, "can't open output file\n");
    	return 1;
    }

    int i_idx = 0;
    for(int o_idx = 0; o_idx < DIFF_MOD_OUT_SIZE/1536; o_idx++) {

    	if(i_idx==0) {
			cplxui1stream var;
			var.dest = 1; //start
			var.last = 1;
			var.data.imag = 1; //pass to next block
			var.data.real = 1; //pass to next block
			data_in.write(var);
			dqpsk_modulator(data_in, data_out);
			not_ok += read_data(data_out, o_idx, in_golden, out_fp, 0);

			var.data.imag = 0; //send phase references
			var.data.real = 0; //send phase references
			data_in.write(var);
			dqpsk_modulator(data_in, data_out);
			not_ok += read_data(data_out, o_idx, in_golden, out_fp, 0);
    	}


		// Fill HW buffers
		for (int i=0; i < 1536; i++) {
			cplxui1stream var;
			var.dest = 0; //start
			var.last = (i==(1536-1)) ? 1 : 0;
			int idx0=0;
			int idx1=0;
			int in_re=0;
			int in_im=0;
			if(fscanf(in_fp,"%d %d %d %d",&idx0,&idx1,&in_re,&in_im) !=4){
				fprintf(stderr, "input scan failed on: %d %d\n", i_idx, i);
				return 1;
			}

			if(idx0!=i_idx || idx1 != i) {
				fprintf(stderr, "input order failure: %d %d != %d %d\n", i_idx, i, idx0, idx1);
				return 1;
			}

			//var.data.real = diff_mod_in_1[i_idx*1536+i].re > 0 ? UI1_PLUS07071 : UI1_MINUS07071;
			//var.data.imag = diff_mod_in_1[i_idx*1536+i].im > 0 ? UI1_PLUS07071 : UI1_MINUS07071;
			var.data.real = in_re > 0 ? UI1_PLUS07071 : UI1_MINUS07071;
			var.data.imag = in_im > 0 ? UI1_PLUS07071 : UI1_MINUS07071;
#ifdef DEBUG1
			inputs_saved[i].real = in_re > 0 ? UI1_PLUS07071 : UI1_MINUS07071;
			inputs_saved[i].imag = in_im > 0 ? UI1_PLUS07071 : UI1_MINUS07071;
#endif
			data_in.write(var);
		}
    	i_idx++;

		// Now run hardware
    	dqpsk_modulator(data_in, data_out);
#ifdef DEBUG1
		fprintf(stderr, "out[%d] size=%d (before read)\n", o_idx, data_out.size());
#endif
		//check hw/sw results:

#ifdef DEBUG1
		fprintf(stderr, "out[%d] size=%d (after read)\n", o_idx, data_out.size());
#endif
		//read once more if it's first sending
		if(o_idx == 0)
			o_idx++;
#ifdef DEBUG1
			fprintf(stderr, "out[%d] size=%d (before read head)\n", o_idx, data_out.size());
#endif
			not_ok += read_data(data_out, o_idx, in_golden, out_fp, 1);
#ifdef DEBUG1
		fprintf(stderr, "out[%d] size=%d (after read head)\n", o_idx, data_out.size());
#endif
    }

    fclose(in_fp);
    fclose(in_golden);
    fclose(out_fp);


    // Compare the results file with the golden results
    int retval = system("diff --brief -w output.dat output.golden.dat");
    if (retval != 0) {
    	printf("Test failed  !!!\n");
    	not_ok++;
    } else {
    	printf("Test passed !\n");
    }


	return not_ok;
}




/*
 * OUT REF: {-1.000000,0.000000}
 * mul out:(0.000000 + -1.000000i) * in:(-0.707107 + 0.707107i) = (0.707107 + 0.707107i)
 * mul out:(0.707107 + 0.707107i) * in:(-0.707107 + 0.707107i) = (-1.000001 + 0.000000i)
 *
 *
 * */








#if 0

















int main()
{



	return not_ok;

}
#endif
