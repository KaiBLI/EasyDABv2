
typedef struct {
  float re;
  float im;
} cplx_f;
// in 0x2035da0 len: 1536
#define DIFF_MOD_IN_SIZE_0 1536
extern const cplx_f diff_mod_in_0[DIFF_MOD_IN_SIZE_0];
// in 0x7f872dc78040 len: 115200
#define DIFF_MOD_IN_SIZE_1 115200
extern const cplx_f diff_mod_in_1[DIFF_MOD_IN_SIZE_1];
// out 0x7f872db93040 len: 116736
#define DIFF_MOD_OUT_SIZE 116736
extern const cplx_f diff_mod_out_0[DIFF_MOD_OUT_SIZE];
