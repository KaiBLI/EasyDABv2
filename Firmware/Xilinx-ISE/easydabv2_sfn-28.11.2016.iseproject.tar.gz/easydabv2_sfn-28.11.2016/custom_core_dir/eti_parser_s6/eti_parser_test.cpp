

#include <ap_int.h>
#include <ap_utils.h>
#include <hls_stream.h>

#define IS_CIF963


typedef struct {
	ap_uint<8> data;
	ap_uint<1>  last;
} u8stream;

void eti_parser(hls::stream<ap_uint<8> > &input, hls::stream<u8stream > &output, bool *out_aresetn, ap_uint<8> stc_buff[256]);

int main()
{
	int ret=0;

	/**************************************************************************************
	 * HW Implementation
	 **************************************************************************************/
    hls::stream<ap_uint<8> > data_in;
    hls::stream<u8stream> data_out;

    FILE *input = fopen("input.eti", "rb");
    FILE *golden = fopen("output2.eti", "rb");
    FILE *output = fopen("output.eti", "wb");

    if(!input || !golden || !output) {
    	fprintf(stderr, "can't open file\n");
    	exit(1);
    }

    //do_eti_parser(input, input_size, out2, output_size);

    uint8_t var;
    ap_uint<8> stc_buff[256];
  do {
    if (fread(&var, 1, 1, input) != 1){
    	fprintf(stderr, "can't read file\n");
    	break;
    }

    bool out_aresetn=true;
	data_in.write(var);
	eti_parser(data_in, data_out, &out_aresetn, stc_buff);

	int read_size = data_out.size();
	if(read_size > 0) {
	    uint16_t out_var;
		u8stream var2;
		var2=data_out.read();

		out_var = var2.data;
		if(var2.last) out_var |= 0x100;

	    if (fwrite(&out_var, 2, 1, output) != 1){
	    	fprintf(stderr, "can't write file\n");
	    	break;
	    }
	}
  } while (1);

	fclose(input);
	fclose(golden);
	fclose(output);

	return ret;
}

