#!/bin/bash

MAIN_CMD="wget --auth-no-challenge -O- -dq -t 1 http://admin:admin@192.168.2.4"


rm -f easydabv2_sfn-10.10.2016.bin

#last addr: 0x60000

echo "Turning off ETI socket..."
$MAIN_CMD/s_010000 > /dev/null 2>&1
ret=${PIPESTATUS[0]}
if [[ $ret -ne 0 && $ret -ne 3 ]];
then
  echo "Can't turn off ETI socket, exit code is $ret..."
  exit;
fi

sleep 0.2

for (( offset_c=0; offset_c<0x200000; offset_c+=4096 ))
do
   printf -v offset_hex '%06x' $offset_c

   sector_nalign=$((offset_c % 65536))
   if [[ $sector_nalign -eq 0 ]];
   then
      echo "Sector alignment"
   fi

   echo "Reading from $offset_c (0x$offset_hex)..."
   $MAIN_CMD/b_$offset_hex 2>/dev/null | head -c 4096 >> easydabv2_sfn-10.10.2016.bin
   ret=${PIPESTATUS[0]}
   if [[ $ret -ne 0 && $ret -ne 3 ]];
   then
      echo "Can't read data at 0x$offset_hex, exit code is $ret..."
      exit;
   fi
   sleep 0.2
done
