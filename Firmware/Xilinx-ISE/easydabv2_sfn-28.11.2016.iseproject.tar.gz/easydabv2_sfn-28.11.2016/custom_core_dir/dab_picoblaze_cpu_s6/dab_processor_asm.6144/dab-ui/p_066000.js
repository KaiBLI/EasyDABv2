var tiiPat=[240,232,216,184,120,228,212,180,116,204,172,108,156,92,60,226,210,178,114,202,170,106,154,90,58,198,166,102,150,86,54,142,78,46,30,225,209,177,113,201,169,105,153,89,57,197,165,101,149,85,53,141,77,45,29,195,163,99,147,83,51,139,75,43,27,135,71,39,23,15];

function getst_cb(data,next){
gEv("eti_s_act").enabled=true;
gEv("eti_s_act").value="Turn OFF ETI socket";
gEv("fe_action").enabled=true;

if((data[4] & 0x50) != 0){
gEv("fe_action").value="Turn ON RF-frontend";
gEv("fe_s").innerHTML="&#9711; Off"; gEv("fe_s").style.color="aaaaaa";
}else if (data[4] == 0x02){
gEv("fe_action").value = "Turn OFF RF-frontend";
gEv("fe_s").innerHTML="&#11044; RF-frontend active"; gEv("fe_s").style.color="00aa00";
}else{
gEv("fe_s").innerHTML="&#9711; Unknown "+dec2hex(data[4]); gEv("fe_s").style.color="ee0000";
}

if((data[9] == 0x02 || data[9] == 0x04) && data[11] == 0x17) {  gEv("conn_s").innerHTML="&#11044; Connected"; gEv("conn_s").style.color="00aa00"; }
else if(data[9] == 0x00 || data[9] == 0x01) {
gEv("eti_s_act").value="Turn ON ETI socket";
if(data[10] == 0x01) {
gEv("conn_s").innerHTML="&#11044; Admin Off"; gEv("conn_s").style.color="aaaaaa";
gEv("eti_s_act").enabled = true;
}else{
gEv("conn_s").innerHTML="&#11044; Flash Off"; gEv("conn_s").style.color="aaaaaa";
gEv("eti_s_act").enabled = false;
}}
else if(data[9] == 0x02 && data[11] == 0x14) {  gEv("conn_s").innerHTML="&#11044; Listening"; gEv("conn_s").style.color="aaaa00"; }
else if(data[9] == 0x04 && (data[11] == 0x13|data[11] == 0x00)) {  gEv("conn_s").innerHTML="&#11044; Connecting"; gEv("conn_s").style.color="aaaa00"; }
else {  gEv("conn_s").innerHTML="&#11044; unknown:"+dec2hex(data[9])+":"+dec2hex(data[10])+":"+dec2hex(data[11]); gEv("conn_s").style.color="ee0000"; }

gEv("progress_s").value = data[12];
gEv("fullness_s").innerHTML= Math.floor((data[12] * 100 / 255)) + " %" ;
gEv("fftovf_s").innerHTML="";
gEv("intovf_s").innerHTML="";
if(data[13] & 0x01){gEv("fftovf_s").innerHTML="&#11044; iFFT overflow!<br/>";gEv("fftovf_s").style.color="ee0000";}else
if(data[13] & 0x04){gEv("fftovf_s").innerHTML="&#9711; iFFT overflow happened<br/>";gEv("fftovf_s").style.color="aaaa00";}

if(data[13] & 0x02){gEv("intovf_s").innerHTML="&#11044; FIR clipping!<br/>";gEv("intovf_s").style.color="ee0000";}else
if(data[13] & 0x08){gEv("intovf_s").innerHTML="&#9711; FIR clipped<br/>";gEv("intovf_s").style.color="aaaa00";}

if(data[13] & 0x10){gEv("gps_s").innerHTML="&#11044; GPS time received<br/>";gEv("gps_s").style.color="00aa00";}else
{gEv("gps_s").innerHTML="&#9711; GPS time is not known yet<br/>";gEv("gps_s").style.color="aaaa00";}

if(data[13] & 0x20){gEv("gps1_s").innerHTML="&#11044; GPS reference is OK<br/>";gEv("gps1_s").style.color="00aa00";}else
{gEv("gps1_s").innerHTML="&#9711; GPS reference isn't ready<br/>"; gEv("gps1_s").style.color="aaaa00";}

if(data[13] & 0x40){gEv("state_s").innerHTML="&#11044; Broadcasting<br/>";gEv("state_s").style.color="00aa00";}else
{gEv("state_s").innerHTML="&#9711; Broadcast OFF<br/>";gEv("state_s").style.color="ee0000";}
if(data[13] & 0x80){gEv("sram_s").innerHTML="&#11044; SPI SRAM buffers detected<br/>";gEv("sram_s").style.color="00aa00";sram_detected=1;}

log("Status received","00aa00");
if(next){next();}
}

function showDC(par, viewer){gEv(viewer).innerHTML=Math.floor((par.value*100/(par.max/2)))+"% (abs:"+par.value+")";}

function getStatus(next){log("Getting status...","aaaa00");gEv("fe_action").enabled = false;gEv("eti_s_act").enabled = true;getBinary("s_000000",getst_cb,next);}

function switchConnection(id){
if(gEv("eti_s_act").value=="Turn ON ETI socket"){
if(c_mode=="server"){getBinary("s_010200", getst_cb);}else if(c_mode=="client"){getBinary("s_010400",getst_cb);}
}else{getBinary("s_010000",getst_cb);}}

function restartSent_cb(){log("Restarted", "ff4444");alert("Device Restarted!\n\nClear your ARP-cache if MAC/IP-address is changed.");}
function deviceRestart(){getBinary("r_000000", restartSent_cb);}
function switchFE(id){if(gEv("fe_action").value == "Turn OFF RF-frontend") {getBinary("s_025000", getst_cb);} else {getBinary("s_020000", getst_cb);}}
function applyDisplayEn(par) {gEv("ampl_apply").style.display = "block";showDC(par, 'da_s');chAf(par);}
function setDac_cb0(data,next){amplApply0();}
function setDac_cb(data,next){gEv("st_ampl2").style.display = "block";gEv("st_ampl2").innerHTML="Actual:"+data[2];}
function amplApply0(){getBinary("s_000e00", setDac_cb);}
function amplApply1(){if(gEv("cfg_ampl").value > 0) getBinary("s_000e"+dec2hex(gEv("cfg_ampl").value), setDac_cb0); else log("can't set amplitude to 0, turn on/off frontend!", "ee0000");}

var currentValue="client";
function handleClick(myRadio){
console.log('Old val:'+currentValue);
console.log('New val:'+myRadio.value);
currentValue = myRadio.value;
if(currentValue == "client"){
gEv("l_port_f").style.display="none";
gEv("r_ip_f").style.display="";
gEv("r_port_f").style.display="";
gEv("r_zmq_f").style.display="";
gEv("tcp_nodelay_f").style.display="";
}else if (currentValue == "server"){
gEv("l_port_f").style.display="";
gEv("r_port_f").style.display="none";
gEv("r_zmq_f").style.display="none";
gEv("r_ip_f").style.display="none";
gEv("tcp_nodelay_f").style.display="";
}else{
gEv("l_port_f").style.display="none";
gEv("r_ip_f").style.display="none";
gEv("r_port_f").style.display="none";
gEv("r_zmq_f").style.display="none";
gEv("tcp_nodelay_f").style.display="none";
}}

gEv("help_page").innerHTML=`<h2>Help</h2><hr/><h3>Networking</h3>This section is responsible for configuring network parameters, such as IP-address, netmask, gateway,etc. Also stream source settings must be setted here, like board's role: TCP-server or client, ports to listen or to connect and additional flags as basic ZeroMQ protocol handshake, that enables ZeroMQ communication with ODR-DabMUX software. Setting TCP no delayed ACKnowledgement is needed in low-performance networks, where packets may be lost.
<h3>RF-Frontend</h3>This section can configure output DAC parameters, like output signal's frequency and it's power. The power is setted as percentage value of output amplitude and output DAC current. If You need low-noise output, then don't increase amplitude and current hugher than 100%, because this will bring more noisy (but higher power) signal. Also this section allows to choose input source frequency of crystal oscillator or external generator.
<h3>Processing</h3>This section - is for additional processing flags and statuses. Here You can enable additinal hardware SPI SRAM buffer, based on 2 chips of 23LC1024, that allows to buffer more than 1 second of data. Also here You can enable Single Frequency Network (SFN) mode, if GPS receiver is installed. Additional UART and 1PPS pins must be connected to the board, from which high precision time will be received by the board. UART baud rate is 9600.
<h3>Authentication</h3>In this section this web-page access can be limited by your credenntials. Default - is admin:admin.
<h3>Actions</h3>Here You can make actual actions with the board. <b>After editing some parameters you must push [apply config] button to apply Your changes to the board.</b> Also You can re-read board's status by pushing [get status] and re-read internally saved config from the board by pushing [read config]. Button [set defaults] will set safe parameters to the board's config that can be applied later. You can enable or disable transmission on-the-fly by pressing [Turn On/Off RF frontend] without need to press apply button. Also You can disable/enable ETI-stream connection to the signal's source by pressing [Turn ON/OFF ETI socket] button.
<h3>Resetting the board</h3>If You forgot password or some settings are wrongly saved, You can reset board by connect wire jumper between first and last pins of X2 connector (pin 1 and pin 8) before power-up the board.`;
// 