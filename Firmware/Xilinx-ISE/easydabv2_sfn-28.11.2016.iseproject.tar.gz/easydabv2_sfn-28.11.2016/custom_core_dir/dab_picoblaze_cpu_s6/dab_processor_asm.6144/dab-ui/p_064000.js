
function setVal(id,val,noisy){
el = gEv(id);
if (typeof(el) != 'undefined' && el != null){
if(val != null && val == 0){
el.style.color = "red"
el.innerHTML = "Bad!"
gEv("apply_btn").disabled = true;
} else if(val != null && val == 1 && noisy) {
el.style.color = "green"
el.innerHTML = "Ok"
}}}

function chAf(id){
gEv("apply_btn").disabled = false;
fCh("cfg_ip", id);
fCh("cfg_mask", id);
fCh("cfg_gw", id);
fCh("cfg_mac", id);
fCh("cfg_l_port", id);
fCh("cfg_r_ip", id);
fCh("cfg_r_port", id);
fCh("cfg_r_zmq", id);
fCh("cfg_login", id);
fCh("cfg_password", id);
fCh("cfg_ampl", id);
fCh("cfg_dc", id);
fCh("cfg_srcfreq", id);
fCh("cfg_pllcp", id);
fCh("cfg_frequency", id);
fCh("cfg_tcp_nodelay", id);
fCh("cfg_spibuf", id);
fCh("cfg_sfn", id);
fCh("cfg_gpsok", id);
fCh("cfg_gpsdo", id);
fCh("cfg_pps", id);
fCh("cfg_gpsd1", id);
fCh("cfg_gpsd2", id);
fCh("cfg_tii", id);
fCh("cfg_tii_comb", id);
fCh("cfg_tii_pat", id);
}

function fCh(id_name, caller_id)
{
id=gEv(id_name);
console.log("element["+id.id+"] changed: "+id.value);
id_p = id.id.substring(3)
var ok=0;

switch(id_p) {
case "_ip":
case "_mask":
case "_gw":
case "_r_ip":
 if (/^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/.test(id.value)) { ok=1; }
 break;
case "_l_port":
 if(!isNaN(id.value) && id.value > 0 && id.value < 65536 && id.value != 80) { ok=1 }
 break;
case "_r_port":
 if(!isNaN(id.value) && id.value > 0 && id.value < 65536) { ok=1 }
 break;
case "_mac":
 if (/^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$/.test(id.value)) { ok=1; }
 if(ok && !(/^(0{2})/.test(id.value))) { ok=0; }
 break;
case "_login":
case "_password":
 if(id.value.length > 0 && id.value.length < 30) { ok=1 }
 break;
case "_ampl":
case "_dc":
 if(!isNaN(id.value) && id.value >= 0 && id.value <= 255) { ok=1 }
 break;
case "_srcfreq":
 if(!isNaN(id.selectedIndex) && id.selectedIndex >= 0 && id.selectedIndex <= 3) { ok=1 }
 if(id.selectedIndex==0) gEv("srcf_s").innerHTML="FPll: 12.288x50=614.4MHz<br>SR: 614.4/100=6.144MHz";
 if(id.selectedIndex==1) gEv("srcf_s").innerHTML="FPll: 19.2x32=614.4MHz<br>SR: 614.4/100=6.144MHz";
 if(id.selectedIndex==2) gEv("srcf_s").innerHTML="FPll: 24.576x25=614.4MHz<br>SR: 614.4/100=6.144MHz";
 if(id.selectedIndex==3) gEv("srcf_s").innerHTML="FPll: 30.72x20=614.4MHz<br>SR: 614.4/100=6.144MHz";
 break;
case "_gpsd1":
 if(!isNaN(id.value) && id.value >= 0 && (id.value <= 15999 || !gEv("cfg_sfn").checked)) { ok=1 }
 break;
case "_gpsd2":
 if(!isNaN(id.value) && id.value >= 0 && (id.value < 1000 || !gEv("cfg_sfn").checked)) { ok=1 }
 break;
case "_spibuf":
 gEv("cfg_sfn").disabled = !id.checked;
 gEv("cfg_gpsd2").disabled = gEv("cfg_gpsd1").disabled = !(id.checked & gEv("cfg_sfn").checked);
 gEv("cfg_gpsok").disabled = !(id.checked & gEv("cfg_sfn").checked);
 ok=1;
 break;
case "_gpsdo":
 gEv("cfg_pps").disabled = id.checked | gEv("cfg_sfn").checked;
case "_sfn":
case "_gpsok":
case "_gpsbaud":
case "_tcp_nodelay":
case "_r_zmq":
case "_pllcp":
case "_pps":
case "_tii":
case "_tii_pat":
case "_tii_comb":
 ok=1;
 break;
case "_frequency":
 if(!isNaN(id.value) && id.value > 0 && id.value <= 307200000 ) { ok=1 }
 break;
default:
 console.log("element["+id.id+"] changed: "+id.value+" == UNKNOWN!!");
 break;
}
setVal("st"+id_p, ok, caller_id == id);
}


function getConfig0() {
var config = default_config;
console.log("default_config:"+default_config);
var data = getBinary("b_070000");
console.log("data:"+data);
}

function resetDefaults(){
is_bad=false;
gEv("apply_btn").disabled = is_bad;
if(sram_detected == 1) uint8_default[54] |= 0x80;
console.log(Array.apply([], uint8_default).join(","));
getConfig_cb(uint8_default);
log("resetted", "888800");
}

function setConfig(){
gEv("apply_btn").disabled = true;
var d_o = setUIConfig(uint8_default);
getBinary("s_010000", setConfig0_cb, d_o);
}

function setConfig0_cb(data_recv, d_o){
log('Erasing partition...', "880000");
getBinary("e_070000", setConfig_erase_callback, d_o);
}

function setConfig_erase_callback(data_recv, d_o){
console.log(Array.apply([], d_o).join(","));
console.log('Erased\nUpl.new cfg');
log('Uploading new config...', "880000");
sendBinary("_070000", d_o, setConfig_done_callback);
}

function setConfig_done_callback(data_recv, callback_arg){
console.log("Uploaded!");
log("Uploaded!", "880000");
if (confirm('New configuration uploaded to memory, would u like to restart device to apply it immediatly?')){deviceRestart();}
gEv("apply_btn").disabled = false;
}

function getConfig_cb(data){
console.log("getConfig_cb():" + data.length);
gEv("cfg_gw").value = data[1]+"."+data[2]+"."+data[3]+"."+data[4];
gEv("cfg_mask").value = data[5]+"."+data[6]+"."+data[7]+"."+data[8];
gEv("cfg_mac").value = dec2hex(data[9])+":"+dec2hex(data[10])+":"+dec2hex(data[11])+":"+dec2hex(data[12])+":"+dec2hex(data[13])+":"+dec2hex(data[14]);
gEv("cfg_ip").value = data[15]+"."+data[16]+"."+data[17]+"."+data[18];
gEv("cfg_l_port").value = (data[20]*256 + data[21]).toString();
gEv("cfg_r_ip").value = data[22]+"."+data[23]+"."+data[24]+"."+data[25];
gEv("cfg_r_port").value = (data[26]*256 + data[27]).toString();
gEv("cfg_r_zmq").checked = (data[38] == 0x01);

if((data[28] & 0xDF) == 0x02) { c_mode="server"; }
else if((data[28] & 0xDF) == 0x04) { c_mode="client"; }
else if((data[28] & 0xDF) == 0x10) { c_mode="off"; }
else { alert("Bad conn mode:"+dec2hex(data[28])); c_mode="off"; }
gEv("cfg_tcp_nodelay").checked = ((data[19] & 0x20) == 0x20);

console.log(c_mode+" mode");
var val = gEv("cfg_mode_"+c_mode);
val.checked=true;
handleClick(val)

gEv("cfg_ampl").value = data[31];
showDC(gEv("cfg_ampl"), 'da_s');
gEv("cfg_dc").value = data[48];
showDC(gEv("cfg_dc"), 'dc_s');
if((data[49] & 0x07) == 0x02 && data[53] == 0x64 && data[30] == 0x64) {
gEv("cfg_srcfreq").selectedIndex = 0;
src_freq=12288;
} else if((data[49] & 0x07) == 0x02 && data[53] == 0x40 && data[30] == 0x64) {
gEv("cfg_srcfreq").selectedIndex = 1;
src_freq=19200;
} else if((data[49] & 0x07) == 0x02 && data[53] == 0x32 && data[30] == 0x64) {
gEv("cfg_srcfreq").selectedIndex = 2;
src_freq=24576;
} else if((data[49] & 0x07) == 0x02 && data[53] == 0x28 && data[30] == 0x64) {
gEv("cfg_srcfreq").selectedIndex = 3;
src_freq=30720;
} else {
console.log("BAD FREQ:"+(data[49] & 0x07)+", "+data[53]+", "+data[30]);
}
gEv("cfg_pllcp").selectedIndex = (data[51] >> 3) & 0x07;
gEv("cfg_frequency").value = Math.round((((data[34]*256 + data[35]) * 256 + data[36]) * 256 + data[37]) * (src_freq * 1000 * data[53]/2) / 4294967296);

gEv("cfg_spibuf").checked = (data[54] & 0x80) ? true : false;
gEv("cfg_sfn").checked = (data[54] & 0x40) ? true : false;
gEv("cfg_gpsdo").checked = (data[54] & 0x10) ? 1 : 0;
gEv("cfg_gpsok").checked = (data[54] & 0x08) ? true : false;
gEv("cfg_gpsd1").value = (((data[54] & 0x07) << 1) + (data[55] >> 7))*1000 + (((data[55] & 0x7F) << 3) + (data[56] >> 5));
gEv("cfg_gpsd2").value = ( ((data[56] & 0x1F) << 8) + data[57]) * (1000/6144);
gEv("cfg_pps").value = (((data[56] & 0xFF) << 8) + data[57]) - 32768;
gEv("cfg_pps").disabled = gEv("cfg_gpsdo").checked | gEv("cfg_sfn").checked;
showPPS(gEv("cfg_pps"), 'pps_s');

gEv("cfg_tii").checked = (data[59] > 0) ? 1 : 0;
gEv("cfg_tii_comb").value = (data[58] < 24) ? data[58] : 0;
var v = tiiPat.indexOf(data[59]); if(v < 0 || v > 69) v=0;
gEv("cfg_tii_pat").value = v;

if(data[0x40] != 0xFF) {
console.log('b64:'+arr2str(data, 0x40));
authstr=b64dec(arr2str(data, 0x40));
console.log('authstr:'+authstr);
loginpassword=authstr.split(":",2);
gEv("cfg_login").value = loginpassword[0];
gEv("cfg_password").value = loginpassword[1];
} else { gEv("cfg_login").value = gEv("cfg_password").value = "";}
log("received", "008800");
chAf();
}

function getConfig(){getBinary("b_070000", getConfig_cb);}
function showPPS(par, viewer){gEv(viewer).innerHTML=par.value/10+" Hz";}
// 