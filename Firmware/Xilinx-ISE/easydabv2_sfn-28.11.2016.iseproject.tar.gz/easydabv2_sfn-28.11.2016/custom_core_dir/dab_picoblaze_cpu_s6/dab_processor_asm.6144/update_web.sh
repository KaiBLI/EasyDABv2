#!/bin/bash

MAIN_CMD="wget --auth-no-challenge -O- -dq -t 1 http://admin:admin@192.168.2.4"

#MAIN_CMD="wget --auth-no-challenge -O- -dq -t 1 http://admin:admin@192.168.9.1"
#MAIN_CMD="wget --auth-no-challenge -O- -dq -t 1 http://admin:admin@192.168.1.2"
#MAIN_CMD="wget --auth-no-challenge -O- -dq -t 1 http://admin:admin@192.168.9.110"

WEB_DIR="dab-ui"
BIT_FILE="easydabv2_6144.bit"
BACKUP_BIT_FILE="easydabv2_backup.bit"

###################################################################################
# Functions
###################################################################################
FW_WRITE_OFFSET=0
FW_READ_OFFSET=0
FW_BIT_FILE=""


function eti_off {

  echo "Turning off ETI socket..."
  ETIOFF_RET=`$MAIN_CMD/s_010000 2>/dev/null`
  ret=${PIPESTATUS[0]}
  if [[ $ret -ne 0 && $ret -ne 3 ]];
  then

    echo "Can't turn off ETI socket, exit code is $ret..."

    if [[ $ret -eq 4 ]];
    then
      echo "It seems like board turned off or used another IP-address."
      echo "If You are not sure which IP-address setted on the board, it can be resetted to defaults."
      echo "More info - on board's webpage."
    else
      echo "There is some error connecting to the board! Please try once more or check parameters!"
    fi

    exit;
  else
      ETIOFF_RET2=`echo $ETIOFF_RET | head -c 1 | xxd -p`
      if [[ "$ETIOFF_RET2" = "ff" ]];
      then
        echo "Uploading 200 OK at first..."
        sleep 0.25
        cat ./$WEB_DIR/headers_200_bin > p_06FF00
        $MAIN_CMD/_06FF00 --post-file=p_06FF00 > /dev/null 2>&1
        rm -f p_06FF00
      fi
  fi
  sleep 1
}


function update_fw {

  if [[ $FW_WRITE_OFFSET -eq 0 ]];
  then
    MD5_OF_HEADER=`$MAIN_CMD/b_000000 2>/dev/null | head -c 128 | md5sum -b | awk '{ print $1 }'`
    sleep 0.25
    if [[ "$MD5_OF_HEADER" = "a81c84f295de22e73709bc0b720a98f0" ]];
    then
      echo "Backup firmware is already presented..."
      return
    fi
    echo "Backup firmware will be uploaded just once, this will take additional 8 minutes..."
  else
    echo "Uploading main firmware..."
  fi

  FILESIZE=$(stat -c%s $FW_BIT_FILE)
  echo "FILE=\"$FW_BIT_FILE\" FILESIZE=$FILESIZE, WRITE_OFFSET=$FW_WRITE_OFFSET"

  for (( offset_c=0; offset_c < $((FILESIZE - FW_READ_OFFSET)); offset_c+=4096 ))
  do
   printf -v offset_hex '%06x'  $((offset_c + FW_WRITE_OFFSET))

   sector_nalign=$((offset_c % 65536))
   if [[ $sector_nalign -eq 0 ]];
   then
      sector_left=$((offset_c / 65536 + 1))
      echo "Sector erase $sector_left of 6 ..."
      $MAIN_CMD/e_$offset_hex 2>/dev/null
      ret=${PIPESTATUS[0]}
      if [[ $ret -ne 0 && $ret -ne 3 ]];
      then
         echo "Can't erase data at 0x$offset_hex, exit code is $ret..."
         #exit;
      fi
      sleep 0.5
   fi

      dd if=$FW_BIT_FILE of=temp_$offset_hex skip=$((offset_c + FW_READ_OFFSET)) bs=1 count=4096 2>/dev/null

     echo "Writing 0x$offset_hex..."
     $MAIN_CMD/_$offset_hex --post-file=temp_$offset_hex 2>/dev/null
     ret=${PIPESTATUS[0]}
     if [[ $ret -ne 0 && $ret -ne 3 ]];
     then
        echo "Can't write data at 0x$offset_hex, exit code is $ret..."
        #exit;
     fi
     rm -f temp_$offset_hex
     sleep 0.25
  done


   if [[ $FW_WRITE_OFFSET -eq 0 ]];
   then
    echo "Set Backup webpages..."
    cat ./$WEB_DIR/headers_200_html > p_05F800
    cat ./$WEB_DIR/p_05F800_eFW.html >> p_05F800
    $MAIN_CMD/_05F800 --post-file=p_05F800 > /dev/null 2>&1
    rm -f p_05F800
    sleep 0.25
    echo "Backup firmware has been uploaded..."
  else
    echo "Main firmware has been uploaded..."
  fi
}




function update_web {

    echo "Updatting WEB-interface..."
    #erase
    echo "Erasing 0x060000..."
    $MAIN_CMD/e_060000 > /dev/null 2>&1
    sleep 0.5

    echo "Set 200 OK..."
    cat ./$WEB_DIR/headers_200_bin > p_06FF00
    $MAIN_CMD/_06FF00 --post-file=p_06FF00 > /dev/null 2>&1
    sleep 0.5

    #pages
    echo "Set WebPage..."
    cat ./$WEB_DIR/headers_200_html > p_060000
    cat ./$WEB_DIR/p_060000.html | sed 's/\$VERSION_STR\$/'${PWD##*/}'/g' >> p_060000

    $MAIN_CMD/_060000 --post-file=p_060000 > /dev/null 2>&1
    sleep 0.5
    #js

    echo "Set JavaScripts..."
    cat ./$WEB_DIR/headers_200_js > p_062000
    cat ./$WEB_DIR/p_062000.js >> p_062000

    cat ./$WEB_DIR/headers_200_js > p_064000
    cat ./$WEB_DIR/p_064000.js >> p_064000

    cat ./$WEB_DIR/headers_200_js > p_066000
    cat ./$WEB_DIR/p_066000.js >> p_066000


    $MAIN_CMD/_062000 --post-file=p_062000 > /dev/null 2>&1
    sleep 0.5
    $MAIN_CMD/_064000 --post-file=p_064000 > /dev/null 2>&1
    sleep 0.5
    $MAIN_CMD/_066000 --post-file=p_066000 > /dev/null 2>&1
    sleep 0.5

    #error pages
    echo "Set Helper Pages..."
    cat ./$WEB_DIR/headers_401 > p_06FE00
    cat ./$WEB_DIR/p_06FE00_e401.html >> p_06FE00
    $MAIN_CMD/_06FE00 --post-file=p_06FE00 > /dev/null 2>&1
    sleep 0.5

    rm -f p_060000
    rm -f p_062000
    rm -f p_064000
    rm -f p_066000
    rm -f p_06FE00
    rm -f p_06FF00
    echo "Web-interface update done!"
}






echo "Run this update only on stable wired network (no WiFi please)."
echo "Updating throught wired switch or router is also acceptable. It can take up to 16 minutes!!!!"
read -r -p "Are you sure? [y/N] " response
case $response in
    [yY][eE][sS]|[yY])
        eti_off

        FW_WRITE_OFFSET=0
        FW_READ_OFFSET=99
        FW_BIT_FILE=$BACKUP_BIT_FILE
        update_fw

        FW_WRITE_OFFSET=524288
        FW_READ_OFFSET=116
        FW_BIT_FILE=$BIT_FILE
#        update_fw

        update_web
        echo "Update has been finished. Now You need to hard-reboot (turn off/on power of the board) to use new firmware!"
        exit;
        ;;
    *)
        exit;
        ;;
esac


