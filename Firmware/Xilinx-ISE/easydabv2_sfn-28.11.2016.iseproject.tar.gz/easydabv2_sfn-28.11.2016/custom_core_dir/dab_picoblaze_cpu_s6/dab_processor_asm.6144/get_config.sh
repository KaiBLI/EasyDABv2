#!/bin/sh

MAIN_CMD="wget --auth-no-challenge -O- -dq -t 1 http://admin:admin@192.168.2.4"
#MAIN_CMD="wget --auth-no-challenge -O- -dq -t 1 http://admin:admin@192.168.1.2"

#$MAIN_CMD/b_070000 | head -c 128 > b_070000

$MAIN_CMD/b_070000 | head -c 256 | tee b_070000 | hd

sleep 1
#$MAIN_CMD/_070000 --post-file=./dab-ui/b_070000
