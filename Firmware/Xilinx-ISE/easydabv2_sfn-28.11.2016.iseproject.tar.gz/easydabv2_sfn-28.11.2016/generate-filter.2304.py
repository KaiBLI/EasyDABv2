#!/usr/bin/env python
# This tool uses gnuradio to generate FIR filter taps
# that can be used for the FIRFilter function in
# CRC DabMod
#
# Usage:
#  1) adapt the filter settings below
#  2) Call this script and redirect the output of this script into a file
#
# Requires:
#  A recent gnuradio version (3.7)
#
#
# The MIT License (MIT)
#
# Copyright (c) 2013 Matthias P. Braendli
# http://mpb.li
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from __future__ import print_function
import gnuradio
from gnuradio import digital
import sys
# From documentation at
#  http://gnuradio.org/doc/doxygen/classgr_1_1filter_1_1firdes.html

# use "window method" to design a low-pass FIR filter
#
# gain: overall gain of filter (typically 1.0)
# sampling_freq: sampling freq (Hz)
# cutoff_freq: center of transition band (Hz)
# transition_width: width of transition band (Hz).
#    The normalized width of the transition band is what sets the number of taps required. Narrow --> more taps
# window_type: What kind of window to use. Determines maximum attenuation and passband ripple.
# beta: parameter for Kaiser window

#gain = 1
#gain = 255
#gain = 18


#experimentally found: -22262...21705

# for low dynamic range:
# IS OK!!!! ???
#gain = 17

# IS OK!!!! ???
#gain = 16

# IS OVERFLOW!!!
#gain = 18

# IS OVERFLOW!!!
#gain = 23

##almost no overflow
#gain = 22
gain = 21
#gain = 20


# for high dynamic range:
#gain = 20

#no overflow
#gain = 19
#gain = 4



#gain = 5
#gain = 6
#gain=5 # no delay
#gain = 5 # no overflows!!!
gain = 21 # no ovf in 5 min, ovf in 10 min
#gain = 7 # ovf in 8 min
#gain = 8

#sampling_freq = 192000
sampling_freq = 256e6
#sampling_freq = 6.144e6
#sampling_freq = 8.192e6
#sampling_freq = 2.048e6
#cutoff = 810e3
#transition_width = 250e3


#cutoff = 820e3
#transition_width = 190e3

##(1536/2 + 180/2) => 858
## (858 - (180 / 2)) * 2 = 1536


#58.65 - is needed

cutoff = 1e6
transition_width = 500e3


#(1536/2 + 70/2)
# (858 - (180 / 2)) * 2 = 1536
#cutoff = 803e3
#transition_width = 70e3


#cutoff = 810e3
#cutoff = 810e3
#transition_width = 165e3

# Generate filter taps and print them out
taps = digital.filter.firdes_low_pass(gain, sampling_freq, cutoff, transition_width) # hamming window

print(len(taps))
for t in taps:
    print(t, end=", ")
    #sys.stdout.write(t)
    #sys.stdout.write(', ')

