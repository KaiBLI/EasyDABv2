This directory contains Windows binaries of GNU m4. These are unmodified versions as distributed by the GnuWin32 project.

GNU m4 is available from the following locations:

http://gnuwin32.sourceforge.net/packages/m4.htm
http://www.gnu.org/software/m4/m4.html
http://ftp.gnu.org/gnu/m4/

The Regex library is part of GNU libc and is available from here:

http://gnuwin32.sourceforge.net/packages/regex.htm
http://directory.fsf.org/wiki/Regex
http://ftp.gnu.org/gnu/glibc/