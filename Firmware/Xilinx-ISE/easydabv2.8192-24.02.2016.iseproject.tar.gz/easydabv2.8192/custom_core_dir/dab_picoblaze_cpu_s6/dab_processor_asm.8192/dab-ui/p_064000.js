
function setVal(id, val, noisy) {
 if(val != null && val == 0) {
  gElVal(id).style.color = "red"
  gElVal(id).innerHTML = "Bad!"
  gElVal("apply_btn").disabled = true;
 } else if(val != null && val == 1 && noisy) {
  gElVal(id).style.color = "green"
  gElVal(id).innerHTML = "Ok"
 }
}

function checkAllFiels(id)
{
 gElVal("apply_btn").disabled = false;
 fieldChanged("cfg_ip", id);
 fieldChanged("cfg_mask", id);
 fieldChanged("cfg_gw", id);
 fieldChanged("cfg_mac", id);
 fieldChanged("cfg_local_port", id);
 fieldChanged("cfg_remote_ip", id);
 fieldChanged("cfg_remote_port", id);
 fieldChanged("cfg_login", id);
 fieldChanged("cfg_password", id);
 fieldChanged("cfg_amplitude", id);
 fieldChanged("cfg_frequency", id);
 fieldChanged("cfg_tcp_nodelay", id);
}

function fieldChanged(id_name, caller_id)
{
 id=gElVal(id_name);
 console.log("element["+id.id+"] changed: "+id.value);
 id_p = id.id.substring(3)
 var ok=0;

 switch(id_p) {
   case "_ip":
   case "_mask":
   case "_gw":
   case "_remote_ip":
  if (/^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/.test(id.value)) { ok=1; }
  break;
   case "_local_port":
  if(!isNaN(id.value) && id.value > 0 && id.value < 65536 && id.value != 80) { ok=1 }
  break;
   case "_remote_port":
  if(!isNaN(id.value) && id.value > 0 && id.value < 65536) { ok=1 }
  break;
   case "_mac":
  if (/^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$/.test(id.value)) { ok=1; }
  if(ok && !(/^(0{2})/.test(id.value))) { ok=0; }
  break;
   case "_login":
   case "_password":
  if(id.value.length > 0 && id.value.length < 30) { ok=1 }
  break;
   case "_amplitude":
  if(!isNaN(id.value) && id.value > 0 && id.value <= 2.0) { ok=1 }
  break;
   case "_tcp_nodelay":
//  if(!isNaN(id.value)) { ok=1 }
   ok=1;
  break;
   case "_frequency":
  if(!isNaN(id.value) && id.value > 0 && id.value <= 516096000) { ok=1 }
  break;
   default:
  console.log("element["+id.id+"] changed: "+id.value+" == UNKNOWN!!");
  break;
 }


 setVal("status"+id_p, ok, caller_id == id);
}


function getConfig0() {
// var str = gElVal("message").value;
// var status = gElVal("status");
 var config = default_config;

 console.log("default_config.length:" + default_config.length);
 console.log("default_config.BYTES_PER_ELEMENT:"+default_config.BYTES_PER_ELEMENT);
 console.log("default_config:"+default_config);

 //status.innerHTML = "Bad Message";
// status.innerHTML = str;
// if(isEmpty(str)) status.innerHTML = "empty";

 var data = getBinary("b_070000");
 console.log("data.length:" + default_config.length);
 console.log("data.BYTES_PER_ELEMENT:"+default_config.BYTES_PER_ELEMENT);
 console.log("data:"+data);
}

var currentValue = "client";
function handleClick(myRadio) {
 console.log('Old value: ' + currentValue);
 console.log('New value: ' + myRadio.value);
 currentValue = myRadio.value;
 if (currentValue == "client") {
  gElVal("local_port_field").style.display = "none";
  gElVal("remote_ip_field").style.display = "";
  gElVal("remote_port_field").style.display = "";
  gElVal("tcp_nodelay_field").style.display = "";
 } else if (currentValue == "server") {
  gElVal("local_port_field").style.display = "";
  gElVal("remote_port_field").style.display = "none";
  gElVal("remote_ip_field").style.display = "none";
  gElVal("tcp_nodelay_field").style.display = "";
 } else {
  gElVal("local_port_field").style.display = "none";
  gElVal("remote_ip_field").style.display = "none";
  gElVal("remote_port_field").style.display = "none";
  gElVal("tcp_nodelay_field").style.display = "none";
 }
}

function restartSent_cb()
{
 log("Restarted", "ff4444");
 alert("Device Restarted!\n\nClear your ARP-cache if you changed MAC/IP-address.");
}

function deviceRestart() { getBinary("r_000000", restartSent_cb); }

function resetDefaults()
{
 is_bad=false;
 gElVal("apply_btn").disabled = is_bad;
 console.log('ResetDeafults()');
 console.log(Array.apply([], uint8_default).join(","));
 getConfig_cb(uint8_default);
 log("resetted", "888800");
}

//var global_arr;
function setConfig()
{
 gElVal("apply_btn").disabled = true;
 var d_o = setUIConfig(uint8_default);

 //array is ready, now erase partition:
 console.log('Erasing partition...');
 log('Erasing partition...', "880000");
 getBinary("e_070000", setConfig_erase_callback, d_o);


// global_arr = d_o;
}


function setConfig_erase_callback(data_recv, d_o)
{

 console.log(Array.apply([], d_o).join(","));
 console.log('Erased\nUploading new config...');
 log('Uploading new config...', "880000");
 sendBinary("_070000", d_o, setConfig_done_callback);
}

function setConfig_done_callback(data_recv, callback_arg)
{
 console.log("Uploaded!");
 log("Uploaded!", "880000");
 if (confirm('New configuration uploaded to memory, would u like to restart device to apply it immediatly?')) {
  deviceRestart();
 }
 gElVal("apply_btn").disabled = false;
}

function getConfig_cb(data)
{
 console.log("getConfig_cb():" + data.length);
 gElVal("cfg_gw").value = data[1]+"."+data[2]+"."+data[3]+"."+data[4];
 gElVal("cfg_mask").value = data[5]+"."+data[6]+"."+data[7]+"."+data[8];
 gElVal("cfg_mac").value = dec2hex(data[9])+":"+dec2hex(data[10])+":"+dec2hex(data[11])+":"+dec2hex(data[12])+":"+dec2hex(data[13])+":"+dec2hex(data[14]);
 gElVal("cfg_ip").value = data[15]+"."+data[16]+"."+data[17]+"."+data[18];
 //data[19] = MR MR_TCP (always)
 gElVal("cfg_local_port").value = (data[20]*256 + data[21]).toString();
 gElVal("cfg_remote_ip").value = data[22]+"."+data[23]+"."+data[24]+"."+data[25];
 gElVal("cfg_remote_port").value = (data[26]*256 + data[27]).toString();
 //data[28] = CR:
 //0x02 OPEN
 //0x04 CONNECT
 //0x10 CLOSE
 if((data[28] & 0xDF) == 0x02) { c_mode="server"; }
 else if((data[28] & 0xDF) == 0x04) { c_mode="client"; }
 else if((data[28] & 0xDF) == 0x10) { c_mode="off"; }
 else { alert("Bad connection mode:"+dec2hex(data[28])); c_mode="off"; }
 gElVal("cfg_tcp_nodelay").checked = ((data[19] & 0x20) != 0x20);

 console.log(c_mode+" mode");
 var val = gElVal("cfg_mode_"+c_mode);
 val.checked=true;
 handleClick(val)

 //data[29] = CCI rate&others
 gElVal("cfg_amplitude").value = (2.0 / 256 * data[31]).toFixed(3);
 //data[31], data[32] = phase
 // X = 1615006720 / (2^32 / (24576000 * 24))
 gElVal("cfg_frequency").value = Math.round((((data[34]*256 + data[35]) * 256 + data[36]) * 256 + data[37]) * (24576000 * 24) / 4294967296);

 if(data[0x40] != 0xFF) {
  console.log('b64:'+arr2str(data, 0x40));
  authstr=b64dec(arr2str(data, 0x40));
  console.log('authstr:'+authstr);
  loginpassword=authstr.split(":",2);
  gElVal("cfg_login").value = loginpassword[0];
  gElVal("cfg_password").value = loginpassword[1];
 } else {
  gElVal("cfg_login").value = "";
  gElVal("cfg_password").value = "";
 }

 log("received", "008800");
 checkAllFiels();
}

function getConfig()
{
 getBinary("b_070000", getConfig_cb);
// getConfig_cb(global_arr);
}
// 