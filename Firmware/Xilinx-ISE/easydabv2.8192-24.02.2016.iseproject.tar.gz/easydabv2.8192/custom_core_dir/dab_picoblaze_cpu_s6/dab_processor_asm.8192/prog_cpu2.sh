#!/bin/bash -e
#make -C ../../../java distclean all || exit
#make distclean all || exit
#make || exit
#java -cp MemFifo.jar MemFifo $@

#./kcpsm6.exe m25p16_spi_uart_bridge.psm

rm -f *.fmt *.gen.psm || true

#python ../opbasm/opbasm.py -6 -m 2048 --m4 -d -r -x -t ROM_form.vhd m25p16_spi_uart_bridge.psm
python ../opbasm/opbasm.py -6 -s 256 -m 1024 --m4 -d -r -x -t ROM_form.vhd m25p16_spi_uart_bridge.psm

rm -f *.fmt *.gen.psm || true

#source /opt/Xilinx/14.7/ISE_DS/settings64.sh
#../JTAG_Loader/JTAG_Loader_RH_64 -l m25p16_spi_uart_bridge.hex
