#!/bin/bash

MAIN_CMD="wget --auth-no-challenge -O- -dq -t 1 http://admin:admin@192.168.2.4"

WEB_DIR="dab-ui"
BIT_FILE="../../../easydabv2_8192.bit"


function eti_off {

  echo "Turning off ETI socket..."
  $MAIN_CMD/s_010000 > /dev/null 2>&1
  ret=${PIPESTATUS[0]}
  if [[ $ret -ne 0 && $ret -ne 3 ]];
  then
    echo "Can't turn off ETI socket, exit code is $ret..."
    exit;
  fi
  sleep 1
}


function update_fw {


FW_FILESIZE=$(stat -c%s $BIT_FILE)
echo "FW_FILESIZE=$FW_FILESIZE"

#last addr: 0x60000

  for (( offset_c=0; offset_c < $((FW_FILESIZE - 113)); offset_c+=4096 ))
  do
   printf -v offset_hex '%06x' $offset_c

   sector_nalign=$((offset_c % 65536))
   if [[ $sector_nalign -eq 0 ]];
   then
      sector_left=$((offset_c / 65536 + 1))
      echo "Sector erase $sector_left of 6 ..."
      $MAIN_CMD/e_$offset_hex 2>/dev/null
      ret=${PIPESTATUS[0]}
      if [[ $ret -ne 0 && $ret -ne 3 ]];
      then
         echo "Can't erase data at 0x$offset_hex, exit code is $ret..."
         #exit;
      fi
   fi

   dd if=$BIT_FILE of=temp_$offset_hex skip=$((offset_c + 113)) bs=1 count=4096 2>/dev/null

   echo "Writing 0x$offset_hex..."
   $MAIN_CMD/_$offset_hex --post-file=temp_$offset_hex 2>/dev/null
   ret=${PIPESTATUS[0]}
   if [[ $ret -ne 0 && $ret -ne 3 ]];
   then
      echo "Can't read data at 0x$offset_hex, exit code is $ret..."
      #exit;
   fi
   rm -f temp_$offset_hex
   sleep 0.2
  done
}




function update_web {

    echo "Updatting WEB-interface..."
    #erase
    echo "Erasing 0x060000..."
    $MAIN_CMD/e_060000 > /dev/null 2>&1
    sleep 0.5

    echo "Set 200 OK..."
    cat ./$WEB_DIR/headers_200_bin > p_06FF00
    $MAIN_CMD/_06FF00 --post-file=p_06FF00 > /dev/null 2>&1
    sleep 0.5

    #pages
    echo "Set WebPage..."
    cat ./$WEB_DIR/headers_200_html > p_060000
    cat ./$WEB_DIR/p_060000.html >> p_060000

    $MAIN_CMD/_060000 --post-file=p_060000 > /dev/null 2>&1
    sleep 0.5
    #js

    echo "Set JavaScripts..."
    cat ./$WEB_DIR/headers_200_js > p_062000
    cat ./$WEB_DIR/p_062000.js >> p_062000

    cat ./$WEB_DIR/headers_200_js > p_064000
    cat ./$WEB_DIR/p_064000.js >> p_064000

    cat ./$WEB_DIR/headers_200_js > p_066000
    cat ./$WEB_DIR/p_066000.js >> p_066000


    $MAIN_CMD/_062000 --post-file=p_062000 > /dev/null 2>&1
    sleep 0.5
    $MAIN_CMD/_064000 --post-file=p_064000 > /dev/null 2>&1
    sleep 0.5
    $MAIN_CMD/_066000 --post-file=p_066000 > /dev/null 2>&1
    sleep 0.5

    #error pages
    echo "Set Helper Pages..."
    cat ./$WEB_DIR/headers_401 > p_06FE00
    cat ./$WEB_DIR/p_06FE00_e401.html >> p_06FE00

    $MAIN_CMD/_06FE00 --post-file=p_06FE00 > /dev/null 2>&1
    sleep 0.5


    rm -f p_060000
    rm -f p_062000
    rm -f p_064000
    rm -f p_066000
    rm -f p_06FE00
    rm -f p_06FF00
    echo "Web-interface update done!"
}




echo "Run this update only on stable wired network (no WiFi please). Updating throught wired switch or router is also acceptable. It can take up to 8 minutes!"
read -r -p "Are you sure? [y/N] " response
case $response in
    [yY][eE][sS]|[yY])
        eti_off
        update_fw
        update_web
        echo "Update has been finished. Now You need to hard-reboot (turn off/on power of the board) to use new firmware!"
        exit;
        ;;
    *)
        exit;
        ;;
esac


